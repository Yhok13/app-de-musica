# 🎵 Music Player Pro

Un reproductor de música offline completo y elegante para Android, construido con Kotlin y Jetpack Compose.

![API](https://img.shields.io/badge/API-29%2B-brightgreen.svg)
![Kotlin](https://img.shields.io/badge/Kotlin-1.9.0-blue.svg)
![Compose](https://img.shields.io/badge/Jetpack%20Compose-Material%203-purple.svg)

## 📱 Capturas de Pantalla

*Próximamente*

## ✨ Características

### Reproducción de Audio
- ✅ Soporte para MP3, FLAC, OGG, WAV, AAC, M4A
- ✅ Reproducción en segundo plano
- ✅ Controles en notificación y pantalla de bloqueo
- ✅ Modos Shuffle (aleatorio) y Repeat (repetir)
- ✅ Cola de reproducción con arrastrar y soltar
- ✅ Seekbar fluida

### Organización de Biblioteca
- ✅ Vista por Canciones
- ✅ Vista por Álbumes
- ✅ Vista por Artistas
- ✅ Vista por Carpetas (navegación de directorios)
- ✅ Playlists personalizadas
- ✅ Canciones favoritas

### Funcionalidades Avanzadas
- ✅ Ecualizador de 5 bandas
- ✅ Bass Boost
- ✅ Búsqueda instantánea global
- ✅ Compartir archivos de audio
- ✅ Establecer como tono de llamada
- ✅ Eliminar archivos

### Interfaz de Usuario
- ✅ Material Design 3 (Material You)
- ✅ Tema dinámico basado en el sistema
- ✅ Carátulas de álbum con placeholders elegantes
- ✅ Animaciones fluidas
- ✅ Mini player persistente

## 🛠 Stack Tecnológico

| Categoría | Tecnología |
|-----------|------------|
| Lenguaje | Kotlin 100% |
| UI | Jetpack Compose + Material 3 |
| Arquitectura | Clean Architecture + MVVM |
| Inyección de Dependencias | Hilt |
| Base de Datos | Room |
| Motor de Audio | Media3 (ExoPlayer) |
| Carga de Imágenes | Coil |
| Concurrencia | Coroutines & Flow |

## 📋 Requisitos

- Android 10 (API 29) o superior
- Android 14+ (API 34) totalmente compatible

## 🚀 Instalación

### Desde el código fuente

1. Clonar el repositorio:
```bash
git clone https://github.com/tu-usuario/music-player-pro.git
```

2. Abrir en Android Studio (Hedgehog o superior)

3. Sincronizar Gradle

4. Ejecutar en un dispositivo o emulador

### Compilar Release

1. Crear un keystore:
```bash
keytool -genkey -v -keystore musicplayer-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias musicplayer
```

2. Copiar `keystore.properties.template` a `keystore.properties` y completar los valores

3. Compilar:
```bash
./gradlew assembleRelease
```

El APK estará en `app/build/outputs/apk/release/`

## 📁 Estructura del Proyecto

```
app/src/main/java/com/musicplayer/pro/
├── data/                    # Capa de datos
│   ├── datasource/          # Fuentes de datos (MediaStore)
│   ├── local/               # Base de datos Room
│   │   ├── dao/             # Data Access Objects
│   │   ├── database/        # Configuración de Room
│   │   └── entity/          # Entidades de la BD
│   ├── mapper/              # Mappers entidad <-> modelo
│   └── repository/          # Implementaciones de repositorios
├── di/                      # Módulos de Hilt
├── domain/                  # Capa de dominio
│   ├── model/               # Modelos de dominio
│   ├── repository/          # Interfaces de repositorios
│   └── usecase/             # Casos de uso
├── presentation/            # Capa de presentación
│   ├── components/          # Componentes UI reutilizables
│   ├── navigation/          # Navegación
│   ├── screens/             # Pantallas
│   ├── state/               # Estados UI
│   ├── theme/               # Tema Material 3
│   └── viewmodel/           # ViewModels
├── service/                 # Servicio de música
├── util/                    # Utilidades
├── MainActivity.kt          # Activity principal
└── MusicPlayerApplication.kt # Clase Application
```

## 🔐 Permisos

La aplicación solicita los siguientes permisos:

| Permiso | Uso |
|---------|-----|
| `READ_MEDIA_AUDIO` (Android 13+) | Acceder a archivos de audio |
| `READ_EXTERNAL_STORAGE` (Android <13) | Acceder a archivos de audio |
| `FOREGROUND_SERVICE` | Reproducción en segundo plano |
| `POST_NOTIFICATIONS` | Notificación de reproducción |
| `WRITE_SETTINGS` | Establecer tono de llamada |

## 🎨 Personalización

### Tema
El tema se adapta automáticamente a los colores del sistema en Android 12+. En versiones anteriores, usa el esquema de colores predeterminado.

### Ecualizador
5 bandas configurables + Bass Boost con presets predefinidos:
- Normal
- Rock
- Pop
- Jazz
- Clásica
- Bass Boost

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo [LICENSE](LICENSE) para más detalles.

## 🤝 Contribuir

Las contribuciones son bienvenidas. Por favor:

1. Fork el repositorio
2. Crea una rama para tu feature (`git checkout -b feature/nueva-caracteristica`)
3. Commit tus cambios (`git commit -m 'Añadir nueva característica'`)
4. Push a la rama (`git push origin feature/nueva-caracteristica`)
5. Abre un Pull Request

## 📧 Contacto

- Email: support@musicplayerpro.app
- Issues: [GitHub Issues](https://github.com/tu-usuario/music-player-pro/issues)

---

Hecho con ❤️ usando Kotlin y Jetpack Compose
