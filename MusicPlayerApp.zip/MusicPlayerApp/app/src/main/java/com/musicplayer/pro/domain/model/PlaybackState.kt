package com.musicplayer.pro.domain.model

/**
 * Modelo que representa el estado actual de reproducción.
 */
data class PlaybackState(
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val currentPosition: Long = 0L,
    val duration: Long = 0L,
    val shuffleMode: ShuffleMode = ShuffleMode.OFF,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val queue: List<Song> = emptyList(),
    val currentQueueIndex: Int = -1,
    val playbackSpeed: Float = 1.0f,
    val isBuffering: Boolean = false,
    val error: String? = null
) {
    /**
     * Progreso de reproducción como porcentaje (0.0 - 1.0).
     */
    val progress: Float
        get() = if (duration > 0) currentPosition.toFloat() / duration else 0f

    /**
     * Posición actual formateada.
     */
    val formattedPosition: String
        get() = formatDuration(currentPosition)

    /**
     * Duración formateada.
     */
    val formattedDuration: String
        get() = formatDuration(duration)

    /**
     * Tiempo restante formateado.
     */
    val formattedRemaining: String
        get() = "-${formatDuration(duration - currentPosition)}"

    /**
     * Verifica si hay una canción cargada.
     */
    val hasSong: Boolean
        get() = currentSong != null

    /**
     * Verifica si hay más canciones en la cola.
     */
    val hasNext: Boolean
        get() = currentQueueIndex < queue.size - 1

    /**
     * Verifica si hay canciones anteriores en la cola.
     */
    val hasPrevious: Boolean
        get() = currentQueueIndex > 0

    /**
     * Obtiene la siguiente canción en la cola.
     */
    val nextSong: Song?
        get() = if (hasNext) queue.getOrNull(currentQueueIndex + 1) else null

    /**
     * Obtiene la canción anterior en la cola.
     */
    val previousSong: Song?
        get() = if (hasPrevious) queue.getOrNull(currentQueueIndex - 1) else null

    /**
     * Canciones restantes en la cola.
     */
    val upNextSongs: List<Song>
        get() = if (currentQueueIndex >= 0 && currentQueueIndex < queue.size - 1) {
            queue.subList(currentQueueIndex + 1, queue.size)
        } else {
            emptyList()
        }

    private fun formatDuration(millis: Long): String {
        val totalSeconds = millis / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (hours > 0) {
            String.format("%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%d:%02d", minutes, seconds)
        }
    }

    companion object {
        /**
         * Estado inicial/vacío.
         */
        val EMPTY = PlaybackState()
    }
}

/**
 * Modos de reproducción aleatoria.
 */
enum class ShuffleMode {
    OFF,
    ON
}

/**
 * Modos de repetición.
 */
enum class RepeatMode {
    OFF,      // Sin repetición
    ONE,      // Repetir una canción
    ALL       // Repetir toda la cola
}
