package com.musicplayer.pro.presentation.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.presentation.theme.PlayerColors
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.EqualizerViewModel

/**
 * Pantalla del ecualizador.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: EqualizerViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Ecualizador") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Atrás"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.reset() }) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Reiniciar"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(Sizes.PaddingMedium)
        ) {
            // Switch de habilitación
            EnableSwitch(
                isEnabled = uiState.isEnabled,
                onEnabledChange = { viewModel.setEnabled(it) }
            )

            Spacer(modifier = Modifier.height(Sizes.PaddingLarge))

            // Presets
            PresetsSection(
                presets = viewModel.getCustomPresets(),
                currentPreset = uiState.currentPreset,
                onPresetSelected = { name, levels ->
                    viewModel.applyCustomPreset(name, levels)
                },
                enabled = uiState.isEnabled
            )

            Spacer(modifier = Modifier.height(Sizes.PaddingLarge))

            // Bandas del ecualizador
            EqualizerBands(
                bandLevels = uiState.bandLevels,
                bandFrequencies = uiState.bandFrequencies,
                minLevel = uiState.minLevel,
                maxLevel = uiState.maxLevel,
                onBandLevelChange = { band, level ->
                    viewModel.setBandLevel(band, level)
                },
                enabled = uiState.isEnabled
            )

            Spacer(modifier = Modifier.height(Sizes.PaddingLarge))

            // Bass Boost
            if (viewModel.isBassBoostSupported()) {
                BassBoostSection(
                    strength = uiState.bassBoostStrength,
                    onStrengthChange = { viewModel.setBassBoostStrength(it) },
                    enabled = uiState.isEnabled
                )
            }
        }
    }
}

/**
 * Switch para habilitar/deshabilitar el ecualizador.
 */
@Composable
private fun EnableSwitch(
    isEnabled: Boolean,
    onEnabledChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(Sizes.PaddingMedium),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Ecualizador",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = if (isEnabled) "Activado" else "Desactivado",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = isEnabled,
                onCheckedChange = onEnabledChange
            )
        }
    }
}

/**
 * Sección de presets.
 */
@Composable
private fun PresetsSection(
    presets: List<Pair<String, List<Int>>>,
    currentPreset: String?,
    onPresetSelected: (String, List<Int>) -> Unit,
    enabled: Boolean
) {
    Column {
        Text(
            text = "Presets",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(Sizes.PaddingSmall))
        
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(Sizes.PaddingSmall)
        ) {
            items(presets) { (name, levels) ->
                FilterChip(
                    selected = currentPreset == name,
                    onClick = { onPresetSelected(name, levels) },
                    label = { Text(name) },
                    enabled = enabled
                )
            }
        }
    }
}

/**
 * Bandas del ecualizador.
 */
@Composable
private fun EqualizerBands(
    bandLevels: List<Int>,
    bandFrequencies: List<Int>,
    minLevel: Int,
    maxLevel: Int,
    onBandLevelChange: (Int, Int) -> Unit,
    enabled: Boolean
) {
    Column {
        Text(
            text = "Bandas",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(Sizes.PaddingSmall))
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            bandLevels.forEachIndexed { index, level ->
                EqualizerBand(
                    level = level,
                    frequency = bandFrequencies.getOrNull(index) ?: 0,
                    minLevel = minLevel,
                    maxLevel = maxLevel,
                    onLevelChange = { newLevel ->
                        onBandLevelChange(index, newLevel)
                    },
                    enabled = enabled
                )
            }
        }
    }
}

/**
 * Banda individual del ecualizador.
 */
@Composable
private fun EqualizerBand(
    level: Int,
    frequency: Int,
    minLevel: Int,
    maxLevel: Int,
    onLevelChange: (Int) -> Unit,
    enabled: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(50.dp)
    ) {
        // Valor actual
        Text(
            text = "${level / 100}dB",
            style = MaterialTheme.typography.labelSmall,
            color = if (enabled) MaterialTheme.colorScheme.onSurface 
                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
        )
        
        // Slider vertical
        Box(
            modifier = Modifier
                .weight(1f)
                .rotate(270f)
        ) {
            Slider(
                value = level.toFloat(),
                onValueChange = { onLevelChange(it.toInt()) },
                valueRange = minLevel.toFloat()..maxLevel.toFloat(),
                enabled = enabled,
                colors = SliderDefaults.colors(
                    thumbColor = PlayerColors.EqualizerBand,
                    activeTrackColor = PlayerColors.EqualizerBand
                ),
                modifier = Modifier.width(150.dp)
            )
        }
        
        // Frecuencia
        Text(
            text = formatFrequency(frequency),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Sección de Bass Boost.
 */
@Composable
private fun BassBoostSection(
    strength: Int,
    onStrengthChange: (Int) -> Unit,
    enabled: Boolean
) {
    Column {
        Text(
            text = "Bass Boost",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(Sizes.PaddingSmall))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "0",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Slider(
                value = strength.toFloat(),
                onValueChange = { onStrengthChange(it.toInt()) },
                valueRange = 0f..1000f,
                enabled = enabled,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = Sizes.PaddingSmall),
                colors = SliderDefaults.colors(
                    thumbColor = PlayerColors.EqualizerBand,
                    activeTrackColor = PlayerColors.EqualizerBand
                )
            )
            
            Text(
                text = "Max",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        Text(
            text = "Intensidad: ${(strength / 10)}%",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Formatea la frecuencia para mostrar.
 */
private fun formatFrequency(frequency: Int): String {
    return when {
        frequency >= 1000 -> "${frequency / 1000}kHz"
        else -> "${frequency}Hz"
    }
}
