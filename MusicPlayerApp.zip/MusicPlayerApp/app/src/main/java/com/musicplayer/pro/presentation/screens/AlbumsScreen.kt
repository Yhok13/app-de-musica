package com.musicplayer.pro.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.domain.model.Album
import com.musicplayer.pro.presentation.components.AlbumArt
import com.musicplayer.pro.presentation.theme.CustomShapes
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.LibraryViewModel

/**
 * Pantalla de álbumes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumsScreen(
    onAlbumClick: (Album) -> Unit,
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: LibraryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()

    Scaffold(
        modifier = modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "Álbumes")
                        if (uiState.albums.isNotEmpty()) {
                            Text(
                                text = "${uiState.albums.size} álbumes",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onSearchClick) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "Buscar"
                        )
                    }
                },
                scrollBehavior = scrollBehavior
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                uiState.isLoading -> {
                    LoadingState()
                }
                uiState.albums.isEmpty() -> {
                    EmptyState(
                        icon = Icons.Filled.Album,
                        title = "No hay álbumes",
                        message = "No se encontraron álbumes en tu dispositivo"
                    )
                }
                else -> {
                    AlbumsGrid(
                        albums = uiState.albums,
                        onAlbumClick = onAlbumClick
                    )
                }
            }
        }
    }
}

/**
 * Grid de álbumes.
 */
@Composable
private fun AlbumsGrid(
    albums: List<Album>,
    onAlbumClick: (Album) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 150.dp),
        contentPadding = PaddingValues(
            start = Sizes.PaddingMedium,
            end = Sizes.PaddingMedium,
            top = Sizes.PaddingSmall,
            bottom = 120.dp
        ),
        horizontalArrangement = Arrangement.spacedBy(Sizes.PaddingSmall),
        verticalArrangement = Arrangement.spacedBy(Sizes.PaddingSmall)
    ) {
        items(
            items = albums,
            key = { it.id }
        ) { album ->
            AlbumItem(
                album = album,
                onClick = { onAlbumClick(album) }
            )
        }
    }
}

/**
 * Item de álbum para el grid.
 */
@Composable
private fun AlbumItem(
    album: Album,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(CustomShapes.SongCard)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        )
    ) {
        Column {
            // Carátula del álbum
            AlbumArt(
                albumArtUri = album.albumArtUri,
                contentDescription = "Carátula de ${album.name}",
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f),
                placeholderSeed = album.name,
                elevation = 0.dp,
                shape = CustomShapes.AlbumArtSmall
            )

            // Información del álbum
            Column(
                modifier = Modifier.padding(Sizes.PaddingSmall)
            ) {
                Text(
                    text = album.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = album.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = "${album.songCount} canciones",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}

/**
 * Pantalla de detalle de álbum.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumDetailScreen(
    albumId: Long,
    onBackClick: () -> Unit,
    onSongClick: (com.musicplayer.pro.domain.model.Song) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: LibraryViewModel = hiltViewModel(),
    playerViewModel: com.musicplayer.pro.presentation.viewmodel.PlayerViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val album = uiState.albums.find { it.id == albumId }
    
    // Obtener canciones del álbum
    val songs = remember(albumId) {
        mutableListOf<com.musicplayer.pro.domain.model.Song>()
    }
    
    LaunchedEffect(albumId) {
        viewModel.getSongsByAlbum(albumId) { albumSongs ->
            songs.clear()
            songs.addAll(albumSongs)
        }
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(album?.name ?: "Álbum") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Atrás"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        // Contenido del álbum
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Header con carátula e información
            if (album != null) {
                AlbumHeader(album = album)
            }
            
            // Lista de canciones
            // ... (implementar lista de canciones del álbum)
        }
    }
}

/**
 * Header del álbum con carátula e información.
 */
@Composable
private fun AlbumHeader(album: Album) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(Sizes.PaddingMedium),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AlbumArt(
            albumArtUri = album.albumArtUri,
            contentDescription = "Carátula de ${album.name}",
            size = Sizes.AlbumArtMedium,
            placeholderSeed = album.name
        )
        
        Spacer(modifier = Modifier.height(Sizes.PaddingMedium))
        
        Text(
            text = album.name,
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
        
        Text(
            text = album.artist,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Text(
            text = "${album.songCount} canciones • ${album.year ?: ""}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
    }
}

// Imports necesarios
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableListOf
import androidx.compose.runtime.remember
