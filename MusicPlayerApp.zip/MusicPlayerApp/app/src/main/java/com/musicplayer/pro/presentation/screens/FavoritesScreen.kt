package com.musicplayer.pro.presentation.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.presentation.components.SongItem
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.FavoritesViewModel
import com.musicplayer.pro.presentation.viewmodel.PlayerViewModel

/**
 * Pantalla de canciones favoritas.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    onBackClick: () -> Unit,
    onSongClick: (Song) -> Unit,
    modifier: Modifier = Modifier,
    favoritesViewModel: FavoritesViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel()
) {
    val uiState by favoritesViewModel.uiState.collectAsState()
    val playerState by playerViewModel.uiState.collectAsState()
    val favoriteSongIds by favoritesViewModel.favoriteSongIds.collectAsState()
    
    val listState = rememberLazyListState()
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()
    
    val expandedFab by remember {
        derivedStateOf { listState.firstVisibleItemIndex == 0 }
    }

    Scaffold(
        modifier = modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "Favoritos")
                        if (uiState.favorites.isNotEmpty()) {
                            Text(
                                text = "${uiState.favorites.size} canciones",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Atrás"
                        )
                    }
                },
                scrollBehavior = scrollBehavior
            )
        },
        floatingActionButton = {
            if (uiState.favorites.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = {
                        playerViewModel.playSongs(uiState.favorites, 0)
                    },
                    expanded = expandedFab,
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Shuffle,
                            contentDescription = null
                        )
                    },
                    text = { Text("Aleatorio") }
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                uiState.isLoading -> {
                    LoadingState()
                }
                uiState.favorites.isEmpty() -> {
                    EmptyState(
                        icon = Icons.Filled.Favorite,
                        title = "No hay favoritos",
                        message = "Marca canciones con el corazón para añadirlas aquí"
                    )
                }
                else -> {
                    FavoritesList(
                        favorites = uiState.favorites,
                        currentSongId = playerState.currentSong?.id,
                        favoriteSongIds = favoriteSongIds,
                        listState = listState,
                        onSongClick = { song ->
                            playerViewModel.playSongs(uiState.favorites, uiState.favorites.indexOf(song))
                            onSongClick(song)
                        },
                        onFavoriteClick = { songId ->
                            favoritesViewModel.toggleFavorite(songId)
                        }
                    )
                }
            }
        }
    }
}

/**
 * Lista de canciones favoritas.
 */
@Composable
private fun FavoritesList(
    favorites: List<Song>,
    currentSongId: Long?,
    favoriteSongIds: Set<Long>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onSongClick: (Song) -> Unit,
    onFavoriteClick: (Long) -> Unit
) {
    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(
            top = Sizes.PaddingSmall,
            bottom = 120.dp
        )
    ) {
        items(
            items = favorites,
            key = { it.id }
        ) { song ->
            SongItem(
                song = song,
                onClick = { onSongClick(song) },
                isPlaying = song.id == currentSongId,
                isFavorite = song.id in favoriteSongIds,
                onFavoriteClick = { onFavoriteClick(song.id) },
                onMoreClick = { }
            )
        }
    }
}
