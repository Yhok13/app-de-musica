package com.musicplayer.pro.util

import android.Manifest
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.MultiplePermissionsState
import com.google.accompanist.permissions.PermissionState
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale

/**
 * Estado del permiso de audio para la UI.
 */
data class AudioPermissionState(
    val hasPermission: Boolean,
    val shouldShowRationale: Boolean,
    val isPermanentlyDenied: Boolean,
    val requestPermission: () -> Unit
)

/**
 * Composable que maneja el estado del permiso de audio.
 * Implementa la lógica de "Pedir al inicio -> Reintentar -> Cargar automático".
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun rememberAudioPermissionState(
    onPermissionGranted: () -> Unit = {},
    onPermissionDenied: () -> Unit = {}
): AudioPermissionState {
    val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val permissionState = rememberPermissionState(permission = audioPermission)
    var hasRequestedOnce by remember { mutableStateOf(false) }

    // Observar cambios en el ciclo de vida para detectar cuando el usuario vuelve de configuración
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                // Verificar el permiso cuando la app vuelve al primer plano
                // Esto permite detectar si el usuario concedió el permiso desde configuración
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Reaccionar a cambios en el estado del permiso
    LaunchedEffect(permissionState.status.isGranted) {
        if (permissionState.status.isGranted) {
            onPermissionGranted()
        } else if (hasRequestedOnce) {
            onPermissionDenied()
        }
    }

    val isPermanentlyDenied = !permissionState.status.isGranted &&
            !permissionState.status.shouldShowRationale &&
            hasRequestedOnce

    return AudioPermissionState(
        hasPermission = permissionState.status.isGranted,
        shouldShowRationale = permissionState.status.shouldShowRationale,
        isPermanentlyDenied = isPermanentlyDenied,
        requestPermission = {
            hasRequestedOnce = true
            permissionState.launchPermissionRequest()
        }
    )
}

/**
 * Composable que maneja múltiples permisos (audio + notificaciones).
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun rememberMultipleAudioPermissionsState(
    onAllPermissionsGranted: () -> Unit = {},
    onPermissionsDenied: () -> Unit = {}
): MultipleAudioPermissionsState {
    val permissions = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            listOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        } else {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    val permissionsState = rememberMultiplePermissionsState(permissions = permissions)
    var hasRequestedOnce by remember { mutableStateOf(false) }

    // Observar cambios en el ciclo de vida
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                // Verificar permisos cuando la app vuelve al primer plano
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Verificar si el permiso de audio está concedido
    val hasAudioPermission = permissionsState.permissions.any { permission ->
        val isAudioPermission = permission.permission == Manifest.permission.READ_MEDIA_AUDIO ||
                permission.permission == Manifest.permission.READ_EXTERNAL_STORAGE
        isAudioPermission && permission.status.isGranted
    }

    LaunchedEffect(hasAudioPermission) {
        if (hasAudioPermission) {
            onAllPermissionsGranted()
        } else if (hasRequestedOnce) {
            onPermissionsDenied()
        }
    }

    val isPermanentlyDenied = !hasAudioPermission &&
            permissionsState.permissions.none { it.status.shouldShowRationale } &&
            hasRequestedOnce

    return MultipleAudioPermissionsState(
        hasAudioPermission = hasAudioPermission,
        allPermissionsGranted = permissionsState.allPermissionsGranted,
        shouldShowRationale = permissionsState.shouldShowRationale,
        isPermanentlyDenied = isPermanentlyDenied,
        requestPermissions = {
            hasRequestedOnce = true
            permissionsState.launchMultiplePermissionRequest()
        }
    )
}

/**
 * Estado de múltiples permisos para la UI.
 */
data class MultipleAudioPermissionsState(
    val hasAudioPermission: Boolean,
    val allPermissionsGranted: Boolean,
    val shouldShowRationale: Boolean,
    val isPermanentlyDenied: Boolean,
    val requestPermissions: () -> Unit
)

/**
 * Composable que solicita permisos automáticamente al inicio.
 */
@Composable
fun RequestPermissionsOnStart(
    onPermissionResult: (Boolean) -> Unit
) {
    val permissionState = rememberAudioPermissionState(
        onPermissionGranted = { onPermissionResult(true) },
        onPermissionDenied = { onPermissionResult(false) }
    )

    // Solicitar permiso automáticamente al inicio si no está concedido
    LaunchedEffect(Unit) {
        if (!permissionState.hasPermission) {
            permissionState.requestPermission()
        } else {
            onPermissionResult(true)
        }
    }
}

/**
 * Composable que observa cambios en el permiso y ejecuta una acción cuando se concede.
 */
@Composable
fun ObservePermissionChanges(
    onPermissionGranted: () -> Unit
) {
    val permissionState = rememberAudioPermissionState(
        onPermissionGranted = onPermissionGranted
    )

    // Observar cambios en el ciclo de vida para detectar concesión desde configuración
    val lifecycleOwner = LocalLifecycleOwner.current
    var wasInBackground by remember { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> wasInBackground = true
                Lifecycle.Event.ON_RESUME -> {
                    if (wasInBackground && permissionState.hasPermission) {
                        onPermissionGranted()
                    }
                    wasInBackground = false
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
}
