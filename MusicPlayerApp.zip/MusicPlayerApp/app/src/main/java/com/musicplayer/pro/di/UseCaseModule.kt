package com.musicplayer.pro.di

import com.musicplayer.pro.domain.repository.AudioRepository
import com.musicplayer.pro.domain.repository.FavoriteRepository
import com.musicplayer.pro.domain.repository.FolderRepository
import com.musicplayer.pro.domain.repository.PlaylistRepository
import com.musicplayer.pro.domain.usecase.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Módulo de Hilt para proveer los casos de uso.
 */
@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {

    // ==================== Song Use Cases ====================

    @Provides
    @Singleton
    fun provideGetAllSongsUseCase(repository: AudioRepository): GetAllSongsUseCase {
        return GetAllSongsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetSongsByDateAddedUseCase(repository: AudioRepository): GetSongsByDateAddedUseCase {
        return GetSongsByDateAddedUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetSongByIdUseCase(repository: AudioRepository): GetSongByIdUseCase {
        return GetSongByIdUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetSongsByAlbumUseCase(repository: AudioRepository): GetSongsByAlbumUseCase {
        return GetSongsByAlbumUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetSongsByArtistUseCase(repository: AudioRepository): GetSongsByArtistUseCase {
        return GetSongsByArtistUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetSongsByFolderUseCase(repository: AudioRepository): GetSongsByFolderUseCase {
        return GetSongsByFolderUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideSearchSongsUseCase(repository: AudioRepository): SearchSongsUseCase {
        return SearchSongsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetMostPlayedSongsUseCase(repository: AudioRepository): GetMostPlayedSongsUseCase {
        return GetMostPlayedSongsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetRecentlyPlayedSongsUseCase(repository: AudioRepository): GetRecentlyPlayedSongsUseCase {
        return GetRecentlyPlayedSongsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideIncrementPlayCountUseCase(repository: AudioRepository): IncrementPlayCountUseCase {
        return IncrementPlayCountUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideScanMediaUseCase(repository: AudioRepository): ScanMediaUseCase {
        return ScanMediaUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetSongCountUseCase(repository: AudioRepository): GetSongCountUseCase {
        return GetSongCountUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideDeleteSongUseCase(repository: AudioRepository): DeleteSongUseCase {
        return DeleteSongUseCase(repository)
    }

    // ==================== Album Use Cases ====================

    @Provides
    @Singleton
    fun provideGetAllAlbumsUseCase(repository: AudioRepository): GetAllAlbumsUseCase {
        return GetAllAlbumsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetAlbumByIdUseCase(repository: AudioRepository): GetAlbumByIdUseCase {
        return GetAlbumByIdUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetAlbumsByArtistUseCase(repository: AudioRepository): GetAlbumsByArtistUseCase {
        return GetAlbumsByArtistUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideSearchAlbumsUseCase(repository: AudioRepository): SearchAlbumsUseCase {
        return SearchAlbumsUseCase(repository)
    }

    // ==================== Artist Use Cases ====================

    @Provides
    @Singleton
    fun provideGetAllArtistsUseCase(repository: AudioRepository): GetAllArtistsUseCase {
        return GetAllArtistsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetArtistByIdUseCase(repository: AudioRepository): GetArtistByIdUseCase {
        return GetArtistByIdUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideSearchArtistsUseCase(repository: AudioRepository): SearchArtistsUseCase {
        return SearchArtistsUseCase(repository)
    }

    // ==================== Folder Use Cases ====================

    @Provides
    @Singleton
    fun provideGetAllFoldersUseCase(repository: FolderRepository): GetAllFoldersUseCase {
        return GetAllFoldersUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetRootFoldersUseCase(repository: FolderRepository): GetRootFoldersUseCase {
        return GetRootFoldersUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetSubFoldersUseCase(repository: FolderRepository): GetSubFoldersUseCase {
        return GetSubFoldersUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetFolderByPathUseCase(repository: FolderRepository): GetFolderByPathUseCase {
        return GetFolderByPathUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetSongsInFolderUseCase(repository: FolderRepository): GetSongsInFolderUseCase {
        return GetSongsInFolderUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideSearchFoldersUseCase(repository: FolderRepository): SearchFoldersUseCase {
        return SearchFoldersUseCase(repository)
    }

    // ==================== Playlist Use Cases ====================

    @Provides
    @Singleton
    fun provideGetAllPlaylistsUseCase(repository: PlaylistRepository): GetAllPlaylistsUseCase {
        return GetAllPlaylistsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetPlaylistByIdUseCase(repository: PlaylistRepository): GetPlaylistByIdUseCase {
        return GetPlaylistByIdUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetPlaylistSongsUseCase(repository: PlaylistRepository): GetPlaylistSongsUseCase {
        return GetPlaylistSongsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideCreatePlaylistUseCase(repository: PlaylistRepository): CreatePlaylistUseCase {
        return CreatePlaylistUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideUpdatePlaylistNameUseCase(repository: PlaylistRepository): UpdatePlaylistNameUseCase {
        return UpdatePlaylistNameUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideDeletePlaylistUseCase(repository: PlaylistRepository): DeletePlaylistUseCase {
        return DeletePlaylistUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideAddSongToPlaylistUseCase(repository: PlaylistRepository): AddSongToPlaylistUseCase {
        return AddSongToPlaylistUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideAddSongsToPlaylistUseCase(repository: PlaylistRepository): AddSongsToPlaylistUseCase {
        return AddSongsToPlaylistUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideRemoveSongFromPlaylistUseCase(repository: PlaylistRepository): RemoveSongFromPlaylistUseCase {
        return RemoveSongFromPlaylistUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideReorderPlaylistSongsUseCase(repository: PlaylistRepository): ReorderPlaylistSongsUseCase {
        return ReorderPlaylistSongsUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideIsSongInPlaylistUseCase(repository: PlaylistRepository): IsSongInPlaylistUseCase {
        return IsSongInPlaylistUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideSearchPlaylistsUseCase(repository: PlaylistRepository): SearchPlaylistsUseCase {
        return SearchPlaylistsUseCase(repository)
    }

    // ==================== Favorite Use Cases ====================

    @Provides
    @Singleton
    fun provideGetAllFavoritesUseCase(repository: FavoriteRepository): GetAllFavoritesUseCase {
        return GetAllFavoritesUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideIsFavoriteUseCase(repository: FavoriteRepository): IsFavoriteUseCase {
        return IsFavoriteUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideAddToFavoritesUseCase(repository: FavoriteRepository): AddToFavoritesUseCase {
        return AddToFavoritesUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideRemoveFromFavoritesUseCase(repository: FavoriteRepository): RemoveFromFavoritesUseCase {
        return RemoveFromFavoritesUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideToggleFavoriteUseCase(repository: FavoriteRepository): ToggleFavoriteUseCase {
        return ToggleFavoriteUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetFavoriteCountUseCase(repository: FavoriteRepository): GetFavoriteCountUseCase {
        return GetFavoriteCountUseCase(repository)
    }

    @Provides
    @Singleton
    fun provideGetFavoriteSongIdsUseCase(repository: FavoriteRepository): GetFavoriteSongIdsUseCase {
        return GetFavoriteSongIdsUseCase(repository)
    }
}
