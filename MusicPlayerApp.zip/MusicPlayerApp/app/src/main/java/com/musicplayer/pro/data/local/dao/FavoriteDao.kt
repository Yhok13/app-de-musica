package com.musicplayer.pro.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.musicplayer.pro.data.local.entity.FavoriteEntity
import com.musicplayer.pro.data.local.entity.SongEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO para operaciones de base de datos relacionadas con favoritos.
 */
@Dao
interface FavoriteDao {

    /**
     * Obtiene todas las canciones favoritas ordenadas por fecha de adición.
     */
    @Query("""
        SELECT s.* FROM songs s
        INNER JOIN favorites f ON s.id = f.song_id
        ORDER BY f.added_at DESC
    """)
    fun getAllFavorites(): Flow<List<SongEntity>>

    /**
     * Obtiene todos los registros de favoritos.
     */
    @Query("SELECT * FROM favorites ORDER BY added_at DESC")
    fun getAllFavoriteEntities(): Flow<List<FavoriteEntity>>

    /**
     * Verifica si una canción es favorita.
     */
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE song_id = :songId)")
    suspend fun isFavorite(songId: Long): Boolean

    /**
     * Verifica si una canción es favorita (Flow).
     */
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE song_id = :songId)")
    fun isFavoriteFlow(songId: Long): Flow<Boolean>

    /**
     * Obtiene el conteo total de favoritos.
     */
    @Query("SELECT COUNT(*) FROM favorites")
    suspend fun getFavoriteCount(): Int

    /**
     * Obtiene el conteo total de favoritos (Flow).
     */
    @Query("SELECT COUNT(*) FROM favorites")
    fun getFavoriteCountFlow(): Flow<Int>

    /**
     * Añade una canción a favoritos.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addToFavorites(favorite: FavoriteEntity): Long

    /**
     * Elimina una canción de favoritos.
     */
    @Query("DELETE FROM favorites WHERE song_id = :songId")
    suspend fun removeFromFavorites(songId: Long)

    /**
     * Elimina un registro de favoritos.
     */
    @Delete
    suspend fun deleteFavorite(favorite: FavoriteEntity)

    /**
     * Elimina todos los favoritos.
     */
    @Query("DELETE FROM favorites")
    suspend fun deleteAllFavorites()

    /**
     * Obtiene los IDs de todas las canciones favoritas.
     */
    @Query("SELECT song_id FROM favorites")
    suspend fun getAllFavoriteSongIds(): List<Long>

    /**
     * Obtiene los IDs de todas las canciones favoritas (Flow).
     */
    @Query("SELECT song_id FROM favorites")
    fun getAllFavoriteSongIdsFlow(): Flow<List<Long>>
}
