package com.musicplayer.pro.di

import android.content.Context
import com.musicplayer.pro.service.EqualizerManager
import com.musicplayer.pro.service.MusicController
import com.musicplayer.pro.service.MusicNotificationManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Módulo de Hilt para proveer dependencias relacionadas con el servicio de música.
 */
@Module
@InstallIn(SingletonComponent::class)
object ServiceModule {

    /**
     * Provee el controlador de música.
     */
    @Provides
    @Singleton
    fun provideMusicController(
        @ApplicationContext context: Context
    ): MusicController {
        return MusicController(context)
    }

    /**
     * Provee el gestor de notificaciones de música.
     */
    @Provides
    @Singleton
    fun provideMusicNotificationManager(
        @ApplicationContext context: Context
    ): MusicNotificationManager {
        return MusicNotificationManager(context)
    }

    /**
     * Provee el gestor del ecualizador.
     */
    @Provides
    @Singleton
    fun provideEqualizerManager(
        @ApplicationContext context: Context
    ): EqualizerManager {
        return EqualizerManager(context)
    }
}
