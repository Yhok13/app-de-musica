package com.musicplayer.pro.presentation.navigation

/**
 * Pestañas de la barra de navegación inferior.
 */
enum class BottomNavTab {
    SONGS,
    ALBUMS,
    ARTISTS,
    FOLDERS,
    PLAYLISTS
}

/**
 * Rutas de navegación de la aplicación.
 */
sealed class Screen(val route: String) {
    
    // Pantallas principales (Bottom Navigation)
    object Songs : Screen("songs")
    object Albums : Screen("albums")
    object Artists : Screen("artists")
    object Folders : Screen("folders")
    object Playlists : Screen("playlists")
    
    // Pantallas de detalle
    object AlbumDetail : Screen("album/{albumId}") {
        fun createRoute(albumId: Long) = "album/$albumId"
    }
    
    object ArtistDetail : Screen("artist/{artistId}") {
        fun createRoute(artistId: Long) = "artist/$artistId"
    }
    
    object PlaylistDetail : Screen("playlist/{playlistId}") {
        fun createRoute(playlistId: Long) = "playlist/$playlistId"
    }
    
    object FolderDetail : Screen("folder/{folderPath}") {
        fun createRoute(folderPath: String) = "folder/${folderPath.encodeUrl()}"
    }
    
    // Pantallas de funcionalidad
    object NowPlaying : Screen("now_playing")
    object Queue : Screen("queue")
    object Search : Screen("search")
    object Favorites : Screen("favorites")
    object Equalizer : Screen("equalizer")
    object Settings : Screen("settings")
    
    // Pantallas de gestión de archivos
    object SongOptions : Screen("song_options/{songId}") {
        fun createRoute(songId: Long) = "song_options/$songId"
    }
    
    object AddToPlaylist : Screen("add_to_playlist/{songId}") {
        fun createRoute(songId: Long) = "add_to_playlist/$songId"
    }
    
    companion object {
        /**
         * Obtiene la pantalla por su ruta.
         */
        fun fromRoute(route: String?): Screen? {
            return when {
                route == null -> null
                route == Songs.route -> Songs
                route == Albums.route -> Albums
                route == Artists.route -> Artists
                route == Folders.route -> Folders
                route == Playlists.route -> Playlists
                route.startsWith("album/") -> AlbumDetail
                route.startsWith("artist/") -> ArtistDetail
                route.startsWith("playlist/") -> PlaylistDetail
                route.startsWith("folder/") -> FolderDetail
                route == NowPlaying.route -> NowPlaying
                route == Queue.route -> Queue
                route == Search.route -> Search
                route == Favorites.route -> Favorites
                route == Equalizer.route -> Equalizer
                route == Settings.route -> Settings
                else -> null
            }
        }
        
        /**
         * Pantallas que muestran la barra de navegación inferior.
         */
        val bottomNavScreens = listOf(
            Songs.route,
            Albums.route,
            Artists.route,
            Folders.route,
            Playlists.route
        )
    }
}

/**
 * Extensión para codificar URLs.
 */
private fun String.encodeUrl(): String {
    return java.net.URLEncoder.encode(this, "UTF-8")
}

/**
 * Argumentos de navegación.
 */
object NavArgs {
    const val ALBUM_ID = "albumId"
    const val ARTIST_ID = "artistId"
    const val PLAYLIST_ID = "playlistId"
    const val FOLDER_PATH = "folderPath"
    const val SONG_ID = "songId"
}
