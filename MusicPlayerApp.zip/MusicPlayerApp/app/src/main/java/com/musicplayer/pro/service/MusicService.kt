package com.musicplayer.pro.service

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.musicplayer.pro.MusicPlayerApplication
import com.musicplayer.pro.domain.model.Song
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Servicio de reproducción de música usando Media3 (ExoPlayer).
 * Maneja la reproducción en segundo plano, notificaciones y controles del sistema.
 */
@AndroidEntryPoint
class MusicService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private var exoPlayer: ExoPlayer? = null

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()

        // Configurar ExoPlayer con atributos de audio para música
        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        exoPlayer = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .apply {
                // Listener para eventos del reproductor
                addListener(playerListener)
            }

        // Crear intent para abrir la app al tocar la notificación
        val sessionActivityPendingIntent = packageManager?.getLaunchIntentForPackage(packageName)?.let { intent ->
            PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        // Crear MediaSession
        mediaSession = MediaSession.Builder(this, exoPlayer!!)
            .setSessionActivity(sessionActivityPendingIntent!!)
            .setCallback(MediaSessionCallback())
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player != null) {
            if (!player.playWhenReady || player.mediaItemCount == 0) {
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.removeListener(playerListener)
            player.release()
            release()
            mediaSession = null
        }
        exoPlayer = null
        super.onDestroy()
    }

    /**
     * Listener para eventos del reproductor.
     */
    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_IDLE -> {
                    // Reproductor inactivo
                }
                Player.STATE_BUFFERING -> {
                    // Cargando
                }
                Player.STATE_READY -> {
                    // Listo para reproducir
                }
                Player.STATE_ENDED -> {
                    // Reproducción terminada
                }
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            // Estado de reproducción cambiado
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            // Cambio de canción
        }
    }

    /**
     * Callback para la MediaSession.
     */
    private inner class MediaSessionCallback : MediaSession.Callback {
        // Implementar callbacks personalizados si es necesario
    }

    companion object {
        /**
         * Convierte una canción del dominio a MediaItem de Media3.
         */
        fun songToMediaItem(song: Song): MediaItem {
            val metadata = MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(song.albumArtUri?.let { android.net.Uri.parse(it) })
                .setTrackNumber(song.trackNumber)
                .setReleaseYear(song.year)
                .setDurationMs(song.duration)
                .build()

            return MediaItem.Builder()
                .setMediaId(song.id.toString())
                .setUri(song.filePath)
                .setMediaMetadata(metadata)
                .build()
        }

        /**
         * Convierte una lista de canciones a MediaItems.
         */
        fun songsToMediaItems(songs: List<Song>): List<MediaItem> {
            return songs.map { songToMediaItem(it) }
        }
    }
}
