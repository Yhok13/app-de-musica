package com.musicplayer.pro.domain.repository

import com.musicplayer.pro.domain.model.Album
import com.musicplayer.pro.domain.model.Artist
import com.musicplayer.pro.domain.model.Song
import kotlinx.coroutines.flow.Flow

/**
 * Interfaz del repositorio de audio.
 * Define las operaciones disponibles para acceder a canciones, álbumes y artistas.
 */
interface AudioRepository {

    /**
     * Escanea y sincroniza la biblioteca de música con MediaStore.
     * @return Result con el número de canciones encontradas o error.
     */
    suspend fun scanAndSyncLibrary(): Result<Int>

    // ==================== Canciones ====================

    /**
     * Obtiene todas las canciones ordenadas por título.
     */
    fun getAllSongs(): Flow<List<Song>>

    /**
     * Obtiene todas las canciones ordenadas por fecha de adición.
     */
    fun getAllSongsByDateAdded(): Flow<List<Song>>

    /**
     * Obtiene una canción por su ID.
     */
    suspend fun getSongById(songId: Long): Song?

    /**
     * Obtiene canciones por ID de álbum.
     */
    fun getSongsByAlbum(albumId: Long): Flow<List<Song>>

    /**
     * Obtiene canciones por ID de artista.
     */
    fun getSongsByArtist(artistId: Long): Flow<List<Song>>

    /**
     * Obtiene canciones por ruta de carpeta.
     */
    fun getSongsByFolder(folderPath: String): Flow<List<Song>>

    /**
     * Busca canciones por consulta.
     */
    fun searchSongs(query: String): Flow<List<Song>>

    /**
     * Obtiene las canciones más reproducidas.
     */
    fun getMostPlayedSongs(limit: Int = 50): Flow<List<Song>>

    /**
     * Obtiene las canciones reproducidas recientemente.
     */
    fun getRecentlyPlayedSongs(limit: Int = 50): Flow<List<Song>>

    /**
     * Incrementa el contador de reproducciones de una canción.
     */
    suspend fun incrementPlayCount(songId: Long)

    /**
     * Obtiene el conteo total de canciones.
     */
    suspend fun getSongCount(): Int

    /**
     * Elimina una canción de la base de datos.
     */
    suspend fun deleteSong(songId: Long)

    // ==================== Álbumes ====================

    /**
     * Obtiene todos los álbumes.
     */
    fun getAllAlbums(): Flow<List<Album>>

    /**
     * Obtiene un álbum por su ID.
     */
    suspend fun getAlbumById(albumId: Long): Album?

    /**
     * Obtiene álbumes por ID de artista.
     */
    fun getAlbumsByArtist(artistId: Long): Flow<List<Album>>

    /**
     * Busca álbumes por consulta.
     */
    fun searchAlbums(query: String): Flow<List<Album>>

    // ==================== Artistas ====================

    /**
     * Obtiene todos los artistas.
     */
    fun getAllArtists(): Flow<List<Artist>>

    /**
     * Obtiene un artista por su ID.
     */
    suspend fun getArtistById(artistId: Long): Artist?

    /**
     * Busca artistas por consulta.
     */
    fun searchArtists(query: String): Flow<List<Artist>>
}
