package com.musicplayer.pro.service

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.musicplayer.pro.domain.model.PlaybackState
import com.musicplayer.pro.domain.model.RepeatMode
import com.musicplayer.pro.domain.model.ShuffleMode
import com.musicplayer.pro.domain.model.Song
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Controlador de música que gestiona la conexión con el servicio de reproducción
 * y expone el estado de reproducción a la UI.
 */
@Singleton
class MusicController @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    private val _playbackState = MutableStateFlow(PlaybackState.EMPTY)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private var progressUpdateJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    // Mapa para almacenar las canciones originales por mediaId
    private val songMap = mutableMapOf<String, Song>()

    /**
     * Inicializa la conexión con el servicio de música.
     */
    fun initialize() {
        val sessionToken = SessionToken(context, ComponentName(context, MusicService::class.java))
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        
        controllerFuture?.addListener({
            mediaController = controllerFuture?.get()
            mediaController?.addListener(playerListener)
            updatePlaybackState()
            startProgressUpdates()
        }, MoreExecutors.directExecutor())
    }

    /**
     * Libera los recursos del controlador.
     */
    fun release() {
        progressUpdateJob?.cancel()
        mediaController?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
        controllerFuture = null
    }

    /**
     * Reproduce una canción específica.
     */
    fun playSong(song: Song) {
        mediaController?.let { controller ->
            songMap[song.id.toString()] = song
            val mediaItem = MusicService.songToMediaItem(song)
            controller.setMediaItem(mediaItem)
            controller.prepare()
            controller.play()
            _currentSong.value = song
        }
    }

    /**
     * Reproduce una lista de canciones comenzando desde un índice.
     */
    fun playSongs(songs: List<Song>, startIndex: Int = 0) {
        mediaController?.let { controller ->
            songMap.clear()
            songs.forEach { song ->
                songMap[song.id.toString()] = song
            }
            
            val mediaItems = MusicService.songsToMediaItems(songs)
            controller.setMediaItems(mediaItems, startIndex, 0)
            controller.prepare()
            controller.play()
            
            _queue.value = songs
            if (startIndex in songs.indices) {
                _currentSong.value = songs[startIndex]
            }
        }
    }

    /**
     * Añade una canción a la cola.
     */
    fun addToQueue(song: Song) {
        mediaController?.let { controller ->
            songMap[song.id.toString()] = song
            val mediaItem = MusicService.songToMediaItem(song)
            controller.addMediaItem(mediaItem)
            _queue.value = _queue.value + song
        }
    }

    /**
     * Añade una canción para reproducir después de la actual.
     */
    fun playNext(song: Song) {
        mediaController?.let { controller ->
            songMap[song.id.toString()] = song
            val mediaItem = MusicService.songToMediaItem(song)
            val nextIndex = controller.currentMediaItemIndex + 1
            controller.addMediaItem(nextIndex, mediaItem)
            
            val currentQueue = _queue.value.toMutableList()
            if (nextIndex <= currentQueue.size) {
                currentQueue.add(nextIndex, song)
                _queue.value = currentQueue
            }
        }
    }

    /**
     * Elimina una canción de la cola.
     */
    fun removeFromQueue(index: Int) {
        mediaController?.let { controller ->
            if (index in 0 until controller.mediaItemCount) {
                controller.removeMediaItem(index)
                val currentQueue = _queue.value.toMutableList()
                if (index < currentQueue.size) {
                    currentQueue.removeAt(index)
                    _queue.value = currentQueue
                }
            }
        }
    }

    /**
     * Mueve una canción en la cola.
     */
    fun moveQueueItem(fromIndex: Int, toIndex: Int) {
        mediaController?.let { controller ->
            controller.moveMediaItem(fromIndex, toIndex)
            val currentQueue = _queue.value.toMutableList()
            if (fromIndex < currentQueue.size && toIndex <= currentQueue.size) {
                val item = currentQueue.removeAt(fromIndex)
                currentQueue.add(toIndex, item)
                _queue.value = currentQueue
            }
        }
    }

    /**
     * Limpia la cola de reproducción.
     */
    fun clearQueue() {
        mediaController?.let { controller ->
            controller.clearMediaItems()
            _queue.value = emptyList()
            songMap.clear()
        }
    }

    /**
     * Reproduce o pausa la reproducción.
     */
    fun playPause() {
        mediaController?.let { controller ->
            if (controller.isPlaying) {
                controller.pause()
            } else {
                controller.play()
            }
        }
    }

    /**
     * Inicia la reproducción.
     */
    fun play() {
        mediaController?.play()
    }

    /**
     * Pausa la reproducción.
     */
    fun pause() {
        mediaController?.pause()
    }

    /**
     * Detiene la reproducción.
     */
    fun stop() {
        mediaController?.stop()
    }

    /**
     * Salta a la siguiente canción.
     */
    fun skipToNext() {
        mediaController?.let { controller ->
            if (controller.hasNextMediaItem()) {
                controller.seekToNext()
            }
        }
    }

    /**
     * Salta a la canción anterior.
     */
    fun skipToPrevious() {
        mediaController?.let { controller ->
            if (controller.currentPosition > 3000) {
                // Si han pasado más de 3 segundos, reiniciar la canción actual
                controller.seekTo(0)
            } else if (controller.hasPreviousMediaItem()) {
                controller.seekToPrevious()
            } else {
                controller.seekTo(0)
            }
        }
    }

    /**
     * Busca una posición específica en la canción actual.
     */
    fun seekTo(positionMs: Long) {
        mediaController?.seekTo(positionMs)
    }

    /**
     * Busca una posición específica como porcentaje (0.0 - 1.0).
     */
    fun seekToProgress(progress: Float) {
        mediaController?.let { controller ->
            val position = (controller.duration * progress).toLong()
            controller.seekTo(position)
        }
    }

    /**
     * Salta a una canción específica en la cola.
     */
    fun skipToQueueItem(index: Int) {
        mediaController?.let { controller ->
            if (index in 0 until controller.mediaItemCount) {
                controller.seekTo(index, 0)
            }
        }
    }

    /**
     * Alterna el modo aleatorio.
     */
    fun toggleShuffle() {
        mediaController?.let { controller ->
            controller.shuffleModeEnabled = !controller.shuffleModeEnabled
            updatePlaybackState()
        }
    }

    /**
     * Establece el modo aleatorio.
     */
    fun setShuffleMode(enabled: Boolean) {
        mediaController?.shuffleModeEnabled = enabled
        updatePlaybackState()
    }

    /**
     * Alterna el modo de repetición (Off -> All -> One -> Off).
     */
    fun toggleRepeatMode() {
        mediaController?.let { controller ->
            val newMode = when (controller.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
                else -> Player.REPEAT_MODE_OFF
            }
            controller.repeatMode = newMode
            updatePlaybackState()
        }
    }

    /**
     * Establece el modo de repetición.
     */
    fun setRepeatMode(mode: RepeatMode) {
        mediaController?.repeatMode = when (mode) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
        }
        updatePlaybackState()
    }

    /**
     * Establece la velocidad de reproducción.
     */
    fun setPlaybackSpeed(speed: Float) {
        mediaController?.setPlaybackSpeed(speed)
    }

    /**
     * Obtiene si el reproductor está reproduciendo.
     */
    val isPlaying: Boolean
        get() = mediaController?.isPlaying == true

    /**
     * Obtiene la posición actual de reproducción.
     */
    val currentPosition: Long
        get() = mediaController?.currentPosition ?: 0L

    /**
     * Obtiene la duración de la canción actual.
     */
    val duration: Long
        get() = mediaController?.duration ?: 0L

    /**
     * Listener para eventos del reproductor.
     */
    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            updatePlaybackState()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePlaybackState()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mediaItem?.let { item ->
                val song = songMap[item.mediaId]
                _currentSong.value = song
            }
            updatePlaybackState()
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            updatePlaybackState()
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            updatePlaybackState()
        }

        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
            updatePlaybackState()
        }
    }

    /**
     * Actualiza el estado de reproducción.
     */
    private fun updatePlaybackState() {
        mediaController?.let { controller ->
            val shuffleMode = if (controller.shuffleModeEnabled) ShuffleMode.ON else ShuffleMode.OFF
            val repeatMode = when (controller.repeatMode) {
                Player.REPEAT_MODE_OFF -> RepeatMode.OFF
                Player.REPEAT_MODE_ONE -> RepeatMode.ONE
                Player.REPEAT_MODE_ALL -> RepeatMode.ALL
                else -> RepeatMode.OFF
            }

            _playbackState.value = PlaybackState(
                currentSong = _currentSong.value,
                isPlaying = controller.isPlaying,
                currentPosition = controller.currentPosition,
                duration = controller.duration.coerceAtLeast(0),
                shuffleMode = shuffleMode,
                repeatMode = repeatMode,
                queue = _queue.value,
                currentQueueIndex = controller.currentMediaItemIndex,
                playbackSpeed = controller.playbackParameters.speed,
                isBuffering = controller.playbackState == Player.STATE_BUFFERING
            )
        }
    }

    /**
     * Inicia las actualizaciones periódicas del progreso.
     */
    private fun startProgressUpdates() {
        progressUpdateJob?.cancel()
        progressUpdateJob = scope.launch {
            while (isActive) {
                if (mediaController?.isPlaying == true) {
                    updatePlaybackState()
                }
                delay(500) // Actualizar cada 500ms
            }
        }
    }
}
