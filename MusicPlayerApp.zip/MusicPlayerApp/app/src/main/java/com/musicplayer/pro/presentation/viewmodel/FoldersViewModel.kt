package com.musicplayer.pro.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicplayer.pro.domain.model.Folder
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.usecase.GetAllFoldersUseCase
import com.musicplayer.pro.domain.usecase.GetSongsInFolderUseCase
import com.musicplayer.pro.domain.usecase.GetSubFoldersUseCase
import com.musicplayer.pro.presentation.state.FoldersUiState
import com.musicplayer.pro.presentation.state.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel para la navegación de carpetas.
 * Gestiona la visualización y navegación de carpetas con archivos de audio.
 */
@HiltViewModel
class FoldersViewModel @Inject constructor(
    private val getAllFoldersUseCase: GetAllFoldersUseCase,
    private val getSubFoldersUseCase: GetSubFoldersUseCase,
    private val getSongsInFolderUseCase: GetSongsInFolderUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(FoldersUiState())
    val uiState: StateFlow<FoldersUiState> = _uiState.asStateFlow()

    private val _events = Channel<UiEvent>()
    val events = _events.receiveAsFlow()

    init {
        loadAllFolders()
    }

    /**
     * Carga todas las carpetas.
     */
    fun loadAllFolders() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, currentPath = null, pathHistory = emptyList()) }

            getAllFoldersUseCase()
                .catch { error ->
                    _uiState.update { 
                        it.copy(isLoading = false, error = error.message) 
                    }
                }
                .collectLatest { folders ->
                    _uiState.update { 
                        it.copy(
                            folders = folders,
                            isLoading = false,
                            error = null,
                            songsInCurrentFolder = emptyList()
                        ) 
                    }
                }
        }
    }

    /**
     * Navega a una carpeta específica.
     */
    fun navigateToFolder(folder: Folder) {
        navigateToPath(folder.path)
    }

    /**
     * Navega a una ruta específica.
     */
    fun navigateToPath(path: String) {
        viewModelScope.launch {
            _uiState.update { state ->
                val newHistory = if (state.currentPath != null) {
                    state.pathHistory + state.currentPath
                } else {
                    state.pathHistory
                }
                state.copy(
                    isLoading = true,
                    currentPath = path,
                    pathHistory = newHistory
                )
            }

            // Cargar subcarpetas
            loadSubFolders(path)
            
            // Cargar canciones en la carpeta
            loadSongsInFolder(path)
        }
    }

    /**
     * Carga las subcarpetas de una ruta.
     */
    private fun loadSubFolders(parentPath: String) {
        viewModelScope.launch {
            getSubFoldersUseCase(parentPath)
                .catch { error ->
                    _uiState.update { it.copy(error = error.message) }
                }
                .collectLatest { folders ->
                    _uiState.update { 
                        it.copy(folders = folders, isLoading = false) 
                    }
                }
        }
    }

    /**
     * Carga las canciones de una carpeta.
     */
    private fun loadSongsInFolder(folderPath: String) {
        viewModelScope.launch {
            getSongsInFolderUseCase(folderPath)
                .catch { error ->
                    _uiState.update { it.copy(error = error.message) }
                }
                .collectLatest { songs ->
                    _uiState.update { 
                        it.copy(songsInCurrentFolder = songs) 
                    }
                }
        }
    }

    /**
     * Navega hacia atrás en el historial de carpetas.
     */
    fun navigateBack(): Boolean {
        val currentState = _uiState.value
        
        if (currentState.pathHistory.isEmpty()) {
            // Estamos en la raíz, volver a la vista de todas las carpetas
            if (currentState.currentPath != null) {
                loadAllFolders()
                return true
            }
            return false
        }

        // Navegar a la carpeta anterior
        val previousPath = currentState.pathHistory.last()
        val newHistory = currentState.pathHistory.dropLast(1)

        _uiState.update { 
            it.copy(
                currentPath = previousPath,
                pathHistory = newHistory,
                isLoading = true
            )
        }

        loadSubFolders(previousPath)
        loadSongsInFolder(previousPath)

        return true
    }

    /**
     * Navega a la raíz.
     */
    fun navigateToRoot() {
        loadAllFolders()
    }

    /**
     * Obtiene las canciones de la carpeta actual.
     */
    fun getCurrentFolderSongs(): List<Song> {
        return _uiState.value.songsInCurrentFolder
    }

    /**
     * Verifica si estamos en la raíz.
     */
    fun isAtRoot(): Boolean {
        return _uiState.value.currentPath == null
    }

    /**
     * Obtiene la ruta actual.
     */
    fun getCurrentPath(): String? {
        return _uiState.value.currentPath
    }

    /**
     * Obtiene el nombre de la carpeta actual.
     */
    fun getCurrentFolderName(): String {
        val path = _uiState.value.currentPath ?: return "Carpetas"
        return path.substringAfterLast('/')
    }

    /**
     * Refresca la carpeta actual.
     */
    fun refresh() {
        val currentPath = _uiState.value.currentPath
        if (currentPath != null) {
            loadSubFolders(currentPath)
            loadSongsInFolder(currentPath)
        } else {
            loadAllFolders()
        }
    }

    /**
     * Limpia el error.
     */
    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}
