package com.musicplayer.pro.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.musicplayer.pro.data.local.entity.PlaylistEntity
import com.musicplayer.pro.data.local.entity.PlaylistSongCrossRef
import com.musicplayer.pro.data.local.entity.SongEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO para operaciones de base de datos relacionadas con playlists.
 */
@Dao
interface PlaylistDao {

    /**
     * Obtiene todas las playlists ordenadas por fecha de actualización.
     */
    @Query("SELECT * FROM playlists ORDER BY updated_at DESC")
    fun getAllPlaylists(): Flow<List<PlaylistEntity>>

    /**
     * Obtiene una playlist por su ID.
     */
    @Query("SELECT * FROM playlists WHERE id = :playlistId")
    suspend fun getPlaylistById(playlistId: Long): PlaylistEntity?

    /**
     * Obtiene una playlist por su ID como Flow.
     */
    @Query("SELECT * FROM playlists WHERE id = :playlistId")
    fun getPlaylistByIdFlow(playlistId: Long): Flow<PlaylistEntity?>

    /**
     * Busca playlists por nombre.
     */
    @Query("SELECT * FROM playlists WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchPlaylists(query: String): Flow<List<PlaylistEntity>>

    /**
     * Obtiene el conteo total de playlists.
     */
    @Query("SELECT COUNT(*) FROM playlists")
    suspend fun getPlaylistCount(): Int

    /**
     * Inserta una playlist.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    /**
     * Actualiza una playlist.
     */
    @Update
    suspend fun updatePlaylist(playlist: PlaylistEntity)

    /**
     * Actualiza el nombre de una playlist.
     */
    @Query("UPDATE playlists SET name = :name, updated_at = :updatedAt WHERE id = :playlistId")
    suspend fun updatePlaylistName(playlistId: Long, name: String, updatedAt: Long = System.currentTimeMillis())

    /**
     * Elimina una playlist.
     */
    @Delete
    suspend fun deletePlaylist(playlist: PlaylistEntity)

    /**
     * Elimina una playlist por su ID.
     */
    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylistById(playlistId: Long)

    // ==================== Playlist Songs ====================

    /**
     * Obtiene las canciones de una playlist ordenadas por posición.
     */
    @Query("""
        SELECT s.* FROM songs s
        INNER JOIN playlist_songs ps ON s.id = ps.song_id
        WHERE ps.playlist_id = :playlistId
        ORDER BY ps.position ASC
    """)
    fun getPlaylistSongs(playlistId: Long): Flow<List<SongEntity>>

    /**
     * Obtiene la posición máxima de canciones en una playlist.
     */
    @Query("SELECT COALESCE(MAX(position), -1) FROM playlist_songs WHERE playlist_id = :playlistId")
    suspend fun getMaxPosition(playlistId: Long): Int

    /**
     * Añade una canción a una playlist.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addSongToPlaylist(crossRef: PlaylistSongCrossRef)

    /**
     * Añade múltiples canciones a una playlist.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addSongsToPlaylist(crossRefs: List<PlaylistSongCrossRef>)

    /**
     * Elimina una canción de una playlist.
     */
    @Query("DELETE FROM playlist_songs WHERE playlist_id = :playlistId AND song_id = :songId")
    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long)

    /**
     * Elimina todas las canciones de una playlist.
     */
    @Query("DELETE FROM playlist_songs WHERE playlist_id = :playlistId")
    suspend fun removeAllSongsFromPlaylist(playlistId: Long)

    /**
     * Actualiza la posición de una canción en una playlist.
     */
    @Query("UPDATE playlist_songs SET position = :position WHERE playlist_id = :playlistId AND song_id = :songId")
    suspend fun updateSongPosition(playlistId: Long, songId: Long, position: Int)

    /**
     * Verifica si una canción está en una playlist.
     */
    @Query("SELECT EXISTS(SELECT 1 FROM playlist_songs WHERE playlist_id = :playlistId AND song_id = :songId)")
    suspend fun isSongInPlaylist(playlistId: Long, songId: Long): Boolean

    /**
     * Obtiene el conteo de canciones en una playlist.
     */
    @Query("SELECT COUNT(*) FROM playlist_songs WHERE playlist_id = :playlistId")
    suspend fun getPlaylistSongCount(playlistId: Long): Int

    /**
     * Actualiza los metadatos de una playlist (conteo y duración).
     */
    @Transaction
    @Query("""
        UPDATE playlists SET 
            song_count = (SELECT COUNT(*) FROM playlist_songs WHERE playlist_id = :playlistId),
            total_duration = (
                SELECT COALESCE(SUM(s.duration), 0) FROM songs s
                INNER JOIN playlist_songs ps ON s.id = ps.song_id
                WHERE ps.playlist_id = :playlistId
            ),
            updated_at = :updatedAt
        WHERE id = :playlistId
    """)
    suspend fun updatePlaylistMetadata(playlistId: Long, updatedAt: Long = System.currentTimeMillis())
}
