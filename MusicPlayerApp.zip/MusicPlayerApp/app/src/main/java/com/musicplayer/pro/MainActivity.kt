package com.musicplayer.pro

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import com.musicplayer.pro.presentation.screens.MainScreen
import com.musicplayer.pro.presentation.screens.PermissionScreen
import com.musicplayer.pro.presentation.theme.MusicPlayerTheme
import com.musicplayer.pro.presentation.viewmodel.MainViewModel
import dagger.hilt.android.AndroidEntryPoint

/**
 * Activity principal de la aplicación.
 * Maneja los permisos y muestra la UI principal.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()

    // Launcher para solicitar permisos
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        mainViewModel.onPermissionResult(isGranted)
        if (isGranted) {
            mainViewModel.scanMedia()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Splash screen
        installSplashScreen()
        
        super.onCreate(savedInstanceState)

        // Configurar edge-to-edge
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // Verificar permisos al inicio
        checkAndRequestPermission()

        setContent {
            MusicPlayerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val uiState by mainViewModel.uiState.collectAsState()

                    if (uiState.hasPermission) {
                        // Mostrar pantalla principal
                        MainScreen()
                    } else {
                        // Mostrar pantalla de solicitud de permisos
                        PermissionScreen(
                            onRequestPermission = { requestPermission() },
                            onOpenSettings = { openAppSettings() }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Verificar permisos cuando la app vuelve al primer plano
        // (por si el usuario los concedió desde configuración)
        if (hasAudioPermission()) {
            mainViewModel.onPermissionResult(true)
        }
    }

    /**
     * Verifica y solicita el permiso de audio.
     */
    private fun checkAndRequestPermission() {
        when {
            hasAudioPermission() -> {
                mainViewModel.onPermissionResult(true)
                mainViewModel.scanMedia()
            }
            shouldShowRequestPermissionRationale(getRequiredPermission()) -> {
                // El usuario ya denegó el permiso antes
                mainViewModel.onPermissionResult(false)
            }
            else -> {
                // Primera vez o puede volver a solicitar
                requestPermission()
            }
        }
    }

    /**
     * Solicita el permiso de audio.
     */
    private fun requestPermission() {
        permissionLauncher.launch(getRequiredPermission())
    }

    /**
     * Verifica si tiene el permiso de audio.
     */
    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            getRequiredPermission()
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Obtiene el permiso requerido según la versión de Android.
     */
    private fun getRequiredPermission(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    /**
     * Abre la configuración de la aplicación.
     */
    private fun openAppSettings() {
        val intent = android.content.Intent(
            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            android.net.Uri.fromParts("package", packageName, null)
        )
        startActivity(intent)
    }
}
