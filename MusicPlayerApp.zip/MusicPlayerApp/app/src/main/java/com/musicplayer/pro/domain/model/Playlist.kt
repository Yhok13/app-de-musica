package com.musicplayer.pro.domain.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Modelo de dominio que representa una playlist.
 */
data class Playlist(
    val id: Long,
    val name: String,
    val description: String?,
    val coverArtUri: String?,
    val songCount: Int,
    val totalDuration: Long,
    val createdAt: Long,
    val updatedAt: Long
) {
    /**
     * Duración total formateada.
     */
    val formattedDuration: String
        get() {
            val totalSeconds = totalDuration / 1000
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60

            return when {
                hours > 0 -> "$hours h $minutes min"
                minutes > 0 -> "$minutes min"
                else -> "0 min"
            }
        }

    /**
     * Fecha de creación formateada.
     */
    val formattedCreatedAt: String
        get() {
            val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            return dateFormat.format(Date(createdAt))
        }

    /**
     * Fecha de última actualización formateada.
     */
    val formattedUpdatedAt: String
        get() {
            val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            return dateFormat.format(Date(updatedAt))
        }

    /**
     * Descripción del contenido.
     */
    val contentDescription: String
        get() = if (songCount == 1) "1 canción" else "$songCount canciones"

    /**
     * Información completa (canciones y duración).
     */
    val fullInfo: String
        get() = "$contentDescription • $formattedDuration"

    /**
     * Verifica si la playlist está vacía.
     */
    val isEmpty: Boolean
        get() = songCount == 0

    companion object {
        /**
         * Crea una playlist vacía/placeholder.
         */
        fun empty() = Playlist(
            id = 0,
            name = "",
            description = null,
            coverArtUri = null,
            songCount = 0,
            totalDuration = 0,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
    }
}
