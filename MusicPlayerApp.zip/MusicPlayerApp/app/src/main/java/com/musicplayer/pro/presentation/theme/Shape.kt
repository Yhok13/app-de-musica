package com.musicplayer.pro.presentation.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/**
 * Formas personalizadas para la aplicación.
 */
val Shapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

/**
 * Formas adicionales para componentes específicos.
 */
object CustomShapes {
    // Botón de reproducción circular
    val PlayButton = CircleShape
    
    // Carátula de álbum con esquinas redondeadas
    val AlbumArt = RoundedCornerShape(16.dp)
    
    // Carátula pequeña
    val AlbumArtSmall = RoundedCornerShape(8.dp)
    
    // Tarjeta de canción
    val SongCard = RoundedCornerShape(12.dp)
    
    // Bottom sheet
    val BottomSheet = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    
    // Mini player
    val MiniPlayer = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    
    // Chip/Tag
    val Chip = RoundedCornerShape(8.dp)
    
    // Barra de progreso
    val ProgressBar = RoundedCornerShape(4.dp)
    
    // Botón de control
    val ControlButton = RoundedCornerShape(12.dp)
    
    // Diálogo
    val Dialog = RoundedCornerShape(28.dp)
    
    // Barra de búsqueda
    val SearchBar = RoundedCornerShape(28.dp)
    
    // Item de lista
    val ListItem = RoundedCornerShape(8.dp)
    
    // Botón FAB
    val FAB = RoundedCornerShape(16.dp)
}

/**
 * Elevaciones personalizadas.
 */
object Elevations {
    val None = 0.dp
    val ExtraSmall = 1.dp
    val Small = 2.dp
    val Medium = 4.dp
    val Large = 8.dp
    val ExtraLarge = 12.dp
}

/**
 * Tamaños estándar.
 */
object Sizes {
    // Carátulas
    val AlbumArtLarge = 300.dp
    val AlbumArtMedium = 180.dp
    val AlbumArtSmall = 56.dp
    val AlbumArtTiny = 40.dp
    
    // Botones de control
    val PlayButtonLarge = 72.dp
    val PlayButtonMedium = 56.dp
    val PlayButtonSmall = 48.dp
    val ControlButton = 48.dp
    val ControlButtonSmall = 40.dp
    
    // Iconos
    val IconLarge = 32.dp
    val IconMedium = 24.dp
    val IconSmall = 20.dp
    val IconTiny = 16.dp
    
    // Mini player
    val MiniPlayerHeight = 64.dp
    
    // Bottom navigation
    val BottomNavHeight = 80.dp
    
    // Barra de progreso
    val ProgressBarHeight = 4.dp
    val ProgressBarHeightLarge = 8.dp
    
    // Espaciado
    val PaddingTiny = 4.dp
    val PaddingSmall = 8.dp
    val PaddingMedium = 16.dp
    val PaddingLarge = 24.dp
    val PaddingExtraLarge = 32.dp
}
