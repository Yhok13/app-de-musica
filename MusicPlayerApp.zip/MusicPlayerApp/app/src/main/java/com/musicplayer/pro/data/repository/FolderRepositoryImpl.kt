package com.musicplayer.pro.data.repository

import com.musicplayer.pro.data.local.dao.FolderDao
import com.musicplayer.pro.data.local.dao.SongDao
import com.musicplayer.pro.data.local.entity.FolderEntity
import com.musicplayer.pro.di.IoDispatcher
import com.musicplayer.pro.domain.model.Folder
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.repository.FolderRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implementación del repositorio de carpetas.
 * Gestiona la navegación y acceso a carpetas con archivos de audio.
 */
@Singleton
class FolderRepositoryImpl @Inject constructor(
    private val folderDao: FolderDao,
    private val songDao: SongDao,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : FolderRepository {

    /**
     * Obtiene todas las carpetas.
     */
    override fun getAllFolders(): Flow<List<Folder>> {
        return folderDao.getAllFolders().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene las carpetas raíz (sin padre).
     */
    override fun getRootFolders(): Flow<List<Folder>> {
        return folderDao.getRootFolders().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene las subcarpetas de una carpeta padre.
     */
    override fun getSubFolders(parentPath: String): Flow<List<Folder>> {
        return folderDao.getSubFolders(parentPath).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene una carpeta por su ruta.
     */
    override suspend fun getFolderByPath(path: String): Folder? {
        return folderDao.getFolderByPath(path)?.toDomainModel()
    }

    /**
     * Obtiene una carpeta por su ID.
     */
    override suspend fun getFolderById(folderId: Long): Folder? {
        return folderDao.getFolderById(folderId)?.toDomainModel()
    }

    /**
     * Obtiene las canciones de una carpeta.
     */
    override fun getSongsInFolder(folderPath: String): Flow<List<Song>> {
        return songDao.getSongsByFolder(folderPath).map { entities ->
            entities.map { entity ->
                Song(
                    id = entity.id,
                    mediaStoreId = entity.mediaStoreId,
                    title = entity.title,
                    artist = entity.artist,
                    artistId = entity.artistId,
                    album = entity.album,
                    albumId = entity.albumId,
                    genre = entity.genre,
                    duration = entity.duration,
                    filePath = entity.filePath,
                    folderPath = entity.folderPath,
                    folderName = entity.folderName,
                    fileName = entity.fileName,
                    fileSize = entity.fileSize,
                    mimeType = entity.mimeType,
                    bitrate = entity.bitrate,
                    sampleRate = entity.sampleRate,
                    trackNumber = entity.trackNumber,
                    year = entity.year,
                    albumArtUri = entity.albumArtUri,
                    dateAdded = entity.dateAdded,
                    dateModified = entity.dateModified,
                    isFavorite = entity.isFavorite,
                    playCount = entity.playCount,
                    lastPlayed = entity.lastPlayed
                )
            }
        }
    }

    /**
     * Busca carpetas por nombre.
     */
    override fun searchFolders(query: String): Flow<List<Folder>> {
        return folderDao.searchFolders(query).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene el conteo total de carpetas.
     */
    override suspend fun getFolderCount(): Int {
        return folderDao.getFolderCount()
    }

    /**
     * Actualiza el conteo de canciones de una carpeta.
     */
    override suspend fun updateFolderSongCount(folderPath: String) = withContext(ioDispatcher) {
        // Contar canciones en la carpeta
        // Este método se puede mejorar con una consulta directa
        folderDao.getFolderByPath(folderPath)?.let { folder ->
            // El conteo se actualiza automáticamente durante el escaneo
        }
    }
}

/**
 * Extensión para convertir FolderEntity a modelo de dominio Folder.
 */
private fun FolderEntity.toDomainModel(): Folder {
    return Folder(
        id = id,
        path = path,
        name = name,
        parentPath = parentPath,
        songCount = songCount,
        totalSize = totalSize,
        lastModified = lastModified
    )
}
