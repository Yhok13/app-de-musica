package com.musicplayer.pro.presentation.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SearchBar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.domain.model.Album
import com.musicplayer.pro.domain.model.Artist
import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.presentation.components.SongItem
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.FavoritesViewModel
import com.musicplayer.pro.presentation.viewmodel.PlayerViewModel
import com.musicplayer.pro.presentation.viewmodel.SearchViewModel

/**
 * Pantalla de búsqueda global.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    onBackClick: () -> Unit,
    onSongClick: (Song) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onPlaylistClick: (Playlist) -> Unit,
    modifier: Modifier = Modifier,
    searchViewModel: SearchViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel(),
    favoritesViewModel: FavoritesViewModel = hiltViewModel()
) {
    val uiState by searchViewModel.uiState.collectAsState()
    val playerState by playerViewModel.uiState.collectAsState()
    val favoriteSongIds by favoritesViewModel.favoriteSongIds.collectAsState()
    
    var active by remember { mutableStateOf(true) }

    Scaffold(modifier = modifier) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Barra de búsqueda
            SearchBar(
                query = uiState.query,
                onQueryChange = { searchViewModel.search(it) },
                onSearch = { active = false },
                active = active,
                onActiveChange = { active = it },
                placeholder = { Text("Buscar canciones, álbumes, artistas...") },
                leadingIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Atrás"
                        )
                    }
                },
                trailingIcon = {
                    if (uiState.query.isNotEmpty()) {
                        IconButton(onClick = { searchViewModel.clearQuery() }) {
                            Icon(
                                imageVector = Icons.Filled.Clear,
                                contentDescription = "Limpiar"
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = if (active) 0.dp else Sizes.PaddingMedium)
            ) {
                // Resultados de búsqueda
                SearchResults(
                    songs = uiState.songs,
                    albums = uiState.albums,
                    artists = uiState.artists,
                    playlists = uiState.playlists,
                    isSearching = uiState.isSearching,
                    hasSearched = uiState.hasSearched,
                    query = uiState.query,
                    currentSongId = playerState.currentSong?.id,
                    favoriteSongIds = favoriteSongIds,
                    onSongClick = { song ->
                        playerViewModel.playSong(song)
                        onSongClick(song)
                    },
                    onAlbumClick = onAlbumClick,
                    onArtistClick = onArtistClick,
                    onPlaylistClick = onPlaylistClick,
                    onFavoriteClick = { songId ->
                        favoritesViewModel.toggleFavorite(songId)
                    }
                )
            }
        }
    }
}

/**
 * Resultados de búsqueda.
 */
@Composable
private fun SearchResults(
    songs: List<Song>,
    albums: List<Album>,
    artists: List<Artist>,
    playlists: List<Playlist>,
    isSearching: Boolean,
    hasSearched: Boolean,
    query: String,
    currentSongId: Long?,
    favoriteSongIds: Set<Long>,
    onSongClick: (Song) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onPlaylistClick: (Playlist) -> Unit,
    onFavoriteClick: (Long) -> Unit
) {
    val hasResults = songs.isNotEmpty() || albums.isNotEmpty() || 
                     artists.isNotEmpty() || playlists.isNotEmpty()

    when {
        isSearching -> {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                LoadingState()
            }
        }
        query.isEmpty() -> {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = null,
                        modifier = Modifier.padding(Sizes.PaddingMedium),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Text(
                        text = "Busca canciones, álbumes o artistas",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        hasSearched && !hasResults -> {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Sin resultados",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(Sizes.PaddingSmall))
                    Text(
                        text = "No se encontraron resultados para \"$query\"",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        else -> {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 120.dp)
            ) {
                // Canciones
                if (songs.isNotEmpty()) {
                    item {
                        SectionTitle(title = "Canciones (${songs.size})")
                    }
                    items(
                        items = songs.take(5),
                        key = { "song_${it.id}" }
                    ) { song ->
                        SongItem(
                            song = song,
                            onClick = { onSongClick(song) },
                            isPlaying = song.id == currentSongId,
                            isFavorite = song.id in favoriteSongIds,
                            onFavoriteClick = { onFavoriteClick(song.id) },
                            onMoreClick = { }
                        )
                    }
                }

                // Álbumes
                if (albums.isNotEmpty()) {
                    item {
                        SectionTitle(title = "Álbumes (${albums.size})")
                    }
                    items(
                        items = albums.take(5),
                        key = { "album_${it.id}" }
                    ) { album ->
                        SearchResultItem(
                            title = album.name,
                            subtitle = album.artist,
                            onClick = { onAlbumClick(album) }
                        )
                    }
                }

                // Artistas
                if (artists.isNotEmpty()) {
                    item {
                        SectionTitle(title = "Artistas (${artists.size})")
                    }
                    items(
                        items = artists.take(5),
                        key = { "artist_${it.id}" }
                    ) { artist ->
                        SearchResultItem(
                            title = artist.name,
                            subtitle = "${artist.songCount} canciones",
                            onClick = { onArtistClick(artist) }
                        )
                    }
                }

                // Playlists
                if (playlists.isNotEmpty()) {
                    item {
                        SectionTitle(title = "Playlists (${playlists.size})")
                    }
                    items(
                        items = playlists.take(5),
                        key = { "playlist_${it.id}" }
                    ) { playlist ->
                        SearchResultItem(
                            title = playlist.name,
                            subtitle = "${playlist.songCount} canciones",
                            onClick = { onPlaylistClick(playlist) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Título de sección.
 */
@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(
            horizontal = Sizes.PaddingMedium,
            vertical = Sizes.PaddingSmall
        )
    )
}

/**
 * Item de resultado de búsqueda genérico.
 */
@Composable
private fun SearchResultItem(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    androidx.compose.foundation.clickable(onClick = onClick) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Sizes.PaddingMedium, vertical = Sizes.PaddingSmall)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
