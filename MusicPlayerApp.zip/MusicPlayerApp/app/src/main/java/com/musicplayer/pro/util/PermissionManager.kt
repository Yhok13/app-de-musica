package com.musicplayer.pro.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gestor de permisos para la aplicación.
 * Maneja la lógica de solicitud y verificación de permisos de audio.
 */
@Singleton
class PermissionManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val _permissionState = MutableStateFlow(PermissionState.UNKNOWN)
    val permissionState: StateFlow<PermissionState> = _permissionState.asStateFlow()

    private val _hasAudioPermission = MutableStateFlow(false)
    val hasAudioPermission: StateFlow<Boolean> = _hasAudioPermission.asStateFlow()

    init {
        checkPermissions()
    }

    /**
     * Obtiene los permisos necesarios según la versión de Android.
     */
    fun getRequiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ (API 33+)
            arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10-12 (API 29-32)
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            // Android 9 y anteriores
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }
    }

    /**
     * Obtiene solo el permiso de audio necesario.
     */
    fun getAudioPermission(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    /**
     * Verifica si se tienen todos los permisos necesarios.
     */
    fun checkPermissions(): Boolean {
        val audioPermission = getAudioPermission()
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            audioPermission
        ) == PackageManager.PERMISSION_GRANTED

        _hasAudioPermission.value = hasPermission
        _permissionState.value = if (hasPermission) {
            PermissionState.GRANTED
        } else {
            PermissionState.DENIED
        }

        return hasPermission
    }

    /**
     * Verifica si se tiene el permiso de audio.
     */
    fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            getAudioPermission()
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Verifica si se tiene el permiso de notificaciones (Android 13+).
     */
    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    /**
     * Actualiza el estado del permiso después de la respuesta del usuario.
     */
    fun updatePermissionState(granted: Boolean) {
        _hasAudioPermission.value = granted
        _permissionState.value = if (granted) {
            PermissionState.GRANTED
        } else {
            PermissionState.DENIED
        }
    }

    /**
     * Marca que el permiso fue denegado permanentemente.
     */
    fun setPermissionPermanentlyDenied() {
        _permissionState.value = PermissionState.PERMANENTLY_DENIED
    }

    /**
     * Crea un intent para abrir la configuración de la app.
     */
    fun createSettingsIntent(): Intent {
        return Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    /**
     * Verifica si se necesita mostrar el rationale del permiso.
     */
    fun shouldShowRationale(activity: android.app.Activity): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            activity.shouldShowRequestPermissionRationale(getAudioPermission())
        } else {
            false
        }
    }

    /**
     * Reinicia el estado del permiso para volver a verificar.
     */
    fun resetPermissionState() {
        checkPermissions()
    }
}

/**
 * Estados posibles del permiso.
 */
enum class PermissionState {
    UNKNOWN,            // Estado inicial, no verificado
    GRANTED,            // Permiso concedido
    DENIED,             // Permiso denegado (puede volver a solicitarse)
    PERMANENTLY_DENIED  // Permiso denegado permanentemente (debe ir a configuración)
}
