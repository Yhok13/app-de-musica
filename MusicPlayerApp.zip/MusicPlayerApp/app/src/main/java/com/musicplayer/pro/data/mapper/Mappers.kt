package com.musicplayer.pro.data.mapper

import com.musicplayer.pro.data.local.entity.AlbumEntity
import com.musicplayer.pro.data.local.entity.ArtistEntity
import com.musicplayer.pro.data.local.entity.FolderEntity
import com.musicplayer.pro.data.local.entity.PlaylistEntity
import com.musicplayer.pro.data.local.entity.SongEntity
import com.musicplayer.pro.domain.model.Album
import com.musicplayer.pro.domain.model.Artist
import com.musicplayer.pro.domain.model.Folder
import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.domain.model.Song

/**
 * Mappers para convertir entre entidades de Room y modelos de dominio.
 */

// ==================== Song Mappers ====================

fun SongEntity.toDomain(): Song {
    return Song(
        id = id,
        mediaStoreId = mediaStoreId,
        title = title,
        artist = artist,
        artistId = artistId,
        album = album,
        albumId = albumId,
        genre = genre,
        duration = duration,
        filePath = filePath,
        folderPath = folderPath,
        folderName = folderName,
        fileName = fileName,
        fileSize = fileSize,
        mimeType = mimeType,
        bitrate = bitrate,
        sampleRate = sampleRate,
        trackNumber = trackNumber,
        year = year,
        albumArtUri = albumArtUri,
        dateAdded = dateAdded,
        dateModified = dateModified,
        isFavorite = isFavorite,
        playCount = playCount,
        lastPlayed = lastPlayed
    )
}

fun Song.toEntity(): SongEntity {
    return SongEntity(
        id = id,
        mediaStoreId = mediaStoreId,
        title = title,
        artist = artist,
        artistId = artistId,
        album = album,
        albumId = albumId,
        genre = genre,
        duration = duration,
        filePath = filePath,
        folderPath = folderPath,
        folderName = folderName,
        fileName = fileName,
        fileSize = fileSize,
        mimeType = mimeType,
        bitrate = bitrate,
        sampleRate = sampleRate,
        trackNumber = trackNumber,
        year = year,
        albumArtUri = albumArtUri,
        dateAdded = dateAdded,
        dateModified = dateModified,
        isFavorite = isFavorite,
        playCount = playCount,
        lastPlayed = lastPlayed
    )
}

fun List<SongEntity>.toDomainSongs(): List<Song> = map { it.toDomain() }
fun List<Song>.toSongEntities(): List<SongEntity> = map { it.toEntity() }

// ==================== Album Mappers ====================

fun AlbumEntity.toDomain(): Album {
    return Album(
        id = id,
        mediaStoreId = mediaStoreId,
        name = name,
        artist = artist,
        artistId = artistId,
        songCount = songCount,
        year = year,
        albumArtUri = albumArtUri,
        totalDuration = totalDuration
    )
}

fun Album.toEntity(): AlbumEntity {
    return AlbumEntity(
        id = id,
        mediaStoreId = mediaStoreId,
        name = name,
        artist = artist,
        artistId = artistId,
        songCount = songCount,
        year = year,
        albumArtUri = albumArtUri,
        totalDuration = totalDuration
    )
}

fun List<AlbumEntity>.toDomainAlbums(): List<Album> = map { it.toDomain() }
fun List<Album>.toAlbumEntities(): List<AlbumEntity> = map { it.toEntity() }

// ==================== Artist Mappers ====================

fun ArtistEntity.toDomain(): Artist {
    return Artist(
        id = id,
        mediaStoreId = mediaStoreId,
        name = name,
        songCount = songCount,
        albumCount = albumCount,
        albumArtUri = albumArtUri
    )
}

fun Artist.toEntity(): ArtistEntity {
    return ArtistEntity(
        id = id,
        mediaStoreId = mediaStoreId,
        name = name,
        songCount = songCount,
        albumCount = albumCount,
        albumArtUri = albumArtUri
    )
}

fun List<ArtistEntity>.toDomainArtists(): List<Artist> = map { it.toDomain() }
fun List<Artist>.toArtistEntities(): List<ArtistEntity> = map { it.toEntity() }

// ==================== Folder Mappers ====================

fun FolderEntity.toDomain(): Folder {
    return Folder(
        id = id,
        path = path,
        name = name,
        parentPath = parentPath,
        songCount = songCount,
        totalSize = totalSize,
        lastModified = lastModified
    )
}

fun Folder.toEntity(): FolderEntity {
    return FolderEntity(
        id = id,
        path = path,
        name = name,
        parentPath = parentPath,
        songCount = songCount,
        totalSize = totalSize,
        lastModified = lastModified
    )
}

fun List<FolderEntity>.toDomainFolders(): List<Folder> = map { it.toDomain() }
fun List<Folder>.toFolderEntities(): List<FolderEntity> = map { it.toEntity() }

// ==================== Playlist Mappers ====================

fun PlaylistEntity.toDomain(): Playlist {
    return Playlist(
        id = id,
        name = name,
        description = description,
        coverArtUri = coverArtUri,
        songCount = songCount,
        totalDuration = totalDuration,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}

fun Playlist.toEntity(): PlaylistEntity {
    return PlaylistEntity(
        id = id,
        name = name,
        description = description,
        coverArtUri = coverArtUri,
        songCount = songCount,
        totalDuration = totalDuration,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}

fun List<PlaylistEntity>.toDomainPlaylists(): List<Playlist> = map { it.toDomain() }
fun List<Playlist>.toPlaylistEntities(): List<PlaylistEntity> = map { it.toEntity() }
