package com.musicplayer.pro.domain.usecase

import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.repository.AudioRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

/**
 * Caso de uso para obtener todas las canciones.
 */
class GetAllSongsUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(): Flow<List<Song>> = audioRepository.getAllSongs()
}

/**
 * Caso de uso para obtener canciones ordenadas por fecha de adición.
 */
class GetSongsByDateAddedUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(): Flow<List<Song>> = audioRepository.getAllSongsByDateAdded()
}

/**
 * Caso de uso para obtener una canción por ID.
 */
class GetSongByIdUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    suspend operator fun invoke(songId: Long): Song? = audioRepository.getSongById(songId)
}

/**
 * Caso de uso para obtener canciones por álbum.
 */
class GetSongsByAlbumUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(albumId: Long): Flow<List<Song>> = audioRepository.getSongsByAlbum(albumId)
}

/**
 * Caso de uso para obtener canciones por artista.
 */
class GetSongsByArtistUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(artistId: Long): Flow<List<Song>> = audioRepository.getSongsByArtist(artistId)
}

/**
 * Caso de uso para obtener canciones por carpeta.
 */
class GetSongsByFolderUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(folderPath: String): Flow<List<Song>> = audioRepository.getSongsByFolder(folderPath)
}

/**
 * Caso de uso para buscar canciones.
 */
class SearchSongsUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(query: String): Flow<List<Song>> = audioRepository.searchSongs(query)
}

/**
 * Caso de uso para obtener canciones más reproducidas.
 */
class GetMostPlayedSongsUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(limit: Int = 50): Flow<List<Song>> = audioRepository.getMostPlayedSongs(limit)
}

/**
 * Caso de uso para obtener canciones reproducidas recientemente.
 */
class GetRecentlyPlayedSongsUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(limit: Int = 50): Flow<List<Song>> = audioRepository.getRecentlyPlayedSongs(limit)
}

/**
 * Caso de uso para incrementar el contador de reproducciones.
 */
class IncrementPlayCountUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    suspend operator fun invoke(songId: Long) = audioRepository.incrementPlayCount(songId)
}

/**
 * Caso de uso para escanear y sincronizar la biblioteca de música.
 */
class ScanMediaUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    suspend operator fun invoke(): Result<Int> = audioRepository.scanAndSyncLibrary()
}

/**
 * Caso de uso para obtener el conteo de canciones.
 */
class GetSongCountUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    suspend operator fun invoke(): Int = audioRepository.getSongCount()
}

/**
 * Caso de uso para eliminar una canción.
 */
class DeleteSongUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    suspend operator fun invoke(songId: Long) = audioRepository.deleteSong(songId)
}
