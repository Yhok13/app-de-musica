package com.musicplayer.pro.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.musicplayer.pro.domain.model.Artist
import com.musicplayer.pro.presentation.theme.CustomShapes
import com.musicplayer.pro.presentation.theme.PlaceholderGradients
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.LibraryViewModel

/**
 * Pantalla de artistas.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArtistsScreen(
    onArtistClick: (Artist) -> Unit,
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: LibraryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()

    Scaffold(
        modifier = modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "Artistas")
                        if (uiState.artists.isNotEmpty()) {
                            Text(
                                text = "${uiState.artists.size} artistas",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onSearchClick) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "Buscar"
                        )
                    }
                },
                scrollBehavior = scrollBehavior
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                uiState.isLoading -> {
                    LoadingState()
                }
                uiState.artists.isEmpty() -> {
                    EmptyState(
                        icon = Icons.Filled.Person,
                        title = "No hay artistas",
                        message = "No se encontraron artistas en tu dispositivo"
                    )
                }
                else -> {
                    ArtistsList(
                        artists = uiState.artists,
                        onArtistClick = onArtistClick
                    )
                }
            }
        }
    }
}

/**
 * Lista de artistas.
 */
@Composable
private fun ArtistsList(
    artists: List<Artist>,
    onArtistClick: (Artist) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(
            top = Sizes.PaddingSmall,
            bottom = 120.dp
        )
    ) {
        items(
            items = artists,
            key = { it.id }
        ) { artist ->
            ArtistItem(
                artist = artist,
                onClick = { onArtistClick(artist) }
            )
        }
    }
}

/**
 * Item de artista.
 */
@Composable
private fun ArtistItem(
    artist: Artist,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val gradientColors = PlaceholderGradients.getGradient(artist.name.hashCode())

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = Sizes.PaddingMedium, vertical = Sizes.PaddingSmall),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar del artista
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
        ) {
            if (artist.albumArtUri != null) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(artist.albumArtUri)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Imagen de ${artist.name}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // Placeholder con gradiente
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.linearGradient(colors = gradientColors)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f),
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(Sizes.PaddingMedium))

        // Información del artista
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = artist.name,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            
            Text(
                text = buildString {
                    append("${artist.songCount} canciones")
                    if (artist.albumCount > 0) {
                        append(" • ${artist.albumCount} álbumes")
                    }
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Pantalla de detalle de artista.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArtistDetailScreen(
    artistId: Long,
    onBackClick: () -> Unit,
    onAlbumClick: (com.musicplayer.pro.domain.model.Album) -> Unit,
    onSongClick: (com.musicplayer.pro.domain.model.Song) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: LibraryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val artist = uiState.artists.find { it.id == artistId }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(artist?.name ?: "Artista") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Atrás"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Header del artista
            if (artist != null) {
                ArtistHeader(artist = artist)
            }
            
            // Álbumes y canciones del artista
            // ... (implementar contenido)
        }
    }
}

/**
 * Header del artista.
 */
@Composable
private fun ArtistHeader(artist: Artist) {
    val gradientColors = PlaceholderGradients.getGradient(artist.name.hashCode())

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(Sizes.PaddingMedium),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Avatar grande
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(
                    brush = Brush.linearGradient(colors = gradientColors)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (artist.albumArtUri != null) {
                AsyncImage(
                    model = artist.albumArtUri,
                    contentDescription = "Imagen de ${artist.name}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f),
                    modifier = Modifier.size(60.dp)
                )
            }
        }
        
        Spacer(modifier = Modifier.height(Sizes.PaddingMedium))
        
        Text(
            text = artist.name,
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
        
        Text(
            text = "${artist.songCount} canciones • ${artist.albumCount} álbumes",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// Import necesario
import androidx.compose.material.icons.filled.ArrowBack
