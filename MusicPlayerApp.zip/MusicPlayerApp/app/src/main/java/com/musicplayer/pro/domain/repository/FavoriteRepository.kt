package com.musicplayer.pro.domain.repository

import com.musicplayer.pro.domain.model.Song
import kotlinx.coroutines.flow.Flow

/**
 * Interfaz del repositorio de favoritos.
 * Define las operaciones para gestionar canciones favoritas.
 */
interface FavoriteRepository {

    /**
     * Obtiene todas las canciones favoritas.
     */
    fun getAllFavorites(): Flow<List<Song>>

    /**
     * Verifica si una canción es favorita.
     */
    suspend fun isFavorite(songId: Long): Boolean

    /**
     * Verifica si una canción es favorita (Flow).
     */
    fun isFavoriteFlow(songId: Long): Flow<Boolean>

    /**
     * Añade una canción a favoritos.
     */
    suspend fun addToFavorites(songId: Long)

    /**
     * Elimina una canción de favoritos.
     */
    suspend fun removeFromFavorites(songId: Long)

    /**
     * Alterna el estado de favorito de una canción.
     * @return true si ahora es favorita, false si se quitó de favoritos.
     */
    suspend fun toggleFavorite(songId: Long): Boolean

    /**
     * Obtiene el conteo total de favoritos.
     */
    suspend fun getFavoriteCount(): Int

    /**
     * Obtiene el conteo total de favoritos (Flow).
     */
    fun getFavoriteCountFlow(): Flow<Int>

    /**
     * Obtiene los IDs de todas las canciones favoritas.
     */
    suspend fun getAllFavoriteSongIds(): List<Long>

    /**
     * Obtiene los IDs de todas las canciones favoritas (Flow).
     */
    fun getAllFavoriteSongIdsFlow(): Flow<List<Long>>
}
