package com.musicplayer.pro.domain.model

/**
 * Modelo de dominio que representa un álbum.
 */
data class Album(
    val id: Long,
    val mediaStoreId: Long,
    val name: String,
    val artist: String,
    val artistId: Long,
    val songCount: Int,
    val year: Int?,
    val albumArtUri: String?,
    val totalDuration: Long = 0
) {
    /**
     * Duración total formateada.
     */
    val formattedDuration: String
        get() {
            val totalSeconds = totalDuration / 1000
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60

            return if (hours > 0) {
                "$hours h $minutes min"
            } else {
                "$minutes min"
            }
        }

    /**
     * Información del álbum (artista y año).
     */
    val albumInfo: String
        get() = if (year != null) "$artist • $year" else artist

    /**
     * Descripción del contenido (número de canciones).
     */
    val contentDescription: String
        get() = if (songCount == 1) "1 canción" else "$songCount canciones"

    companion object {
        /**
         * Crea un álbum vacío/placeholder.
         */
        fun empty() = Album(
            id = 0,
            mediaStoreId = 0,
            name = "",
            artist = "",
            artistId = 0,
            songCount = 0,
            year = null,
            albumArtUri = null
        )
    }
}
