package com.musicplayer.pro.domain.usecase

import com.musicplayer.pro.domain.model.Album
import com.musicplayer.pro.domain.model.Artist
import com.musicplayer.pro.domain.model.Folder
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.repository.AudioRepository
import com.musicplayer.pro.domain.repository.FolderRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

// ==================== Álbumes ====================

/**
 * Caso de uso para obtener todos los álbumes.
 */
class GetAllAlbumsUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(): Flow<List<Album>> = audioRepository.getAllAlbums()
}

/**
 * Caso de uso para obtener un álbum por ID.
 */
class GetAlbumByIdUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    suspend operator fun invoke(albumId: Long): Album? = audioRepository.getAlbumById(albumId)
}

/**
 * Caso de uso para obtener álbumes por artista.
 */
class GetAlbumsByArtistUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(artistId: Long): Flow<List<Album>> = audioRepository.getAlbumsByArtist(artistId)
}

/**
 * Caso de uso para buscar álbumes.
 */
class SearchAlbumsUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(query: String): Flow<List<Album>> = audioRepository.searchAlbums(query)
}

// ==================== Artistas ====================

/**
 * Caso de uso para obtener todos los artistas.
 */
class GetAllArtistsUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(): Flow<List<Artist>> = audioRepository.getAllArtists()
}

/**
 * Caso de uso para obtener un artista por ID.
 */
class GetArtistByIdUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    suspend operator fun invoke(artistId: Long): Artist? = audioRepository.getArtistById(artistId)
}

/**
 * Caso de uso para buscar artistas.
 */
class SearchArtistsUseCase @Inject constructor(
    private val audioRepository: AudioRepository
) {
    operator fun invoke(query: String): Flow<List<Artist>> = audioRepository.searchArtists(query)
}

// ==================== Carpetas ====================

/**
 * Caso de uso para obtener todas las carpetas.
 */
class GetAllFoldersUseCase @Inject constructor(
    private val folderRepository: FolderRepository
) {
    operator fun invoke(): Flow<List<Folder>> = folderRepository.getAllFolders()
}

/**
 * Caso de uso para obtener carpetas raíz.
 */
class GetRootFoldersUseCase @Inject constructor(
    private val folderRepository: FolderRepository
) {
    operator fun invoke(): Flow<List<Folder>> = folderRepository.getRootFolders()
}

/**
 * Caso de uso para obtener subcarpetas.
 */
class GetSubFoldersUseCase @Inject constructor(
    private val folderRepository: FolderRepository
) {
    operator fun invoke(parentPath: String): Flow<List<Folder>> = folderRepository.getSubFolders(parentPath)
}

/**
 * Caso de uso para obtener una carpeta por ruta.
 */
class GetFolderByPathUseCase @Inject constructor(
    private val folderRepository: FolderRepository
) {
    suspend operator fun invoke(path: String): Folder? = folderRepository.getFolderByPath(path)
}

/**
 * Caso de uso para obtener canciones de una carpeta.
 */
class GetSongsInFolderUseCase @Inject constructor(
    private val folderRepository: FolderRepository
) {
    operator fun invoke(folderPath: String): Flow<List<Song>> = folderRepository.getSongsInFolder(folderPath)
}

/**
 * Caso de uso para buscar carpetas.
 */
class SearchFoldersUseCase @Inject constructor(
    private val folderRepository: FolderRepository
) {
    operator fun invoke(query: String): Flow<List<Folder>> = folderRepository.searchFolders(query)
}
