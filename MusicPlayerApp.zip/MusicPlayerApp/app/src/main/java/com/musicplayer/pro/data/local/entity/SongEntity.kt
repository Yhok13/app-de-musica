package com.musicplayer.pro.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entidad Room que representa una canción en la base de datos local.
 * Almacena todos los metadatos extraídos de MediaStore.
 */
@Entity(
    tableName = "songs",
    indices = [
        Index(value = ["media_store_id"], unique = true),
        Index(value = ["album_id"]),
        Index(value = ["artist_id"]),
        Index(value = ["folder_path"])
    ]
)
data class SongEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "media_store_id")
    val mediaStoreId: Long,

    @ColumnInfo(name = "title")
    val title: String,

    @ColumnInfo(name = "artist")
    val artist: String,

    @ColumnInfo(name = "artist_id")
    val artistId: Long,

    @ColumnInfo(name = "album")
    val album: String,

    @ColumnInfo(name = "album_id")
    val albumId: Long,

    @ColumnInfo(name = "genre")
    val genre: String?,

    @ColumnInfo(name = "duration")
    val duration: Long,

    @ColumnInfo(name = "file_path")
    val filePath: String,

    @ColumnInfo(name = "folder_path")
    val folderPath: String,

    @ColumnInfo(name = "folder_name")
    val folderName: String,

    @ColumnInfo(name = "file_name")
    val fileName: String,

    @ColumnInfo(name = "file_size")
    val fileSize: Long,

    @ColumnInfo(name = "mime_type")
    val mimeType: String,

    @ColumnInfo(name = "bitrate")
    val bitrate: Int?,

    @ColumnInfo(name = "sample_rate")
    val sampleRate: Int?,

    @ColumnInfo(name = "track_number")
    val trackNumber: Int?,

    @ColumnInfo(name = "year")
    val year: Int?,

    @ColumnInfo(name = "album_art_uri")
    val albumArtUri: String?,

    @ColumnInfo(name = "date_added")
    val dateAdded: Long,

    @ColumnInfo(name = "date_modified")
    val dateModified: Long,

    @ColumnInfo(name = "is_favorite")
    val isFavorite: Boolean = false,

    @ColumnInfo(name = "play_count")
    val playCount: Int = 0,

    @ColumnInfo(name = "last_played")
    val lastPlayed: Long? = null
)
