package com.musicplayer.pro.data.repository

import com.musicplayer.pro.data.local.dao.FavoriteDao
import com.musicplayer.pro.data.local.dao.SongDao
import com.musicplayer.pro.data.local.entity.FavoriteEntity
import com.musicplayer.pro.di.IoDispatcher
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.repository.FavoriteRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implementación del repositorio de favoritos.
 * Gestiona las canciones marcadas como favoritas.
 */
@Singleton
class FavoriteRepositoryImpl @Inject constructor(
    private val favoriteDao: FavoriteDao,
    private val songDao: SongDao,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : FavoriteRepository {

    /**
     * Obtiene todas las canciones favoritas.
     */
    override fun getAllFavorites(): Flow<List<Song>> {
        return favoriteDao.getAllFavorites().map { entities ->
            entities.map { entity ->
                Song(
                    id = entity.id,
                    mediaStoreId = entity.mediaStoreId,
                    title = entity.title,
                    artist = entity.artist,
                    artistId = entity.artistId,
                    album = entity.album,
                    albumId = entity.albumId,
                    genre = entity.genre,
                    duration = entity.duration,
                    filePath = entity.filePath,
                    folderPath = entity.folderPath,
                    folderName = entity.folderName,
                    fileName = entity.fileName,
                    fileSize = entity.fileSize,
                    mimeType = entity.mimeType,
                    bitrate = entity.bitrate,
                    sampleRate = entity.sampleRate,
                    trackNumber = entity.trackNumber,
                    year = entity.year,
                    albumArtUri = entity.albumArtUri,
                    dateAdded = entity.dateAdded,
                    dateModified = entity.dateModified,
                    isFavorite = true,
                    playCount = entity.playCount,
                    lastPlayed = entity.lastPlayed
                )
            }
        }
    }

    /**
     * Verifica si una canción es favorita.
     */
    override suspend fun isFavorite(songId: Long): Boolean {
        return favoriteDao.isFavorite(songId)
    }

    /**
     * Verifica si una canción es favorita (Flow).
     */
    override fun isFavoriteFlow(songId: Long): Flow<Boolean> {
        return favoriteDao.isFavoriteFlow(songId)
    }

    /**
     * Añade una canción a favoritos.
     */
    override suspend fun addToFavorites(songId: Long) = withContext(ioDispatcher) {
        val favorite = FavoriteEntity(songId = songId)
        favoriteDao.addToFavorites(favorite)
        songDao.updateFavoriteStatus(songId, true)
    }

    /**
     * Elimina una canción de favoritos.
     */
    override suspend fun removeFromFavorites(songId: Long) = withContext(ioDispatcher) {
        favoriteDao.removeFromFavorites(songId)
        songDao.updateFavoriteStatus(songId, false)
    }

    /**
     * Alterna el estado de favorito de una canción.
     */
    override suspend fun toggleFavorite(songId: Long): Boolean = withContext(ioDispatcher) {
        val isFavorite = favoriteDao.isFavorite(songId)
        if (isFavorite) {
            removeFromFavorites(songId)
            false
        } else {
            addToFavorites(songId)
            true
        }
    }

    /**
     * Obtiene el conteo total de favoritos.
     */
    override suspend fun getFavoriteCount(): Int {
        return favoriteDao.getFavoriteCount()
    }

    /**
     * Obtiene el conteo total de favoritos (Flow).
     */
    override fun getFavoriteCountFlow(): Flow<Int> {
        return favoriteDao.getFavoriteCountFlow()
    }

    /**
     * Obtiene los IDs de todas las canciones favoritas.
     */
    override suspend fun getAllFavoriteSongIds(): List<Long> {
        return favoriteDao.getAllFavoriteSongIds()
    }

    /**
     * Obtiene los IDs de todas las canciones favoritas (Flow).
     */
    override fun getAllFavoriteSongIdsFlow(): Flow<List<Long>> {
        return favoriteDao.getAllFavoriteSongIdsFlow()
    }
}
