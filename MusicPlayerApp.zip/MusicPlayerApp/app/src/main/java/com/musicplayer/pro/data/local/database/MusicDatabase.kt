package com.musicplayer.pro.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.musicplayer.pro.data.local.dao.AlbumDao
import com.musicplayer.pro.data.local.dao.ArtistDao
import com.musicplayer.pro.data.local.dao.FavoriteDao
import com.musicplayer.pro.data.local.dao.FolderDao
import com.musicplayer.pro.data.local.dao.GenreDao
import com.musicplayer.pro.data.local.dao.PlaylistDao
import com.musicplayer.pro.data.local.dao.SongDao
import com.musicplayer.pro.data.local.entity.AlbumEntity
import com.musicplayer.pro.data.local.entity.ArtistEntity
import com.musicplayer.pro.data.local.entity.FavoriteEntity
import com.musicplayer.pro.data.local.entity.FolderEntity
import com.musicplayer.pro.data.local.entity.GenreEntity
import com.musicplayer.pro.data.local.entity.PlaylistEntity
import com.musicplayer.pro.data.local.entity.PlaylistSongCrossRef
import com.musicplayer.pro.data.local.entity.SongEntity

/**
 * Base de datos Room principal de la aplicación.
 * Contiene todas las tablas necesarias para almacenar la biblioteca musical.
 */
@Database(
    entities = [
        SongEntity::class,
        AlbumEntity::class,
        ArtistEntity::class,
        GenreEntity::class,
        FolderEntity::class,
        PlaylistEntity::class,
        PlaylistSongCrossRef::class,
        FavoriteEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class MusicDatabase : RoomDatabase() {

    /**
     * DAO para operaciones con canciones.
     */
    abstract fun songDao(): SongDao

    /**
     * DAO para operaciones con álbumes.
     */
    abstract fun albumDao(): AlbumDao

    /**
     * DAO para operaciones con artistas.
     */
    abstract fun artistDao(): ArtistDao

    /**
     * DAO para operaciones con géneros.
     */
    abstract fun genreDao(): GenreDao

    /**
     * DAO para operaciones con carpetas.
     */
    abstract fun folderDao(): FolderDao

    /**
     * DAO para operaciones con playlists.
     */
    abstract fun playlistDao(): PlaylistDao

    /**
     * DAO para operaciones con favoritos.
     */
    abstract fun favoriteDao(): FavoriteDao

    companion object {
        const val DATABASE_NAME = "music_player_database"
    }
}
