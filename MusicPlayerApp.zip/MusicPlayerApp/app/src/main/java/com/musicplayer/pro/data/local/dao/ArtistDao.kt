package com.musicplayer.pro.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.musicplayer.pro.data.local.entity.ArtistEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO para operaciones de base de datos relacionadas con artistas.
 */
@Dao
interface ArtistDao {

    /**
     * Obtiene todos los artistas ordenados por nombre.
     */
    @Query("SELECT * FROM artists ORDER BY name ASC")
    fun getAllArtists(): Flow<List<ArtistEntity>>

    /**
     * Obtiene un artista por su ID.
     */
    @Query("SELECT * FROM artists WHERE id = :artistId")
    suspend fun getArtistById(artistId: Long): ArtistEntity?

    /**
     * Obtiene un artista por su ID de MediaStore.
     */
    @Query("SELECT * FROM artists WHERE media_store_id = :mediaStoreId")
    suspend fun getArtistByMediaStoreId(mediaStoreId: Long): ArtistEntity?

    /**
     * Busca artistas por nombre.
     */
    @Query("SELECT * FROM artists WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchArtists(query: String): Flow<List<ArtistEntity>>

    /**
     * Obtiene el conteo total de artistas.
     */
    @Query("SELECT COUNT(*) FROM artists")
    suspend fun getArtistCount(): Int

    /**
     * Inserta un artista.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArtist(artist: ArtistEntity): Long

    /**
     * Inserta múltiples artistas.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArtists(artists: List<ArtistEntity>)

    /**
     * Actualiza un artista.
     */
    @Update
    suspend fun updateArtist(artist: ArtistEntity)

    /**
     * Elimina un artista.
     */
    @Delete
    suspend fun deleteArtist(artist: ArtistEntity)

    /**
     * Elimina todos los artistas.
     */
    @Query("DELETE FROM artists")
    suspend fun deleteAllArtists()

    /**
     * Obtiene todos los IDs de MediaStore existentes.
     */
    @Query("SELECT media_store_id FROM artists")
    suspend fun getAllMediaStoreIds(): List<Long>
}
