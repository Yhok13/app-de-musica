package com.musicplayer.pro.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.usecase.AddSongToPlaylistUseCase
import com.musicplayer.pro.domain.usecase.AddSongsToPlaylistUseCase
import com.musicplayer.pro.domain.usecase.CreatePlaylistUseCase
import com.musicplayer.pro.domain.usecase.DeletePlaylistUseCase
import com.musicplayer.pro.domain.usecase.GetAllPlaylistsUseCase
import com.musicplayer.pro.domain.usecase.GetPlaylistByIdUseCase
import com.musicplayer.pro.domain.usecase.GetPlaylistSongsUseCase
import com.musicplayer.pro.domain.usecase.RemoveSongFromPlaylistUseCase
import com.musicplayer.pro.domain.usecase.ReorderPlaylistSongsUseCase
import com.musicplayer.pro.domain.usecase.UpdatePlaylistNameUseCase
import com.musicplayer.pro.presentation.state.PlaylistsUiState
import com.musicplayer.pro.presentation.state.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel para la gestión de playlists.
 */
@HiltViewModel
class PlaylistsViewModel @Inject constructor(
    private val getAllPlaylistsUseCase: GetAllPlaylistsUseCase,
    private val getPlaylistByIdUseCase: GetPlaylistByIdUseCase,
    private val getPlaylistSongsUseCase: GetPlaylistSongsUseCase,
    private val createPlaylistUseCase: CreatePlaylistUseCase,
    private val updatePlaylistNameUseCase: UpdatePlaylistNameUseCase,
    private val deletePlaylistUseCase: DeletePlaylistUseCase,
    private val addSongToPlaylistUseCase: AddSongToPlaylistUseCase,
    private val addSongsToPlaylistUseCase: AddSongsToPlaylistUseCase,
    private val removeSongFromPlaylistUseCase: RemoveSongFromPlaylistUseCase,
    private val reorderPlaylistSongsUseCase: ReorderPlaylistSongsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(PlaylistsUiState())
    val uiState: StateFlow<PlaylistsUiState> = _uiState.asStateFlow()

    private val _events = Channel<UiEvent>()
    val events = _events.receiveAsFlow()

    init {
        loadPlaylists()
    }

    /**
     * Carga todas las playlists.
     */
    fun loadPlaylists() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            getAllPlaylistsUseCase()
                .catch { error ->
                    _uiState.update { 
                        it.copy(isLoading = false, error = error.message) 
                    }
                }
                .collectLatest { playlists ->
                    _uiState.update { 
                        it.copy(playlists = playlists, isLoading = false, error = null) 
                    }
                }
        }
    }

    /**
     * Selecciona una playlist y carga sus canciones.
     */
    fun selectPlaylist(playlist: Playlist) {
        viewModelScope.launch {
            _uiState.update { it.copy(selectedPlaylist = playlist, isLoading = true) }

            getPlaylistSongsUseCase(playlist.id)
                .catch { error ->
                    _uiState.update { it.copy(error = error.message, isLoading = false) }
                }
                .collectLatest { songs ->
                    _uiState.update { 
                        it.copy(playlistSongs = songs, isLoading = false) 
                    }
                }
        }
    }

    /**
     * Selecciona una playlist por ID.
     */
    fun selectPlaylistById(playlistId: Long) {
        viewModelScope.launch {
            val playlist = getPlaylistByIdUseCase(playlistId)
            playlist?.let { selectPlaylist(it) }
        }
    }

    /**
     * Deselecciona la playlist actual.
     */
    fun deselectPlaylist() {
        _uiState.update { 
            it.copy(selectedPlaylist = null, playlistSongs = emptyList()) 
        }
    }

    /**
     * Crea una nueva playlist.
     */
    fun createPlaylist(name: String, description: String? = null) {
        if (name.isBlank()) {
            viewModelScope.launch {
                _events.send(UiEvent.ShowSnackbar("El nombre no puede estar vacío"))
            }
            return
        }

        viewModelScope.launch {
            try {
                val playlistId = createPlaylistUseCase(name, description)
                _events.send(UiEvent.ShowSnackbar("Playlist creada"))
                hideCreateDialog()
                
                // Seleccionar la nueva playlist
                val playlist = getPlaylistByIdUseCase(playlistId)
                playlist?.let { selectPlaylist(it) }
            } catch (e: Exception) {
                _events.send(UiEvent.ShowSnackbar("Error al crear playlist: ${e.message}"))
            }
        }
    }

    /**
     * Actualiza el nombre de una playlist.
     */
    fun updatePlaylistName(playlistId: Long, name: String) {
        if (name.isBlank()) {
            viewModelScope.launch {
                _events.send(UiEvent.ShowSnackbar("El nombre no puede estar vacío"))
            }
            return
        }

        viewModelScope.launch {
            try {
                updatePlaylistNameUseCase(playlistId, name)
                _events.send(UiEvent.ShowSnackbar("Playlist actualizada"))
                hideEditDialog()
                
                // Actualizar la playlist seleccionada si es la misma
                if (_uiState.value.selectedPlaylist?.id == playlistId) {
                    val updatedPlaylist = getPlaylistByIdUseCase(playlistId)
                    _uiState.update { it.copy(selectedPlaylist = updatedPlaylist) }
                }
            } catch (e: Exception) {
                _events.send(UiEvent.ShowSnackbar("Error al actualizar: ${e.message}"))
            }
        }
    }

    /**
     * Elimina una playlist.
     */
    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            try {
                deletePlaylistUseCase(playlistId)
                _events.send(UiEvent.ShowSnackbar("Playlist eliminada"))
                hideDeleteDialog()
                
                // Si era la playlist seleccionada, deseleccionar
                if (_uiState.value.selectedPlaylist?.id == playlistId) {
                    deselectPlaylist()
                }
            } catch (e: Exception) {
                _events.send(UiEvent.ShowSnackbar("Error al eliminar: ${e.message}"))
            }
        }
    }

    /**
     * Añade una canción a una playlist.
     */
    fun addSongToPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            try {
                addSongToPlaylistUseCase(playlistId, songId)
                _events.send(UiEvent.ShowSnackbar("Canción añadida a la playlist"))
            } catch (e: Exception) {
                _events.send(UiEvent.ShowSnackbar("Error: ${e.message}"))
            }
        }
    }

    /**
     * Añade múltiples canciones a una playlist.
     */
    fun addSongsToPlaylist(playlistId: Long, songIds: List<Long>) {
        viewModelScope.launch {
            try {
                addSongsToPlaylistUseCase(playlistId, songIds)
                _events.send(UiEvent.ShowSnackbar("${songIds.size} canciones añadidas"))
            } catch (e: Exception) {
                _events.send(UiEvent.ShowSnackbar("Error: ${e.message}"))
            }
        }
    }

    /**
     * Elimina una canción de una playlist.
     */
    fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            try {
                removeSongFromPlaylistUseCase(playlistId, songId)
                _events.send(UiEvent.ShowSnackbar("Canción eliminada de la playlist"))
            } catch (e: Exception) {
                _events.send(UiEvent.ShowSnackbar("Error: ${e.message}"))
            }
        }
    }

    /**
     * Reordena una canción en la playlist.
     */
    fun reorderSong(playlistId: Long, songId: Long, newPosition: Int) {
        viewModelScope.launch {
            try {
                reorderPlaylistSongsUseCase(playlistId, songId, newPosition)
            } catch (e: Exception) {
                _events.send(UiEvent.ShowSnackbar("Error al reordenar: ${e.message}"))
            }
        }
    }

    /**
     * Obtiene las canciones de la playlist seleccionada.
     */
    fun getSelectedPlaylistSongs(): List<Song> {
        return _uiState.value.playlistSongs
    }

    // Diálogos
    fun showCreateDialog() {
        _uiState.update { it.copy(showCreateDialog = true) }
    }

    fun hideCreateDialog() {
        _uiState.update { it.copy(showCreateDialog = false) }
    }

    fun showEditDialog() {
        _uiState.update { it.copy(showEditDialog = true) }
    }

    fun hideEditDialog() {
        _uiState.update { it.copy(showEditDialog = false) }
    }

    fun showDeleteDialog() {
        _uiState.update { it.copy(showDeleteDialog = true) }
    }

    fun hideDeleteDialog() {
        _uiState.update { it.copy(showDeleteDialog = false) }
    }

    /**
     * Refresca las playlists.
     */
    fun refresh() {
        loadPlaylists()
        _uiState.value.selectedPlaylist?.let { selectPlaylist(it) }
    }

    /**
     * Limpia el error.
     */
    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}
