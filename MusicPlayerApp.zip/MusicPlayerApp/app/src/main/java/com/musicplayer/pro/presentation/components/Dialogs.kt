package com.musicplayer.pro.presentation.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.presentation.theme.Sizes

/**
 * Diálogo de confirmación genérico.
 */
@Composable
fun ConfirmationDialog(
    title: String,
    message: String,
    confirmText: String = "Confirmar",
    dismissText: String = "Cancelar",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    isDestructive: Boolean = false
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(
                    text = confirmText,
                    color = if (isDestructive) MaterialTheme.colorScheme.error 
                            else MaterialTheme.colorScheme.primary
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(dismissText)
            }
        }
    )
}

/**
 * Diálogo de entrada de texto.
 */
@Composable
fun TextInputDialog(
    title: String,
    initialValue: String = "",
    placeholder: String = "",
    confirmText: String = "Guardar",
    dismissText: String = "Cancelar",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initialValue) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text(placeholder) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(text) },
                enabled = text.isNotBlank()
            ) {
                Text(confirmText)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(dismissText)
            }
        }
    )
}

/**
 * Bottom sheet de opciones de canción.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongOptionsBottomSheet(
    song: Song,
    onDismiss: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onShare: () -> Unit,
    onSetAsRingtone: () -> Unit,
    onDelete: () -> Unit,
    onViewDetails: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier.padding(bottom = Sizes.PaddingLarge)
        ) {
            // Header con información de la canción
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(Sizes.PaddingMedium),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SmallAlbumArt(
                    albumArtUri = song.albumArtUri,
                    contentDescription = "Carátula",
                    placeholderSeed = song.title
                )
                
                Spacer(modifier = Modifier.width(Sizes.PaddingMedium))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1
                    )
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }

            Divider()

            // Opciones
            OptionItem(
                icon = Icons.Filled.PlaylistAdd,
                text = "Reproducir siguiente",
                onClick = {
                    onPlayNext()
                    onDismiss()
                }
            )
            
            OptionItem(
                icon = Icons.Filled.Add,
                text = "Añadir a la cola",
                onClick = {
                    onAddToQueue()
                    onDismiss()
                }
            )
            
            OptionItem(
                icon = Icons.Filled.PlaylistAdd,
                text = "Añadir a playlist",
                onClick = {
                    onAddToPlaylist()
                    onDismiss()
                }
            )

            Divider()
            
            OptionItem(
                icon = Icons.Filled.Share,
                text = "Compartir",
                onClick = {
                    onShare()
                    onDismiss()
                }
            )
            
            OptionItem(
                icon = Icons.Filled.Notifications,
                text = "Establecer como tono",
                onClick = {
                    onSetAsRingtone()
                    onDismiss()
                }
            )
            
            OptionItem(
                icon = Icons.Filled.Edit,
                text = "Ver detalles",
                onClick = {
                    onViewDetails()
                    onDismiss()
                }
            )

            Divider()
            
            OptionItem(
                icon = Icons.Filled.Delete,
                text = "Eliminar archivo",
                onClick = {
                    onDelete()
                    onDismiss()
                },
                isDestructive = true
            )
        }
    }
}

/**
 * Item de opción para bottom sheets.
 */
@Composable
private fun OptionItem(
    icon: ImageVector,
    text: String,
    onClick: () -> Unit,
    isDestructive: Boolean = false
) {
    ListItem(
        headlineContent = {
            Text(
                text = text,
                color = if (isDestructive) MaterialTheme.colorScheme.error 
                        else MaterialTheme.colorScheme.onSurface
            )
        },
        leadingContent = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isDestructive) MaterialTheme.colorScheme.error 
                       else MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        modifier = Modifier.selectable(
            selected = false,
            onClick = onClick
        )
    )
}

/**
 * Diálogo para seleccionar playlist.
 */
@Composable
fun SelectPlaylistDialog(
    playlists: List<Playlist>,
    onPlaylistSelected: (Playlist) -> Unit,
    onCreateNew: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir a playlist") },
        text = {
            LazyColumn {
                // Opción de crear nueva playlist
                item {
                    ListItem(
                        headlineContent = { Text("Crear nueva playlist") },
                        leadingContent = {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        },
                        modifier = Modifier.selectable(
                            selected = false,
                            onClick = {
                                onCreateNew()
                                onDismiss()
                            }
                        )
                    )
                    Divider()
                }
                
                // Lista de playlists existentes
                items(playlists) { playlist ->
                    ListItem(
                        headlineContent = { Text(playlist.name) },
                        supportingContent = { Text("${playlist.songCount} canciones") },
                        modifier = Modifier.selectable(
                            selected = false,
                            onClick = {
                                onPlaylistSelected(playlist)
                                onDismiss()
                            }
                        )
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

/**
 * Diálogo de ordenamiento.
 */
@Composable
fun SortDialog(
    currentSort: SortOption,
    onSortSelected: (SortOption) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ordenar por") },
        text = {
            Column {
                SortOption.values().forEach { option ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = currentSort == option,
                                onClick = {
                                    onSortSelected(option)
                                    onDismiss()
                                }
                            )
                            .padding(vertical = Sizes.PaddingSmall),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = currentSort == option,
                            onClick = null
                        )
                        Spacer(modifier = Modifier.width(Sizes.PaddingSmall))
                        Text(option.displayName)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

/**
 * Opciones de ordenamiento.
 */
enum class SortOption(val displayName: String) {
    TITLE_ASC("Título (A-Z)"),
    TITLE_DESC("Título (Z-A)"),
    ARTIST_ASC("Artista (A-Z)"),
    ARTIST_DESC("Artista (Z-A)"),
    ALBUM_ASC("Álbum (A-Z)"),
    ALBUM_DESC("Álbum (Z-A)"),
    DATE_ADDED_DESC("Fecha añadido (Reciente)"),
    DATE_ADDED_ASC("Fecha añadido (Antiguo)"),
    DURATION_ASC("Duración (Corta)"),
    DURATION_DESC("Duración (Larga)")
}
