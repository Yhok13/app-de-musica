package com.musicplayer.pro.presentation.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.presentation.theme.CustomShapes
import com.musicplayer.pro.presentation.theme.Sizes

/**
 * Mini player que aparece en la parte inferior de la pantalla.
 */
@Composable
fun MiniPlayer(
    song: Song?,
    isPlaying: Boolean,
    progress: Float,
    onPlayPauseClick: () -> Unit,
    onNextClick: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    visible: Boolean = song != null
) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it }),
        modifier = modifier
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CustomShapes.MiniPlayer),
            color = MaterialTheme.colorScheme.surfaceVariant,
            tonalElevation = 4.dp
        ) {
            Column {
                // Barra de progreso
                MiniProgressBar(
                    progress = progress,
                    modifier = Modifier.fillMaxWidth()
                )

                // Contenido del mini player
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(Sizes.MiniPlayerHeight)
                        .clickable(onClick = onClick)
                        .padding(horizontal = Sizes.PaddingMedium),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Carátula
                    if (song != null) {
                        TinyAlbumArt(
                            albumArtUri = song.albumArtUri,
                            contentDescription = "Carátula de ${song.title}",
                            placeholderSeed = song.title
                        )
                    }

                    Spacer(modifier = Modifier.width(Sizes.PaddingMedium))

                    // Información de la canción
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = song?.title ?: "Sin reproducción",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = song?.artist ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Controles
                    MiniPlayPauseButton(
                        isPlaying = isPlaying,
                        onClick = onPlayPauseClick
                    )

                    Spacer(modifier = Modifier.width(Sizes.PaddingSmall))

                    ControlButton(
                        icon = Icons.Filled.SkipNext,
                        contentDescription = "Siguiente",
                        onClick = onNextClick,
                        size = Sizes.ControlButtonSmall
                    )
                }
            }
        }
    }
}

/**
 * Mini player con información adicional.
 */
@Composable
fun ExpandedMiniPlayer(
    song: Song?,
    isPlaying: Boolean,
    progress: Float,
    currentTime: String,
    totalTime: String,
    onPlayPauseClick: () -> Unit,
    onPreviousClick: () -> Unit,
    onNextClick: () -> Unit,
    onSeek: (Float) -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(CustomShapes.MiniPlayer),
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(Sizes.PaddingMedium)
        ) {
            // Información y carátula
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (song != null) {
                    SmallAlbumArt(
                        albumArtUri = song.albumArtUri,
                        contentDescription = "Carátula de ${song.title}",
                        placeholderSeed = song.title
                    )
                }

                Spacer(modifier = Modifier.width(Sizes.PaddingMedium))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song?.title ?: "Sin reproducción",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song?.artist ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(Sizes.PaddingSmall))

            // Barra de progreso
            MusicProgressBar(
                progress = progress,
                currentTime = currentTime,
                totalTime = totalTime,
                onSeek = onSeek
            )

            Spacer(modifier = Modifier.height(Sizes.PaddingSmall))

            // Controles
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(modifier = Modifier.weight(1f))

                PreviousButton(onClick = onPreviousClick)

                Spacer(modifier = Modifier.width(Sizes.PaddingMedium))

                PlayPauseButton(
                    isPlaying = isPlaying,
                    onClick = onPlayPauseClick,
                    size = Sizes.PlayButtonMedium
                )

                Spacer(modifier = Modifier.width(Sizes.PaddingMedium))

                NextButton(onClick = onNextClick)

                Spacer(modifier = Modifier.weight(1f))
            }
        }
    }
}
