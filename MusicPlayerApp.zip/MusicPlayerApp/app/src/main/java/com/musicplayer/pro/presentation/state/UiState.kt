package com.musicplayer.pro.presentation.state

import com.musicplayer.pro.domain.model.Album
import com.musicplayer.pro.domain.model.Artist
import com.musicplayer.pro.domain.model.Folder
import com.musicplayer.pro.domain.model.PlaybackState
import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.domain.model.Song

/**
 * Estado genérico para operaciones asíncronas.
 */
sealed class UiState<out T> {
    object Initial : UiState<Nothing>()
    object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
    object Empty : UiState<Nothing>()
}

/**
 * Estado de la pantalla principal.
 */
data class MainUiState(
    val hasPermission: Boolean = false,
    val isScanning: Boolean = false,
    val scanProgress: Int = 0,
    val totalSongs: Int = 0,
    val currentTab: Int = 0,
    val error: String? = null
)

/**
 * Estado de la biblioteca de canciones.
 */
data class LibraryUiState(
    val songs: List<Song> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val sortOrder: SortOrder = SortOrder.TITLE_ASC,
    val filterQuery: String = ""
)

/**
 * Estado de la pantalla de carpetas.
 */
data class FoldersUiState(
    val folders: List<Folder> = emptyList(),
    val currentPath: String? = null,
    val pathHistory: List<String> = emptyList(),
    val songsInCurrentFolder: List<Song> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

/**
 * Estado del reproductor.
 */
data class PlayerUiState(
    val playbackState: PlaybackState = PlaybackState.EMPTY,
    val currentSong: Song? = null,
    val queue: List<Song> = emptyList(),
    val currentQueueIndex: Int = -1,
    val isExpanded: Boolean = false,
    val showQueue: Boolean = false,
    val isFavorite: Boolean = false
)

/**
 * Estado de la pantalla de playlists.
 */
data class PlaylistsUiState(
    val playlists: List<Playlist> = emptyList(),
    val selectedPlaylist: Playlist? = null,
    val playlistSongs: List<Song> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val showCreateDialog: Boolean = false,
    val showEditDialog: Boolean = false,
    val showDeleteDialog: Boolean = false
)

/**
 * Estado de la pantalla de favoritos.
 */
data class FavoritesUiState(
    val favorites: List<Song> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

/**
 * Estado de la pantalla de búsqueda.
 */
data class SearchUiState(
    val query: String = "",
    val songs: List<Song> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val isSearching: Boolean = false,
    val hasSearched: Boolean = false
)

/**
 * Estado del ecualizador.
 */
data class EqualizerUiState(
    val isEnabled: Boolean = false,
    val bandLevels: List<Int> = listOf(0, 0, 0, 0, 0),
    val bandFrequencies: List<Int> = listOf(60, 230, 910, 3600, 14000),
    val minLevel: Int = -1500,
    val maxLevel: Int = 1500,
    val bassBoostStrength: Int = 0,
    val currentPreset: String? = null,
    val presets: List<String> = emptyList()
)

/**
 * Estado de la cola de reproducción.
 */
data class QueueUiState(
    val queue: List<Song> = emptyList(),
    val currentIndex: Int = -1,
    val isReordering: Boolean = false
)

/**
 * Opciones de ordenamiento.
 */
enum class SortOrder {
    TITLE_ASC,
    TITLE_DESC,
    ARTIST_ASC,
    ARTIST_DESC,
    ALBUM_ASC,
    ALBUM_DESC,
    DATE_ADDED_ASC,
    DATE_ADDED_DESC,
    DURATION_ASC,
    DURATION_DESC
}

/**
 * Eventos de UI para comunicación ViewModel -> UI.
 */
sealed class UiEvent {
    data class ShowSnackbar(val message: String) : UiEvent()
    data class ShowToast(val message: String) : UiEvent()
    object NavigateBack : UiEvent()
    data class NavigateTo(val route: String) : UiEvent()
    object ScrollToTop : UiEvent()
    data class ShowDialog(val dialogType: DialogType) : UiEvent()
    object DismissDialog : UiEvent()
}

/**
 * Tipos de diálogos.
 */
enum class DialogType {
    CREATE_PLAYLIST,
    EDIT_PLAYLIST,
    DELETE_PLAYLIST,
    DELETE_SONG,
    ADD_TO_PLAYLIST,
    SONG_OPTIONS,
    SORT_OPTIONS
}

/**
 * Acciones del usuario en la UI.
 */
sealed class UserAction {
    // Reproducción
    data class PlaySong(val song: Song) : UserAction()
    data class PlaySongs(val songs: List<Song>, val startIndex: Int = 0) : UserAction()
    object PlayPause : UserAction()
    object SkipNext : UserAction()
    object SkipPrevious : UserAction()
    data class SeekTo(val position: Long) : UserAction()
    object ToggleShuffle : UserAction()
    object ToggleRepeat : UserAction()
    
    // Cola
    data class AddToQueue(val song: Song) : UserAction()
    data class PlayNext(val song: Song) : UserAction()
    data class RemoveFromQueue(val index: Int) : UserAction()
    data class MoveQueueItem(val from: Int, val to: Int) : UserAction()
    object ClearQueue : UserAction()
    
    // Favoritos
    data class ToggleFavorite(val songId: Long) : UserAction()
    
    // Playlists
    data class CreatePlaylist(val name: String) : UserAction()
    data class DeletePlaylist(val playlistId: Long) : UserAction()
    data class RenamePlaylist(val playlistId: Long, val name: String) : UserAction()
    data class AddToPlaylist(val playlistId: Long, val songId: Long) : UserAction()
    data class RemoveFromPlaylist(val playlistId: Long, val songId: Long) : UserAction()
    
    // Archivos
    data class DeleteSong(val song: Song) : UserAction()
    data class ShareSong(val song: Song) : UserAction()
    data class SetAsRingtone(val song: Song) : UserAction()
    
    // Navegación
    data class NavigateToFolder(val path: String) : UserAction()
    object NavigateBack : UserAction()
    data class Search(val query: String) : UserAction()
    data class SetSortOrder(val order: SortOrder) : UserAction()
    
    // Permisos
    object RequestPermission : UserAction()
    object OpenSettings : UserAction()
    
    // Escaneo
    object ScanLibrary : UserAction()
    object RefreshLibrary : UserAction()
}
