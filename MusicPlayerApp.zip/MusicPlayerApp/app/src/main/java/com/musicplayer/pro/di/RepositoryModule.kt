package com.musicplayer.pro.di

import com.musicplayer.pro.data.repository.AudioRepositoryImpl
import com.musicplayer.pro.data.repository.FavoriteRepositoryImpl
import com.musicplayer.pro.data.repository.FolderRepositoryImpl
import com.musicplayer.pro.data.repository.PlaylistRepositoryImpl
import com.musicplayer.pro.domain.repository.AudioRepository
import com.musicplayer.pro.domain.repository.FavoriteRepository
import com.musicplayer.pro.domain.repository.FolderRepository
import com.musicplayer.pro.domain.repository.PlaylistRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Módulo de Hilt para vincular las implementaciones de repositorios con sus interfaces.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    /**
     * Vincula la implementación del repositorio de audio.
     */
    @Binds
    @Singleton
    abstract fun bindAudioRepository(
        audioRepositoryImpl: AudioRepositoryImpl
    ): AudioRepository

    /**
     * Vincula la implementación del repositorio de carpetas.
     */
    @Binds
    @Singleton
    abstract fun bindFolderRepository(
        folderRepositoryImpl: FolderRepositoryImpl
    ): FolderRepository

    /**
     * Vincula la implementación del repositorio de playlists.
     */
    @Binds
    @Singleton
    abstract fun bindPlaylistRepository(
        playlistRepositoryImpl: PlaylistRepositoryImpl
    ): PlaylistRepository

    /**
     * Vincula la implementación del repositorio de favoritos.
     */
    @Binds
    @Singleton
    abstract fun bindFavoriteRepository(
        favoriteRepositoryImpl: FavoriteRepositoryImpl
    ): FavoriteRepository
}
