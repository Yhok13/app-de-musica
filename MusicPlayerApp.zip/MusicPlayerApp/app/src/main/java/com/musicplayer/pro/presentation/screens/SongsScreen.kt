package com.musicplayer.pro.presentation.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.presentation.components.SongItem
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.FavoritesViewModel
import com.musicplayer.pro.presentation.viewmodel.LibraryViewModel
import com.musicplayer.pro.presentation.viewmodel.PlayerViewModel

/**
 * Pantalla de lista de canciones.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongsScreen(
    onSongClick: (Song) -> Unit,
    onSearchClick: () -> Unit,
    onSortClick: () -> Unit,
    modifier: Modifier = Modifier,
    libraryViewModel: LibraryViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel(),
    favoritesViewModel: FavoritesViewModel = hiltViewModel()
) {
    val uiState by libraryViewModel.uiState.collectAsState()
    val playerState by playerViewModel.uiState.collectAsState()
    val favoriteSongIds by favoritesViewModel.favoriteSongIds.collectAsState()
    
    val listState = rememberLazyListState()
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()
    
    // Determinar si el FAB debe estar expandido
    val expandedFab by remember {
        derivedStateOf { listState.firstVisibleItemIndex == 0 }
    }

    Scaffold(
        modifier = modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "Canciones")
                        if (uiState.songs.isNotEmpty()) {
                            Text(
                                text = "${uiState.songs.size} canciones",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onSearchClick) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "Buscar"
                        )
                    }
                    IconButton(onClick = onSortClick) {
                        Icon(
                            imageVector = Icons.Filled.Sort,
                            contentDescription = "Ordenar"
                        )
                    }
                },
                scrollBehavior = scrollBehavior
            )
        },
        floatingActionButton = {
            if (uiState.songs.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = {
                        playerViewModel.playSongs(uiState.songs, 0)
                    },
                    expanded = expandedFab,
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Shuffle,
                            contentDescription = null
                        )
                    },
                    text = { Text("Aleatorio") }
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                uiState.isLoading -> {
                    LoadingState()
                }
                uiState.songs.isEmpty() -> {
                    EmptyState(
                        icon = Icons.Filled.MusicNote,
                        title = "No hay canciones",
                        message = "No se encontraron canciones en tu dispositivo"
                    )
                }
                else -> {
                    SongsList(
                        songs = uiState.songs,
                        currentSongId = playerState.currentSong?.id,
                        favoriteSongIds = favoriteSongIds,
                        listState = listState,
                        onSongClick = { song ->
                            playerViewModel.playSongs(uiState.songs, uiState.songs.indexOf(song))
                            onSongClick(song)
                        },
                        onFavoriteClick = { songId ->
                            favoritesViewModel.toggleFavorite(songId)
                        },
                        onMoreClick = { /* Mostrar opciones */ }
                    )
                }
            }
        }
    }
}

/**
 * Lista de canciones.
 */
@Composable
private fun SongsList(
    songs: List<Song>,
    currentSongId: Long?,
    favoriteSongIds: Set<Long>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onSongClick: (Song) -> Unit,
    onFavoriteClick: (Long) -> Unit,
    onMoreClick: (Song) -> Unit
) {
    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(
            top = Sizes.PaddingSmall,
            bottom = 120.dp // Espacio para mini player y FAB
        )
    ) {
        items(
            items = songs,
            key = { it.id }
        ) { song ->
            SongItem(
                song = song,
                onClick = { onSongClick(song) },
                isPlaying = song.id == currentSongId,
                isFavorite = song.id in favoriteSongIds,
                onFavoriteClick = { onFavoriteClick(song.id) },
                onMoreClick = { onMoreClick(song) }
            )
        }
    }
}

/**
 * Estado de carga.
 */
@Composable
fun LoadingState(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator()
    }
}

/**
 * Estado vacío.
 */
@Composable
fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    action: @Composable (() -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(Sizes.PaddingLarge),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(80.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
        )
        
        Spacer(modifier = Modifier.height(Sizes.PaddingMedium))
        
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        
        Spacer(modifier = Modifier.height(Sizes.PaddingSmall))
        
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        if (action != null) {
            Spacer(modifier = Modifier.height(Sizes.PaddingLarge))
            action()
        }
    }
}
