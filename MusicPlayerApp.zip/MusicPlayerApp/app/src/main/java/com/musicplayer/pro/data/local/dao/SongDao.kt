package com.musicplayer.pro.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.musicplayer.pro.data.local.entity.SongEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO para operaciones de base de datos relacionadas con canciones.
 */
@Dao
interface SongDao {

    /**
     * Obtiene todas las canciones ordenadas por título.
     */
    @Query("SELECT * FROM songs ORDER BY title ASC")
    fun getAllSongs(): Flow<List<SongEntity>>

    /**
     * Obtiene todas las canciones ordenadas por fecha de adición (más recientes primero).
     */
    @Query("SELECT * FROM songs ORDER BY date_added DESC")
    fun getAllSongsByDateAdded(): Flow<List<SongEntity>>

    /**
     * Obtiene una canción por su ID.
     */
    @Query("SELECT * FROM songs WHERE id = :songId")
    suspend fun getSongById(songId: Long): SongEntity?

    /**
     * Obtiene una canción por su ID de MediaStore.
     */
    @Query("SELECT * FROM songs WHERE media_store_id = :mediaStoreId")
    suspend fun getSongByMediaStoreId(mediaStoreId: Long): SongEntity?

    /**
     * Obtiene canciones por ID de álbum.
     */
    @Query("SELECT * FROM songs WHERE album_id = :albumId ORDER BY track_number ASC, title ASC")
    fun getSongsByAlbum(albumId: Long): Flow<List<SongEntity>>

    /**
     * Obtiene canciones por ID de artista.
     */
    @Query("SELECT * FROM songs WHERE artist_id = :artistId ORDER BY album ASC, track_number ASC")
    fun getSongsByArtist(artistId: Long): Flow<List<SongEntity>>

    /**
     * Obtiene canciones por ruta de carpeta.
     */
    @Query("SELECT * FROM songs WHERE folder_path = :folderPath ORDER BY title ASC")
    fun getSongsByFolder(folderPath: String): Flow<List<SongEntity>>

    /**
     * Obtiene canciones favoritas.
     */
    @Query("SELECT * FROM songs WHERE is_favorite = 1 ORDER BY title ASC")
    fun getFavoriteSongs(): Flow<List<SongEntity>>

    /**
     * Busca canciones por título, artista o álbum.
     */
    @Query("""
        SELECT * FROM songs 
        WHERE title LIKE '%' || :query || '%' 
        OR artist LIKE '%' || :query || '%' 
        OR album LIKE '%' || :query || '%'
        ORDER BY title ASC
    """)
    fun searchSongs(query: String): Flow<List<SongEntity>>

    /**
     * Obtiene las canciones más reproducidas.
     */
    @Query("SELECT * FROM songs WHERE play_count > 0 ORDER BY play_count DESC LIMIT :limit")
    fun getMostPlayedSongs(limit: Int = 50): Flow<List<SongEntity>>

    /**
     * Obtiene las canciones reproducidas recientemente.
     */
    @Query("SELECT * FROM songs WHERE last_played IS NOT NULL ORDER BY last_played DESC LIMIT :limit")
    fun getRecentlyPlayedSongs(limit: Int = 50): Flow<List<SongEntity>>

    /**
     * Obtiene el conteo total de canciones.
     */
    @Query("SELECT COUNT(*) FROM songs")
    suspend fun getSongCount(): Int

    /**
     * Inserta una canción.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSong(song: SongEntity): Long

    /**
     * Inserta múltiples canciones.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSongs(songs: List<SongEntity>)

    /**
     * Actualiza una canción.
     */
    @Update
    suspend fun updateSong(song: SongEntity)

    /**
     * Actualiza el estado de favorito de una canción.
     */
    @Query("UPDATE songs SET is_favorite = :isFavorite WHERE id = :songId")
    suspend fun updateFavoriteStatus(songId: Long, isFavorite: Boolean)

    /**
     * Incrementa el contador de reproducciones y actualiza la última reproducción.
     */
    @Query("UPDATE songs SET play_count = play_count + 1, last_played = :timestamp WHERE id = :songId")
    suspend fun incrementPlayCount(songId: Long, timestamp: Long = System.currentTimeMillis())

    /**
     * Elimina una canción.
     */
    @Delete
    suspend fun deleteSong(song: SongEntity)

    /**
     * Elimina una canción por su ID de MediaStore.
     */
    @Query("DELETE FROM songs WHERE media_store_id = :mediaStoreId")
    suspend fun deleteSongByMediaStoreId(mediaStoreId: Long)

    /**
     * Elimina todas las canciones.
     */
    @Query("DELETE FROM songs")
    suspend fun deleteAllSongs()

    /**
     * Obtiene todos los IDs de MediaStore existentes.
     */
    @Query("SELECT media_store_id FROM songs")
    suspend fun getAllMediaStoreIds(): List<Long>

    /**
     * Elimina canciones que ya no existen en MediaStore.
     */
    @Query("DELETE FROM songs WHERE media_store_id NOT IN (:validIds)")
    suspend fun deleteOrphanedSongs(validIds: List<Long>)
}
