package com.musicplayer.pro.domain.model

/**
 * Modelo de dominio que representa una canción.
 * Contiene todos los metadatos relevantes de un archivo de audio.
 */
data class Song(
    val id: Long,
    val mediaStoreId: Long,
    val title: String,
    val artist: String,
    val artistId: Long,
    val album: String,
    val albumId: Long,
    val genre: String?,
    val duration: Long,
    val filePath: String,
    val folderPath: String,
    val folderName: String,
    val fileName: String,
    val fileSize: Long,
    val mimeType: String,
    val bitrate: Int?,
    val sampleRate: Int?,
    val trackNumber: Int?,
    val year: Int?,
    val albumArtUri: String?,
    val dateAdded: Long,
    val dateModified: Long,
    val isFavorite: Boolean = false,
    val playCount: Int = 0,
    val lastPlayed: Long? = null
) {
    /**
     * Duración formateada como MM:SS o HH:MM:SS.
     */
    val formattedDuration: String
        get() {
            val totalSeconds = duration / 1000
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60
            val seconds = totalSeconds % 60

            return if (hours > 0) {
                String.format("%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format("%d:%02d", minutes, seconds)
            }
        }

    /**
     * Tamaño del archivo formateado (KB, MB, GB).
     */
    val formattedFileSize: String
        get() {
            val kb = fileSize / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0

            return when {
                gb >= 1 -> String.format("%.2f GB", gb)
                mb >= 1 -> String.format("%.2f MB", mb)
                else -> String.format("%.2f KB", kb)
            }
        }

    /**
     * Extensión del archivo.
     */
    val fileExtension: String
        get() = fileName.substringAfterLast('.', "").uppercase()

    /**
     * Información del artista y álbum combinada.
     */
    val artistAlbumInfo: String
        get() = "$artist • $album"

    companion object {
        /**
         * Crea una canción vacía/placeholder.
         */
        fun empty() = Song(
            id = 0,
            mediaStoreId = 0,
            title = "",
            artist = "",
            artistId = 0,
            album = "",
            albumId = 0,
            genre = null,
            duration = 0,
            filePath = "",
            folderPath = "",
            folderName = "",
            fileName = "",
            fileSize = 0,
            mimeType = "",
            bitrate = null,
            sampleRate = null,
            trackNumber = null,
            year = null,
            albumArtUri = null,
            dateAdded = 0,
            dateModified = 0
        )
    }
}
