package com.musicplayer.pro.data.datasource

import android.content.ContentResolver
import android.content.ContentUris
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.musicplayer.pro.data.local.entity.AlbumEntity
import com.musicplayer.pro.data.local.entity.ArtistEntity
import com.musicplayer.pro.data.local.entity.FolderEntity
import com.musicplayer.pro.data.local.entity.SongEntity
import com.musicplayer.pro.di.IoDispatcher
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Data source para acceder a los archivos de audio del dispositivo a través de MediaStore.
 * Soporta formatos: MP3, FLAC, OGG, WAV, AAC, M4A.
 */
@Singleton
class MediaStoreDataSource @Inject constructor(
    private val contentResolver: ContentResolver,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    companion object {
        // Formatos de audio soportados
        private val SUPPORTED_MIME_TYPES = arrayOf(
            "audio/mpeg",       // MP3
            "audio/mp3",        // MP3
            "audio/flac",       // FLAC
            "audio/ogg",        // OGG
            "audio/vorbis",     // OGG Vorbis
            "audio/wav",        // WAV
            "audio/x-wav",      // WAV
            "audio/aac",        // AAC
            "audio/mp4",        // M4A/AAC
            "audio/x-m4a",      // M4A
            "audio/m4a"         // M4A
        )

        // Duración mínima en milisegundos (filtrar archivos muy cortos como tonos)
        private const val MIN_DURATION_MS = 30000L // 30 segundos

        // URI de contenido para audio
        private val AUDIO_URI: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        // Proyección para consulta de canciones
        private val SONG_PROJECTION = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ARTIST_ID,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATE_MODIFIED
        )

        // Proyección para consulta de álbumes
        private val ALBUM_PROJECTION = arrayOf(
            MediaStore.Audio.Albums._ID,
            MediaStore.Audio.Albums.ALBUM,
            MediaStore.Audio.Albums.ARTIST,
            MediaStore.Audio.Albums.ARTIST_ID,
            MediaStore.Audio.Albums.NUMBER_OF_SONGS,
            MediaStore.Audio.Albums.FIRST_YEAR
        )

        // Proyección para consulta de artistas
        private val ARTIST_PROJECTION = arrayOf(
            MediaStore.Audio.Artists._ID,
            MediaStore.Audio.Artists.ARTIST,
            MediaStore.Audio.Artists.NUMBER_OF_TRACKS,
            MediaStore.Audio.Artists.NUMBER_OF_ALBUMS
        )
    }

    /**
     * Escanea todas las canciones del dispositivo.
     */
    suspend fun scanAllSongs(): List<SongEntity> = withContext(ioDispatcher) {
        val songs = mutableListOf<SongEntity>()

        // Construir selección para filtrar por tipo MIME y duración
        val mimeSelection = SUPPORTED_MIME_TYPES.joinToString(" OR ") {
            "${MediaStore.Audio.Media.MIME_TYPE} = ?"
        }
        val selection = "($mimeSelection) AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val selectionArgs = SUPPORTED_MIME_TYPES.toList() + MIN_DURATION_MS.toString()

        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        contentResolver.query(
            AUDIO_URI,
            SONG_PROJECTION,
            selection,
            selectionArgs.toTypedArray(),
            sortOrder
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val song = cursorToSongEntity(cursor)
                if (song != null) {
                    songs.add(song)
                }
            }
        }

        songs
    }

    /**
     * Escanea todos los álbumes del dispositivo.
     */
    suspend fun scanAllAlbums(): List<AlbumEntity> = withContext(ioDispatcher) {
        val albums = mutableListOf<AlbumEntity>()

        contentResolver.query(
            MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,
            ALBUM_PROJECTION,
            null,
            null,
            "${MediaStore.Audio.Albums.ALBUM} ASC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val album = cursorToAlbumEntity(cursor)
                if (album != null) {
                    albums.add(album)
                }
            }
        }

        albums
    }

    /**
     * Escanea todos los artistas del dispositivo.
     */
    suspend fun scanAllArtists(): List<ArtistEntity> = withContext(ioDispatcher) {
        val artists = mutableListOf<ArtistEntity>()

        contentResolver.query(
            MediaStore.Audio.Artists.EXTERNAL_CONTENT_URI,
            ARTIST_PROJECTION,
            null,
            null,
            "${MediaStore.Audio.Artists.ARTIST} ASC"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val artist = cursorToArtistEntity(cursor)
                if (artist != null) {
                    artists.add(artist)
                }
            }
        }

        artists
    }

    /**
     * Extrae las carpetas únicas de una lista de canciones.
     */
    suspend fun extractFolders(songs: List<SongEntity>): List<FolderEntity> = withContext(ioDispatcher) {
        val folderMap = mutableMapOf<String, MutableList<SongEntity>>()

        // Agrupar canciones por carpeta
        songs.forEach { song ->
            val folderPath = song.folderPath
            if (folderPath.isNotEmpty()) {
                folderMap.getOrPut(folderPath) { mutableListOf() }.add(song)
            }
        }

        // Crear entidades de carpeta
        folderMap.map { (path, songsInFolder) ->
            val file = File(path)
            val parentPath = file.parent

            FolderEntity(
                path = path,
                name = file.name,
                parentPath = parentPath,
                songCount = songsInFolder.size,
                totalSize = songsInFolder.sumOf { it.fileSize },
                lastModified = songsInFolder.maxOfOrNull { it.dateModified } ?: 0L
            )
        }
    }

    /**
     * Obtiene la URI del artwork de un álbum.
     */
    fun getAlbumArtUri(albumId: Long): Uri {
        return ContentUris.withAppendedId(
            Uri.parse("content://media/external/audio/albumart"),
            albumId
        )
    }

    /**
     * Obtiene la URI de contenido de una canción.
     */
    fun getSongContentUri(mediaStoreId: Long): Uri {
        return ContentUris.withAppendedId(AUDIO_URI, mediaStoreId)
    }

    /**
     * Convierte un cursor a SongEntity.
     */
    private fun cursorToSongEntity(cursor: Cursor): SongEntity? {
        return try {
            val mediaStoreId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID))
            val title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)) ?: "Sin título"
            val artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)) ?: "Artista desconocido"
            val artistId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST_ID))
            val album = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)) ?: "Álbum desconocido"
            val albumId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID))
            val duration = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION))
            val filePath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)) ?: ""
            val fileName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)) ?: ""
            val fileSize = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE))
            val mimeType = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)) ?: ""
            val trackNumber = cursor.getIntOrNull(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK))
            val year = cursor.getIntOrNull(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR))
            val dateAdded = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED))
            val dateModified = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED))

            // Extraer información de carpeta
            val file = File(filePath)
            val folderPath = file.parent ?: ""
            val folderName = file.parentFile?.name ?: ""

            // URI del artwork del álbum
            val albumArtUri = getAlbumArtUri(albumId).toString()

            SongEntity(
                mediaStoreId = mediaStoreId,
                title = title,
                artist = artist,
                artistId = artistId,
                album = album,
                albumId = albumId,
                genre = null, // Se puede obtener de otra consulta si es necesario
                duration = duration,
                filePath = filePath,
                folderPath = folderPath,
                folderName = folderName,
                fileName = fileName,
                fileSize = fileSize,
                mimeType = mimeType,
                bitrate = null,
                sampleRate = null,
                trackNumber = trackNumber,
                year = year,
                albumArtUri = albumArtUri,
                dateAdded = dateAdded,
                dateModified = dateModified
            )
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Convierte un cursor a AlbumEntity.
     */
    private fun cursorToAlbumEntity(cursor: Cursor): AlbumEntity? {
        return try {
            val mediaStoreId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Albums._ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Albums.ALBUM)) ?: "Álbum desconocido"
            val artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Albums.ARTIST)) ?: "Artista desconocido"
            val artistId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Albums.ARTIST_ID))
            val songCount = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Albums.NUMBER_OF_SONGS))
            val year = cursor.getIntOrNull(cursor.getColumnIndexOrThrow(MediaStore.Audio.Albums.FIRST_YEAR))

            val albumArtUri = getAlbumArtUri(mediaStoreId).toString()

            AlbumEntity(
                mediaStoreId = mediaStoreId,
                name = name,
                artist = artist,
                artistId = artistId,
                songCount = songCount,
                year = year,
                albumArtUri = albumArtUri
            )
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Convierte un cursor a ArtistEntity.
     */
    private fun cursorToArtistEntity(cursor: Cursor): ArtistEntity? {
        return try {
            val mediaStoreId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Artists._ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Artists.ARTIST)) ?: "Artista desconocido"
            val songCount = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Artists.NUMBER_OF_TRACKS))
            val albumCount = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Artists.NUMBER_OF_ALBUMS))

            ArtistEntity(
                mediaStoreId = mediaStoreId,
                name = name,
                songCount = songCount,
                albumCount = albumCount
            )
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Extensión para obtener un Int nullable de un cursor.
     */
    private fun Cursor.getIntOrNull(columnIndex: Int): Int? {
        return if (isNull(columnIndex)) null else getInt(columnIndex)
    }
}
