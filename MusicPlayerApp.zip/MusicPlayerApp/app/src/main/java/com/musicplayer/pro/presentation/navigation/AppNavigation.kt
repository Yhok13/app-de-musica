package com.musicplayer.pro.presentation.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.musicplayer.pro.domain.model.Album
import com.musicplayer.pro.domain.model.Artist
import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.presentation.screens.AlbumsScreen
import com.musicplayer.pro.presentation.screens.ArtistsScreen
import com.musicplayer.pro.presentation.screens.EqualizerScreen
import com.musicplayer.pro.presentation.screens.FavoritesScreen
import com.musicplayer.pro.presentation.screens.FoldersScreen
import com.musicplayer.pro.presentation.screens.NowPlayingScreen
import com.musicplayer.pro.presentation.screens.PlaylistsScreen
import com.musicplayer.pro.presentation.screens.QueueScreen
import com.musicplayer.pro.presentation.screens.SearchScreen
import com.musicplayer.pro.presentation.screens.SongsScreen

/**
 * Duración de las animaciones de transición.
 */
private const val ANIMATION_DURATION = 300

/**
 * NavHost principal de la aplicación con todas las rutas.
 */
@Composable
fun AppNavHost(
    navController: NavHostController,
    onSongClick: (Song) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onPlaylistClick: (Playlist) -> Unit,
    onNowPlayingClick: () -> Unit,
    modifier: Modifier = Modifier,
    startDestination: String = Screen.Songs.route
) {
    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier,
        enterTransition = {
            fadeIn(animationSpec = tween(ANIMATION_DURATION)) +
            slideIntoContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.Start,
                animationSpec = tween(ANIMATION_DURATION)
            )
        },
        exitTransition = {
            fadeOut(animationSpec = tween(ANIMATION_DURATION)) +
            slideOutOfContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.Start,
                animationSpec = tween(ANIMATION_DURATION)
            )
        },
        popEnterTransition = {
            fadeIn(animationSpec = tween(ANIMATION_DURATION)) +
            slideIntoContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.End,
                animationSpec = tween(ANIMATION_DURATION)
            )
        },
        popExitTransition = {
            fadeOut(animationSpec = tween(ANIMATION_DURATION)) +
            slideOutOfContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.End,
                animationSpec = tween(ANIMATION_DURATION)
            )
        }
    ) {
        // ============ PANTALLAS PRINCIPALES (Bottom Navigation) ============
        
        composable(Screen.Songs.route) {
            SongsScreen(
                onSongClick = onSongClick,
                onSearchClick = { navController.navigate(Screen.Search.route) },
                onSortClick = { /* Mostrar diálogo de ordenamiento */ }
            )
        }
        
        composable(Screen.Albums.route) {
            AlbumsScreen(
                onAlbumClick = { album ->
                    navController.navigate(Screen.AlbumDetail.createRoute(album.id))
                },
                onSearchClick = { navController.navigate(Screen.Search.route) }
            )
        }
        
        composable(Screen.Artists.route) {
            ArtistsScreen(
                onArtistClick = { artist ->
                    navController.navigate(Screen.ArtistDetail.createRoute(artist.id))
                },
                onSearchClick = { navController.navigate(Screen.Search.route) }
            )
        }
        
        composable(Screen.Folders.route) {
            FoldersScreen(
                onSongClick = onSongClick
            )
        }
        
        composable(Screen.Playlists.route) {
            PlaylistsScreen(
                onPlaylistClick = { playlist ->
                    navController.navigate(Screen.PlaylistDetail.createRoute(playlist.id))
                }
            )
        }
        
        // ============ PANTALLAS DE DETALLE ============
        
        composable(
            route = Screen.AlbumDetail.route,
            arguments = listOf(
                navArgument(NavArgs.ALBUM_ID) { type = NavType.LongType }
            )
        ) { backStackEntry ->
            val albumId = backStackEntry.arguments?.getLong(NavArgs.ALBUM_ID) ?: 0L
            AlbumDetailScreen(
                albumId = albumId,
                onBackClick = { navController.popBackStack() },
                onSongClick = onSongClick
            )
        }
        
        composable(
            route = Screen.ArtistDetail.route,
            arguments = listOf(
                navArgument(NavArgs.ARTIST_ID) { type = NavType.LongType }
            )
        ) { backStackEntry ->
            val artistId = backStackEntry.arguments?.getLong(NavArgs.ARTIST_ID) ?: 0L
            ArtistDetailScreen(
                artistId = artistId,
                onBackClick = { navController.popBackStack() },
                onAlbumClick = { album ->
                    navController.navigate(Screen.AlbumDetail.createRoute(album.id))
                },
                onSongClick = onSongClick
            )
        }
        
        composable(
            route = Screen.PlaylistDetail.route,
            arguments = listOf(
                navArgument(NavArgs.PLAYLIST_ID) { type = NavType.LongType }
            )
        ) { backStackEntry ->
            val playlistId = backStackEntry.arguments?.getLong(NavArgs.PLAYLIST_ID) ?: 0L
            PlaylistDetailScreen(
                playlistId = playlistId,
                onBackClick = { navController.popBackStack() },
                onSongClick = onSongClick
            )
        }
        
        // ============ PANTALLAS DE FUNCIONALIDAD ============
        
        composable(Screen.NowPlaying.route) {
            NowPlayingScreen(
                onBackClick = { navController.popBackStack() },
                onQueueClick = { navController.navigate(Screen.Queue.route) }
            )
        }
        
        composable(Screen.Queue.route) {
            QueueScreen(
                onBackClick = { navController.popBackStack() }
            )
        }
        
        composable(Screen.Search.route) {
            SearchScreen(
                onBackClick = { navController.popBackStack() },
                onSongClick = onSongClick,
                onAlbumClick = { album ->
                    navController.navigate(Screen.AlbumDetail.createRoute(album.id))
                },
                onArtistClick = { artist ->
                    navController.navigate(Screen.ArtistDetail.createRoute(artist.id))
                },
                onPlaylistClick = { playlist ->
                    navController.navigate(Screen.PlaylistDetail.createRoute(playlist.id))
                }
            )
        }
        
        composable(Screen.Favorites.route) {
            FavoritesScreen(
                onBackClick = { navController.popBackStack() },
                onSongClick = onSongClick
            )
        }
        
        composable(Screen.Equalizer.route) {
            EqualizerScreen(
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}

/**
 * Pantalla de detalle de álbum (placeholder).
 */
@Composable
private fun AlbumDetailScreen(
    albumId: Long,
    onBackClick: () -> Unit,
    onSongClick: (Song) -> Unit
) {
    // Implementación completa en AlbumsScreen.kt
    com.musicplayer.pro.presentation.screens.AlbumDetailScreen(
        albumId = albumId,
        onBackClick = onBackClick,
        onSongClick = onSongClick
    )
}

/**
 * Pantalla de detalle de artista (placeholder).
 */
@Composable
private fun ArtistDetailScreen(
    artistId: Long,
    onBackClick: () -> Unit,
    onAlbumClick: (Album) -> Unit,
    onSongClick: (Song) -> Unit
) {
    // Implementación completa en ArtistsScreen.kt
    com.musicplayer.pro.presentation.screens.ArtistDetailScreen(
        artistId = artistId,
        onBackClick = onBackClick,
        onAlbumClick = onAlbumClick,
        onSongClick = onSongClick
    )
}

/**
 * Pantalla de detalle de playlist.
 */
@Composable
private fun PlaylistDetailScreen(
    playlistId: Long,
    onBackClick: () -> Unit,
    onSongClick: (Song) -> Unit
) {
    // TODO: Implementar pantalla de detalle de playlist
    androidx.compose.foundation.layout.Box(
        modifier = Modifier,
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.material3.Text("Playlist Detail: $playlistId")
    }
}

/**
 * Extensión para navegar a una pestaña del bottom navigation.
 */
fun NavHostController.navigateToTab(tab: BottomNavTab) {
    val route = when (tab) {
        BottomNavTab.SONGS -> Screen.Songs.route
        BottomNavTab.ALBUMS -> Screen.Albums.route
        BottomNavTab.ARTISTS -> Screen.Artists.route
        BottomNavTab.FOLDERS -> Screen.Folders.route
        BottomNavTab.PLAYLISTS -> Screen.Playlists.route
    }
    
    navigate(route) {
        popUpTo(graph.startDestinationId) {
            saveState = true
        }
        launchSingleTop = true
        restoreState = true
    }
}
