package com.musicplayer.pro.domain.model

/**
 * Modelo de dominio que representa un artista.
 */
data class Artist(
    val id: Long,
    val mediaStoreId: Long,
    val name: String,
    val songCount: Int,
    val albumCount: Int,
    val albumArtUri: String? = null
) {
    /**
     * Descripción del contenido (álbumes y canciones).
     */
    val contentDescription: String
        get() {
            val albumText = if (albumCount == 1) "1 álbum" else "$albumCount álbumes"
            val songText = if (songCount == 1) "1 canción" else "$songCount canciones"
            return "$albumText • $songText"
        }

    /**
     * Descripción corta (solo canciones).
     */
    val shortDescription: String
        get() = if (songCount == 1) "1 canción" else "$songCount canciones"

    companion object {
        /**
         * Crea un artista vacío/placeholder.
         */
        fun empty() = Artist(
            id = 0,
            mediaStoreId = 0,
            name = "",
            songCount = 0,
            albumCount = 0
        )
    }
}
