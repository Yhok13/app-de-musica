package com.musicplayer.pro.domain.repository

import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.domain.model.Song
import kotlinx.coroutines.flow.Flow

/**
 * Interfaz del repositorio de playlists.
 * Define las operaciones CRUD para playlists.
 */
interface PlaylistRepository {

    /**
     * Obtiene todas las playlists.
     */
    fun getAllPlaylists(): Flow<List<Playlist>>

    /**
     * Obtiene una playlist por su ID.
     */
    suspend fun getPlaylistById(playlistId: Long): Playlist?

    /**
     * Obtiene una playlist por su ID como Flow.
     */
    fun getPlaylistByIdFlow(playlistId: Long): Flow<Playlist?>

    /**
     * Obtiene las canciones de una playlist.
     */
    fun getPlaylistSongs(playlistId: Long): Flow<List<Song>>

    /**
     * Crea una nueva playlist.
     * @return ID de la playlist creada.
     */
    suspend fun createPlaylist(name: String, description: String? = null): Long

    /**
     * Actualiza el nombre de una playlist.
     */
    suspend fun updatePlaylistName(playlistId: Long, name: String)

    /**
     * Elimina una playlist.
     */
    suspend fun deletePlaylist(playlistId: Long)

    /**
     * Añade una canción a una playlist.
     */
    suspend fun addSongToPlaylist(playlistId: Long, songId: Long)

    /**
     * Añade múltiples canciones a una playlist.
     */
    suspend fun addSongsToPlaylist(playlistId: Long, songIds: List<Long>)

    /**
     * Elimina una canción de una playlist.
     */
    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long)

    /**
     * Actualiza la posición de una canción en una playlist.
     */
    suspend fun updateSongPosition(playlistId: Long, songId: Long, newPosition: Int)

    /**
     * Verifica si una canción está en una playlist.
     */
    suspend fun isSongInPlaylist(playlistId: Long, songId: Long): Boolean

    /**
     * Busca playlists por nombre.
     */
    fun searchPlaylists(query: String): Flow<List<Playlist>>

    /**
     * Obtiene el conteo total de playlists.
     */
    suspend fun getPlaylistCount(): Int
}
