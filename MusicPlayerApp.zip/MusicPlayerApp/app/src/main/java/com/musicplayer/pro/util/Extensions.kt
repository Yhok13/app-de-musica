package com.musicplayer.pro.util

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.compose.ui.graphics.Color
import androidx.core.content.FileProvider
import com.musicplayer.pro.domain.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

/**
 * Extensiones y utilidades generales para la aplicación.
 */

// ==================== Extensiones de Duración ====================

/**
 * Formatea milisegundos a formato MM:SS o HH:MM:SS.
 */
fun Long.formatDuration(): String {
    val totalSeconds = this / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60

    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%d:%02d", minutes, seconds)
    }
}

/**
 * Formatea bytes a formato legible (KB, MB, GB).
 */
fun Long.formatFileSize(): String {
    val kb = this / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0

    return when {
        gb >= 1 -> String.format("%.2f GB", gb)
        mb >= 1 -> String.format("%.2f MB", mb)
        else -> String.format("%.2f KB", kb)
    }
}

// ==================== Extensiones de Contexto ====================

/**
 * Muestra un Toast corto.
 */
fun Context.showToast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

/**
 * Muestra un Toast largo.
 */
fun Context.showLongToast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}

/**
 * Comparte un archivo de audio.
 */
fun Context.shareAudioFile(song: Song) {
    try {
        val file = File(song.filePath)
        val uri = FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = song.mimeType.ifEmpty { "audio/*" }
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, song.title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        startActivity(Intent.createChooser(intent, "Compartir canción"))
    } catch (e: Exception) {
        showToast("Error al compartir: ${e.message}")
    }
}

/**
 * Establece una canción como tono de llamada.
 */
fun Context.setAsRingtone(song: Song) {
    try {
        // Verificar permiso WRITE_SETTINGS
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
                showToast("Por favor, concede el permiso para modificar configuración del sistema")
                return
            }
        }

        val uri = ContentUris.withAppendedId(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            song.mediaStoreId
        )

        RingtoneManager.setActualDefaultRingtoneUri(
            this,
            RingtoneManager.TYPE_RINGTONE,
            uri
        )

        showToast("${song.title} establecida como tono de llamada")
    } catch (e: Exception) {
        showToast("Error al establecer tono: ${e.message}")
    }
}

// ==================== Generador de Colores para Placeholders ====================

/**
 * Genera un color basado en un string (para placeholders de carátulas).
 */
fun String.toGradientColors(): Pair<Color, Color> {
    val hash = this.hashCode()
    
    // Generar colores basados en el hash
    val hue1 = abs(hash % 360).toFloat()
    val hue2 = (hue1 + 30) % 360
    
    val color1 = Color.hsl(hue1, 0.6f, 0.5f)
    val color2 = Color.hsl(hue2, 0.7f, 0.4f)
    
    return Pair(color1, color2)
}

/**
 * Genera un color sólido basado en un string.
 */
fun String.toColor(): Color {
    val hash = this.hashCode()
    val hue = abs(hash % 360).toFloat()
    return Color.hsl(hue, 0.5f, 0.5f)
}

/**
 * Lista de colores predefinidos para gradientes.
 */
object GradientColors {
    val gradients = listOf(
        Pair(Color(0xFF667eea), Color(0xFF764ba2)),
        Pair(Color(0xFFf093fb), Color(0xFFf5576c)),
        Pair(Color(0xFF4facfe), Color(0xFF00f2fe)),
        Pair(Color(0xFF43e97b), Color(0xFF38f9d7)),
        Pair(Color(0xFFfa709a), Color(0xFFfee140)),
        Pair(Color(0xFF30cfd0), Color(0xFF330867)),
        Pair(Color(0xFFa8edea), Color(0xFFfed6e3)),
        Pair(Color(0xFFff9a9e), Color(0xFFfecfef)),
        Pair(Color(0xFFffecd2), Color(0xFFfcb69f)),
        Pair(Color(0xFF667eea), Color(0xFF764ba2))
    )

    /**
     * Obtiene un gradiente basado en un índice o string.
     */
    fun getGradient(seed: Any): Pair<Color, Color> {
        val index = when (seed) {
            is Int -> seed
            is Long -> seed.toInt()
            is String -> abs(seed.hashCode())
            else -> 0
        }
        return gradients[index % gradients.size]
    }
}

// ==================== Carga de Artwork ====================

/**
 * Carga el artwork de un álbum de forma asíncrona.
 */
suspend fun loadAlbumArt(
    contentResolver: ContentResolver,
    albumId: Long
): Bitmap? = withContext(Dispatchers.IO) {
    try {
        val uri = ContentUris.withAppendedId(
            Uri.parse("content://media/external/audio/albumart"),
            albumId
        )
        contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream)
        }
    } catch (e: Exception) {
        null
    }
}

/**
 * Carga el artwork desde una URI.
 */
suspend fun loadArtworkFromUri(
    contentResolver: ContentResolver,
    uri: String?
): Bitmap? = withContext(Dispatchers.IO) {
    if (uri.isNullOrEmpty()) return@withContext null
    
    try {
        contentResolver.openInputStream(Uri.parse(uri))?.use { stream ->
            BitmapFactory.decodeStream(stream)
        }
    } catch (e: Exception) {
        null
    }
}

// ==================== Extensiones de Color ====================

/**
 * Crea un color HSL.
 */
fun Color.Companion.hsl(hue: Float, saturation: Float, lightness: Float): Color {
    val c = (1 - abs(2 * lightness - 1)) * saturation
    val x = c * (1 - abs((hue / 60) % 2 - 1))
    val m = lightness - c / 2

    val (r, g, b) = when {
        hue < 60 -> Triple(c, x, 0f)
        hue < 120 -> Triple(x, c, 0f)
        hue < 180 -> Triple(0f, c, x)
        hue < 240 -> Triple(0f, x, c)
        hue < 300 -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }

    return Color(
        red = r + m,
        green = g + m,
        blue = b + m
    )
}

// ==================== Validaciones ====================

/**
 * Verifica si un archivo de audio existe.
 */
fun Song.fileExists(): Boolean {
    return File(filePath).exists()
}

/**
 * Obtiene la extensión del archivo.
 */
fun String.getFileExtension(): String {
    return substringAfterLast('.', "").uppercase()
}

/**
 * Verifica si es un formato de audio soportado.
 */
fun String.isSupportedAudioFormat(): Boolean {
    val extension = getFileExtension().lowercase()
    return extension in listOf("mp3", "flac", "ogg", "wav", "aac", "m4a")
}
