package com.musicplayer.pro.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.musicplayer.pro.presentation.theme.CustomShapes
import com.musicplayer.pro.presentation.theme.PlaceholderGradients
import com.musicplayer.pro.presentation.theme.Sizes
import kotlin.math.abs

/**
 * Componente de carátula de álbum con soporte para placeholder con gradiente.
 */
@Composable
fun AlbumArt(
    albumArtUri: String?,
    contentDescription: String,
    modifier: Modifier = Modifier,
    size: Dp = Sizes.AlbumArtMedium,
    placeholderSeed: String = "",
    elevation: Dp = 8.dp,
    shape: androidx.compose.ui.graphics.Shape = CustomShapes.AlbumArt
) {
    val context = LocalContext.current
    
    // Generar gradiente basado en el seed
    val gradientColors = remember(placeholderSeed) {
        PlaceholderGradients.getGradient(placeholderSeed.hashCode())
    }
    
    Box(
        modifier = modifier
            .size(size)
            .shadow(elevation = elevation, shape = shape)
            .clip(shape)
    ) {
        if (albumArtUri.isNullOrEmpty()) {
            // Placeholder con gradiente
            AlbumArtPlaceholder(
                gradientColors = gradientColors,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(albumArtUri)
                    .crossfade(true)
                    .build(),
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/**
 * Placeholder de carátula con gradiente y icono de nota musical.
 */
@Composable
fun AlbumArtPlaceholder(
    gradientColors: List<Color>,
    modifier: Modifier = Modifier,
    iconSize: Dp = 48.dp
) {
    Box(
        modifier = modifier
            .background(
                brush = Brush.linearGradient(colors = gradientColors)
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Filled.MusicNote,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.7f),
            modifier = Modifier.size(iconSize)
        )
    }
}

/**
 * Carátula grande para la pantalla de reproducción.
 */
@Composable
fun LargeAlbumArt(
    albumArtUri: String?,
    songTitle: String,
    modifier: Modifier = Modifier
) {
    AlbumArt(
        albumArtUri = albumArtUri,
        contentDescription = "Carátula de $songTitle",
        modifier = modifier,
        size = Sizes.AlbumArtLarge,
        placeholderSeed = songTitle,
        elevation = 16.dp
    )
}

/**
 * Carátula pequeña para listas.
 */
@Composable
fun SmallAlbumArt(
    albumArtUri: String?,
    contentDescription: String,
    modifier: Modifier = Modifier,
    placeholderSeed: String = ""
) {
    AlbumArt(
        albumArtUri = albumArtUri,
        contentDescription = contentDescription,
        modifier = modifier,
        size = Sizes.AlbumArtSmall,
        placeholderSeed = placeholderSeed,
        elevation = 2.dp,
        shape = CustomShapes.AlbumArtSmall
    )
}

/**
 * Carátula diminuta para mini player.
 */
@Composable
fun TinyAlbumArt(
    albumArtUri: String?,
    contentDescription: String,
    modifier: Modifier = Modifier,
    placeholderSeed: String = ""
) {
    AlbumArt(
        albumArtUri = albumArtUri,
        contentDescription = contentDescription,
        modifier = modifier,
        size = Sizes.AlbumArtTiny,
        placeholderSeed = placeholderSeed,
        elevation = 0.dp,
        shape = CustomShapes.AlbumArtSmall
    )
}

/**
 * Carátula con animación de rotación (para efecto de disco girando).
 */
@Composable
fun RotatingAlbumArt(
    albumArtUri: String?,
    songTitle: String,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    // La animación de rotación se puede agregar aquí si se desea
    LargeAlbumArt(
        albumArtUri = albumArtUri,
        songTitle = songTitle,
        modifier = modifier
    )
}
