package com.musicplayer.pro.presentation.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.musicplayer.pro.presentation.theme.PlayerColors
import com.musicplayer.pro.presentation.theme.Sizes

/**
 * Barra de progreso de reproducción con estilo premium.
 */
@Composable
fun MusicProgressBar(
    progress: Float,
    currentTime: String,
    totalTime: String,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    var isDragging by remember { mutableStateOf(false) }
    var dragProgress by remember { mutableFloatStateOf(progress) }

    val displayProgress = if (isDragging) dragProgress else progress

    Column(modifier = modifier.fillMaxWidth()) {
        // Slider
        Slider(
            value = displayProgress.coerceIn(0f, 1f),
            onValueChange = { newValue ->
                isDragging = true
                dragProgress = newValue
            },
            onValueChangeFinished = {
                onSeek(dragProgress)
                isDragging = false
            },
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
            ),
            modifier = Modifier.fillMaxWidth()
        )

        // Tiempos
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Sizes.PaddingSmall),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = currentTime,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = totalTime,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Barra de progreso personalizada con Canvas.
 */
@Composable
fun CustomProgressBar(
    progress: Float,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = Sizes.ProgressBarHeightLarge,
    activeColor: Color = PlayerColors.SeekBarActive,
    inactiveColor: Color = PlayerColors.SeekBarInactive,
    thumbColor: Color = MaterialTheme.colorScheme.primary,
    showThumb: Boolean = true
) {
    var isDragging by remember { mutableStateOf(false) }
    var dragProgress by remember { mutableFloatStateOf(progress) }

    val displayProgress = if (isDragging) dragProgress else progress
    val animatedProgress by animateFloatAsState(
        targetValue = displayProgress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = if (isDragging) 0 else 100),
        label = "progress"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height + 16.dp)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val newProgress = (offset.x / size.width).coerceIn(0f, 1f)
                    onSeek(newProgress)
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { isDragging = true },
                    onDragEnd = {
                        onSeek(dragProgress)
                        isDragging = false
                    },
                    onDragCancel = { isDragging = false },
                    onHorizontalDrag = { _, dragAmount ->
                        val delta = dragAmount / size.width
                        dragProgress = (dragProgress + delta).coerceIn(0f, 1f)
                    }
                )
            }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(height)
                .padding(vertical = 8.dp)
        ) {
            val cornerRadius = CornerRadius(height.toPx() / 2)

            // Fondo inactivo
            drawRoundRect(
                color = inactiveColor,
                size = Size(size.width, height.toPx()),
                cornerRadius = cornerRadius
            )

            // Progreso activo
            if (animatedProgress > 0) {
                drawRoundRect(
                    color = activeColor,
                    size = Size(size.width * animatedProgress, height.toPx()),
                    cornerRadius = cornerRadius
                )
            }

            // Thumb
            if (showThumb) {
                val thumbRadius = height.toPx() * 1.5f
                val thumbX = size.width * animatedProgress
                drawCircle(
                    color = thumbColor,
                    radius = thumbRadius,
                    center = Offset(thumbX, height.toPx() / 2)
                )
            }
        }
    }
}

/**
 * Barra de progreso lineal simple (sin interacción).
 */
@Composable
fun LinearProgressIndicator(
    progress: Float,
    modifier: Modifier = Modifier,
    height: Dp = Sizes.ProgressBarHeight,
    activeColor: Color = MaterialTheme.colorScheme.primary,
    inactiveColor: Color = MaterialTheme.colorScheme.surfaceVariant
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 100),
        label = "progress"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val cornerRadius = CornerRadius(height.toPx() / 2)

        // Fondo
        drawRoundRect(
            color = inactiveColor,
            size = Size(size.width, height.toPx()),
            cornerRadius = cornerRadius
        )

        // Progreso
        if (animatedProgress > 0) {
            drawRoundRect(
                color = activeColor,
                size = Size(size.width * animatedProgress, height.toPx()),
                cornerRadius = cornerRadius
            )
        }
    }
}

/**
 * Mini barra de progreso para el mini player.
 */
@Composable
fun MiniProgressBar(
    progress: Float,
    modifier: Modifier = Modifier
) {
    LinearProgressIndicator(
        progress = progress,
        modifier = modifier,
        height = 2.dp
    )
}
