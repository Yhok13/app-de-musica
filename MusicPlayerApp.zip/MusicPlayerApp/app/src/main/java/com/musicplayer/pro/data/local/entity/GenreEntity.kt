package com.musicplayer.pro.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entidad Room que representa un género musical en la base de datos local.
 */
@Entity(
    tableName = "genres",
    indices = [
        Index(value = ["media_store_id"], unique = true)
    ]
)
data class GenreEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "media_store_id")
    val mediaStoreId: Long,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "song_count")
    val songCount: Int
)
