package com.musicplayer.pro.util

import android.content.Context
import android.content.SharedPreferences
import com.musicplayer.pro.domain.model.RepeatMode
import com.musicplayer.pro.domain.model.ShuffleMode
import com.musicplayer.pro.presentation.state.SortOrder
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gestor de preferencias de la aplicación.
 * Almacena y recupera configuraciones del usuario.
 */
@Singleton
class PreferencesManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    // ==================== Reproducción ====================

    private val _shuffleMode = MutableStateFlow(getShuffleMode())
    val shuffleMode: StateFlow<ShuffleMode> = _shuffleMode.asStateFlow()

    private val _repeatMode = MutableStateFlow(getRepeatMode())
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    fun setShuffleMode(mode: ShuffleMode) {
        prefs.edit().putString(KEY_SHUFFLE_MODE, mode.name).apply()
        _shuffleMode.value = mode
    }

    fun getShuffleMode(): ShuffleMode {
        val name = prefs.getString(KEY_SHUFFLE_MODE, ShuffleMode.OFF.name)
        return try {
            ShuffleMode.valueOf(name ?: ShuffleMode.OFF.name)
        } catch (e: Exception) {
            ShuffleMode.OFF
        }
    }

    fun setRepeatMode(mode: RepeatMode) {
        prefs.edit().putString(KEY_REPEAT_MODE, mode.name).apply()
        _repeatMode.value = mode
    }

    fun getRepeatMode(): RepeatMode {
        val name = prefs.getString(KEY_REPEAT_MODE, RepeatMode.OFF.name)
        return try {
            RepeatMode.valueOf(name ?: RepeatMode.OFF.name)
        } catch (e: Exception) {
            RepeatMode.OFF
        }
    }

    // ==================== Ordenamiento ====================

    fun setSortOrder(order: SortOrder) {
        prefs.edit().putString(KEY_SORT_ORDER, order.name).apply()
    }

    fun getSortOrder(): SortOrder {
        val name = prefs.getString(KEY_SORT_ORDER, SortOrder.TITLE_ASC.name)
        return try {
            SortOrder.valueOf(name ?: SortOrder.TITLE_ASC.name)
        } catch (e: Exception) {
            SortOrder.TITLE_ASC
        }
    }

    // ==================== Última canción reproducida ====================

    fun setLastPlayedSongId(songId: Long) {
        prefs.edit().putLong(KEY_LAST_SONG_ID, songId).apply()
    }

    fun getLastPlayedSongId(): Long {
        return prefs.getLong(KEY_LAST_SONG_ID, -1L)
    }

    fun setLastPlayedPosition(position: Long) {
        prefs.edit().putLong(KEY_LAST_POSITION, position).apply()
    }

    fun getLastPlayedPosition(): Long {
        return prefs.getLong(KEY_LAST_POSITION, 0L)
    }

    // ==================== Ecualizador ====================

    fun setEqualizerEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_EQ_ENABLED, enabled).apply()
    }

    fun isEqualizerEnabled(): Boolean {
        return prefs.getBoolean(KEY_EQ_ENABLED, false)
    }

    fun setEqualizerBandLevels(levels: List<Int>) {
        val levelsString = levels.joinToString(",")
        prefs.edit().putString(KEY_EQ_BAND_LEVELS, levelsString).apply()
    }

    fun getEqualizerBandLevels(): List<Int> {
        val levelsString = prefs.getString(KEY_EQ_BAND_LEVELS, "0,0,0,0,0")
        return levelsString?.split(",")?.mapNotNull { it.toIntOrNull() } ?: listOf(0, 0, 0, 0, 0)
    }

    fun setBassBoostStrength(strength: Int) {
        prefs.edit().putInt(KEY_BASS_BOOST, strength).apply()
    }

    fun getBassBoostStrength(): Int {
        return prefs.getInt(KEY_BASS_BOOST, 0)
    }

    // ==================== UI ====================

    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DARK_MODE, enabled).apply()
    }

    fun isDarkMode(): Boolean {
        return prefs.getBoolean(KEY_DARK_MODE, true)
    }

    fun setDynamicColors(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DYNAMIC_COLORS, enabled).apply()
    }

    fun isDynamicColorsEnabled(): Boolean {
        return prefs.getBoolean(KEY_DYNAMIC_COLORS, true)
    }

    // ==================== Primera ejecución ====================

    fun setFirstLaunch(isFirst: Boolean) {
        prefs.edit().putBoolean(KEY_FIRST_LAUNCH, isFirst).apply()
    }

    fun isFirstLaunch(): Boolean {
        return prefs.getBoolean(KEY_FIRST_LAUNCH, true)
    }

    // ==================== Escaneo ====================

    fun setLastScanTime(timestamp: Long) {
        prefs.edit().putLong(KEY_LAST_SCAN_TIME, timestamp).apply()
    }

    fun getLastScanTime(): Long {
        return prefs.getLong(KEY_LAST_SCAN_TIME, 0L)
    }

    // ==================== Velocidad de reproducción ====================

    fun setPlaybackSpeed(speed: Float) {
        prefs.edit().putFloat(KEY_PLAYBACK_SPEED, speed).apply()
    }

    fun getPlaybackSpeed(): Float {
        return prefs.getFloat(KEY_PLAYBACK_SPEED, 1.0f)
    }

    // ==================== Limpiar preferencias ====================

    fun clearAll() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val PREFS_NAME = "music_player_prefs"

        // Keys
        private const val KEY_SHUFFLE_MODE = "shuffle_mode"
        private const val KEY_REPEAT_MODE = "repeat_mode"
        private const val KEY_SORT_ORDER = "sort_order"
        private const val KEY_LAST_SONG_ID = "last_song_id"
        private const val KEY_LAST_POSITION = "last_position"
        private const val KEY_EQ_ENABLED = "eq_enabled"
        private const val KEY_EQ_BAND_LEVELS = "eq_band_levels"
        private const val KEY_BASS_BOOST = "bass_boost"
        private const val KEY_DARK_MODE = "dark_mode"
        private const val KEY_DYNAMIC_COLORS = "dynamic_colors"
        private const val KEY_FIRST_LAUNCH = "first_launch"
        private const val KEY_LAST_SCAN_TIME = "last_scan_time"
        private const val KEY_PLAYBACK_SPEED = "playback_speed"
    }
}
