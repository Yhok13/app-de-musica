package com.musicplayer.pro.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.musicplayer.pro.data.local.entity.FolderEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO para operaciones de base de datos relacionadas con carpetas.
 */
@Dao
interface FolderDao {

    /**
     * Obtiene todas las carpetas ordenadas por nombre.
     */
    @Query("SELECT * FROM folders ORDER BY name ASC")
    fun getAllFolders(): Flow<List<FolderEntity>>

    /**
     * Obtiene carpetas raíz (sin padre).
     */
    @Query("SELECT * FROM folders WHERE parent_path IS NULL OR parent_path = '' ORDER BY name ASC")
    fun getRootFolders(): Flow<List<FolderEntity>>

    /**
     * Obtiene subcarpetas de una carpeta padre.
     */
    @Query("SELECT * FROM folders WHERE parent_path = :parentPath ORDER BY name ASC")
    fun getSubFolders(parentPath: String): Flow<List<FolderEntity>>

    /**
     * Obtiene una carpeta por su ruta.
     */
    @Query("SELECT * FROM folders WHERE path = :path")
    suspend fun getFolderByPath(path: String): FolderEntity?

    /**
     * Obtiene una carpeta por su ID.
     */
    @Query("SELECT * FROM folders WHERE id = :folderId")
    suspend fun getFolderById(folderId: Long): FolderEntity?

    /**
     * Busca carpetas por nombre.
     */
    @Query("SELECT * FROM folders WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchFolders(query: String): Flow<List<FolderEntity>>

    /**
     * Obtiene el conteo total de carpetas.
     */
    @Query("SELECT COUNT(*) FROM folders")
    suspend fun getFolderCount(): Int

    /**
     * Inserta una carpeta.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: FolderEntity): Long

    /**
     * Inserta múltiples carpetas.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolders(folders: List<FolderEntity>)

    /**
     * Actualiza una carpeta.
     */
    @Update
    suspend fun updateFolder(folder: FolderEntity)

    /**
     * Actualiza el conteo de canciones de una carpeta.
     */
    @Query("UPDATE folders SET song_count = :count WHERE path = :path")
    suspend fun updateSongCount(path: String, count: Int)

    /**
     * Elimina una carpeta.
     */
    @Delete
    suspend fun deleteFolder(folder: FolderEntity)

    /**
     * Elimina todas las carpetas.
     */
    @Query("DELETE FROM folders")
    suspend fun deleteAllFolders()

    /**
     * Elimina carpetas vacías (sin canciones).
     */
    @Query("DELETE FROM folders WHERE song_count = 0")
    suspend fun deleteEmptyFolders()

    /**
     * Obtiene todas las rutas de carpetas existentes.
     */
    @Query("SELECT path FROM folders")
    suspend fun getAllFolderPaths(): List<String>
}
