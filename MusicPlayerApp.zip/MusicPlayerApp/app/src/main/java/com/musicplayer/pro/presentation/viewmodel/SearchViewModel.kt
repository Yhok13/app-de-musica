package com.musicplayer.pro.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicplayer.pro.domain.usecase.SearchAlbumsUseCase
import com.musicplayer.pro.domain.usecase.SearchArtistsUseCase
import com.musicplayer.pro.domain.usecase.SearchPlaylistsUseCase
import com.musicplayer.pro.domain.usecase.SearchSongsUseCase
import com.musicplayer.pro.presentation.state.SearchUiState
import com.musicplayer.pro.presentation.state.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel para la búsqueda global.
 */
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val searchSongsUseCase: SearchSongsUseCase,
    private val searchAlbumsUseCase: SearchAlbumsUseCase,
    private val searchArtistsUseCase: SearchArtistsUseCase,
    private val searchPlaylistsUseCase: SearchPlaylistsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _events = Channel<UiEvent>()
    val events = _events.receiveAsFlow()

    private var searchJob: Job? = null

    /**
     * Realiza una búsqueda con debounce.
     */
    fun search(query: String) {
        _uiState.update { it.copy(query = query) }

        if (query.isBlank()) {
            clearResults()
            return
        }

        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(300) // Debounce de 300ms

            _uiState.update { it.copy(isSearching = true) }

            // Buscar en paralelo
            launch {
                searchSongsUseCase(query)
                    .catch { /* Ignorar errores */ }
                    .collectLatest { songs ->
                        _uiState.update { it.copy(songs = songs) }
                    }
            }

            launch {
                searchAlbumsUseCase(query)
                    .catch { /* Ignorar errores */ }
                    .collectLatest { albums ->
                        _uiState.update { it.copy(albums = albums) }
                    }
            }

            launch {
                searchArtistsUseCase(query)
                    .catch { /* Ignorar errores */ }
                    .collectLatest { artists ->
                        _uiState.update { it.copy(artists = artists) }
                    }
            }

            launch {
                searchPlaylistsUseCase(query)
                    .catch { /* Ignorar errores */ }
                    .collectLatest { playlists ->
                        _uiState.update { it.copy(playlists = playlists) }
                    }
            }

            _uiState.update { it.copy(isSearching = false, hasSearched = true) }
        }
    }

    /**
     * Limpia los resultados de búsqueda.
     */
    fun clearResults() {
        searchJob?.cancel()
        _uiState.update { 
            SearchUiState(query = "") 
        }
    }

    /**
     * Limpia la consulta de búsqueda.
     */
    fun clearQuery() {
        _uiState.update { it.copy(query = "") }
        clearResults()
    }

    /**
     * Verifica si hay resultados.
     */
    fun hasResults(): Boolean {
        val state = _uiState.value
        return state.songs.isNotEmpty() || 
               state.albums.isNotEmpty() || 
               state.artists.isNotEmpty() ||
               state.playlists.isNotEmpty()
    }

    /**
     * Obtiene el total de resultados.
     */
    fun getTotalResults(): Int {
        val state = _uiState.value
        return state.songs.size + state.albums.size + state.artists.size + state.playlists.size
    }
}
