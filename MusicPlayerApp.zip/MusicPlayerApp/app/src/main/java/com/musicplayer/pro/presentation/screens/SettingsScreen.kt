package com.musicplayer.pro.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.MainViewModel

/**
 * Pantalla de configuración de la aplicación.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBackClick: () -> Unit,
    onEqualizerClick: () -> Unit,
    onFavoritesClick: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: MainViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Configuración") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Atrás"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            // Sección: Reproducción
            SettingsSection(title = "Reproducción")
            
            SettingsItem(
                icon = Icons.Filled.Equalizer,
                title = "Ecualizador",
                subtitle = "Ajustar sonido y bajos",
                onClick = onEqualizerClick
            )
            
            SettingsItem(
                icon = Icons.Filled.Favorite,
                title = "Favoritos",
                subtitle = "Ver canciones favoritas",
                onClick = onFavoritesClick
            )

            Divider()

            // Sección: Apariencia
            SettingsSection(title = "Apariencia")
            
            SettingsSwitchItem(
                icon = Icons.Filled.ColorLens,
                title = "Tema dinámico",
                subtitle = "Usar colores del sistema (Material You)",
                checked = true,
                onCheckedChange = { /* Implementar cambio de tema */ }
            )

            Divider()

            // Sección: Biblioteca
            SettingsSection(title = "Biblioteca")
            
            SettingsItem(
                icon = Icons.Filled.Refresh,
                title = "Escanear biblioteca",
                subtitle = "Buscar nuevas canciones",
                onClick = { viewModel.scanMedia() }
            )
            
            SettingsItem(
                icon = Icons.Filled.Storage,
                title = "Estadísticas",
                subtitle = "${uiState.totalSongs} canciones • ${uiState.totalAlbums} álbumes • ${uiState.totalArtists} artistas",
                onClick = { }
            )

            Divider()

            // Sección: Notificaciones
            SettingsSection(title = "Notificaciones")
            
            SettingsSwitchItem(
                icon = Icons.Filled.Notifications,
                title = "Notificación de reproducción",
                subtitle = "Mostrar controles en la barra de estado",
                checked = true,
                onCheckedChange = { /* Implementar */ }
            )

            Divider()

            // Sección: Acerca de
            SettingsSection(title = "Acerca de")
            
            SettingsItem(
                icon = Icons.Filled.Info,
                title = "Music Player Pro",
                subtitle = "Versión 1.0.0",
                onClick = { }
            )
        }
    }
}

/**
 * Título de sección de configuración.
 */
@Composable
private fun SettingsSection(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(
            horizontal = Sizes.PaddingMedium,
            vertical = Sizes.PaddingSmall
        )
    )
}

/**
 * Item de configuración clickeable.
 */
@Composable
private fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        leadingContent = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

/**
 * Item de configuración con switch.
 */
@Composable
private fun SettingsSwitchItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        leadingContent = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        trailingContent = {
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange
            )
        }
    )
}
