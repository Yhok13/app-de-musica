package com.musicplayer.pro.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicplayer.pro.domain.usecase.GetAllFavoritesUseCase
import com.musicplayer.pro.domain.usecase.GetFavoriteCountUseCase
import com.musicplayer.pro.domain.usecase.GetFavoriteSongIdsUseCase
import com.musicplayer.pro.domain.usecase.ToggleFavoriteUseCase
import com.musicplayer.pro.presentation.state.FavoritesUiState
import com.musicplayer.pro.presentation.state.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel para la gestión de canciones favoritas.
 */
@HiltViewModel
class FavoritesViewModel @Inject constructor(
    private val getAllFavoritesUseCase: GetAllFavoritesUseCase,
    private val toggleFavoriteUseCase: ToggleFavoriteUseCase,
    private val getFavoriteCountUseCase: GetFavoriteCountUseCase,
    private val getFavoriteSongIdsUseCase: GetFavoriteSongIdsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(FavoritesUiState())
    val uiState: StateFlow<FavoritesUiState> = _uiState.asStateFlow()

    private val _events = Channel<UiEvent>()
    val events = _events.receiveAsFlow()

    private val _favoriteSongIds = MutableStateFlow<Set<Long>>(emptySet())
    val favoriteSongIds: StateFlow<Set<Long>> = _favoriteSongIds.asStateFlow()

    init {
        loadFavorites()
        observeFavoriteSongIds()
    }

    /**
     * Carga todas las canciones favoritas.
     */
    fun loadFavorites() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            getAllFavoritesUseCase()
                .catch { error ->
                    _uiState.update { 
                        it.copy(isLoading = false, error = error.message) 
                    }
                }
                .collectLatest { favorites ->
                    _uiState.update { 
                        it.copy(favorites = favorites, isLoading = false, error = null) 
                    }
                }
        }
    }

    /**
     * Observa los IDs de canciones favoritas.
     */
    private fun observeFavoriteSongIds() {
        viewModelScope.launch {
            getFavoriteSongIdsUseCase.asFlow()
                .catch { /* Ignorar errores */ }
                .collectLatest { ids ->
                    _favoriteSongIds.value = ids.toSet()
                }
        }
    }

    /**
     * Alterna el estado de favorito de una canción.
     */
    fun toggleFavorite(songId: Long) {
        viewModelScope.launch {
            try {
                val isFavorite = toggleFavoriteUseCase(songId)
                val message = if (isFavorite) "Añadido a favoritos" else "Eliminado de favoritos"
                _events.send(UiEvent.ShowSnackbar(message))
            } catch (e: Exception) {
                _events.send(UiEvent.ShowSnackbar("Error: ${e.message}"))
            }
        }
    }

    /**
     * Verifica si una canción es favorita.
     */
    fun isFavorite(songId: Long): Boolean {
        return songId in _favoriteSongIds.value
    }

    /**
     * Obtiene el conteo de favoritos.
     */
    fun getFavoriteCount(): Int {
        return _uiState.value.favorites.size
    }

    /**
     * Refresca los favoritos.
     */
    fun refresh() {
        loadFavorites()
    }

    /**
     * Limpia el error.
     */
    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}
