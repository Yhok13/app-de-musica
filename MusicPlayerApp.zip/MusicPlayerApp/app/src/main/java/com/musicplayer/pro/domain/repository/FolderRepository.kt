package com.musicplayer.pro.domain.repository

import com.musicplayer.pro.domain.model.Folder
import com.musicplayer.pro.domain.model.Song
import kotlinx.coroutines.flow.Flow

/**
 * Interfaz del repositorio de carpetas.
 * Define las operaciones disponibles para navegar y acceder a carpetas con audio.
 */
interface FolderRepository {

    /**
     * Obtiene todas las carpetas.
     */
    fun getAllFolders(): Flow<List<Folder>>

    /**
     * Obtiene las carpetas raíz (sin padre).
     */
    fun getRootFolders(): Flow<List<Folder>>

    /**
     * Obtiene las subcarpetas de una carpeta padre.
     */
    fun getSubFolders(parentPath: String): Flow<List<Folder>>

    /**
     * Obtiene una carpeta por su ruta.
     */
    suspend fun getFolderByPath(path: String): Folder?

    /**
     * Obtiene una carpeta por su ID.
     */
    suspend fun getFolderById(folderId: Long): Folder?

    /**
     * Obtiene las canciones de una carpeta.
     */
    fun getSongsInFolder(folderPath: String): Flow<List<Song>>

    /**
     * Busca carpetas por nombre.
     */
    fun searchFolders(query: String): Flow<List<Folder>>

    /**
     * Obtiene el conteo total de carpetas.
     */
    suspend fun getFolderCount(): Int

    /**
     * Actualiza el conteo de canciones de una carpeta.
     */
    suspend fun updateFolderSongCount(folderPath: String)
}
