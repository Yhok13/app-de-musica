package com.musicplayer.pro.data.repository

import com.musicplayer.pro.data.local.dao.PlaylistDao
import com.musicplayer.pro.data.local.entity.PlaylistEntity
import com.musicplayer.pro.data.local.entity.PlaylistSongCrossRef
import com.musicplayer.pro.di.IoDispatcher
import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.repository.PlaylistRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implementación del repositorio de playlists.
 * Gestiona la creación, edición y eliminación de playlists.
 */
@Singleton
class PlaylistRepositoryImpl @Inject constructor(
    private val playlistDao: PlaylistDao,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : PlaylistRepository {

    /**
     * Obtiene todas las playlists.
     */
    override fun getAllPlaylists(): Flow<List<Playlist>> {
        return playlistDao.getAllPlaylists().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene una playlist por su ID.
     */
    override suspend fun getPlaylistById(playlistId: Long): Playlist? {
        return playlistDao.getPlaylistById(playlistId)?.toDomainModel()
    }

    /**
     * Obtiene una playlist por su ID como Flow.
     */
    override fun getPlaylistByIdFlow(playlistId: Long): Flow<Playlist?> {
        return playlistDao.getPlaylistByIdFlow(playlistId).map { it?.toDomainModel() }
    }

    /**
     * Obtiene las canciones de una playlist.
     */
    override fun getPlaylistSongs(playlistId: Long): Flow<List<Song>> {
        return playlistDao.getPlaylistSongs(playlistId).map { entities ->
            entities.map { entity ->
                Song(
                    id = entity.id,
                    mediaStoreId = entity.mediaStoreId,
                    title = entity.title,
                    artist = entity.artist,
                    artistId = entity.artistId,
                    album = entity.album,
                    albumId = entity.albumId,
                    genre = entity.genre,
                    duration = entity.duration,
                    filePath = entity.filePath,
                    folderPath = entity.folderPath,
                    folderName = entity.folderName,
                    fileName = entity.fileName,
                    fileSize = entity.fileSize,
                    mimeType = entity.mimeType,
                    bitrate = entity.bitrate,
                    sampleRate = entity.sampleRate,
                    trackNumber = entity.trackNumber,
                    year = entity.year,
                    albumArtUri = entity.albumArtUri,
                    dateAdded = entity.dateAdded,
                    dateModified = entity.dateModified,
                    isFavorite = entity.isFavorite,
                    playCount = entity.playCount,
                    lastPlayed = entity.lastPlayed
                )
            }
        }
    }

    /**
     * Crea una nueva playlist.
     */
    override suspend fun createPlaylist(name: String, description: String?): Long = withContext(ioDispatcher) {
        val playlist = PlaylistEntity(
            name = name,
            description = description
        )
        playlistDao.insertPlaylist(playlist)
    }

    /**
     * Actualiza el nombre de una playlist.
     */
    override suspend fun updatePlaylistName(playlistId: Long, name: String) = withContext(ioDispatcher) {
        playlistDao.updatePlaylistName(playlistId, name)
    }

    /**
     * Elimina una playlist.
     */
    override suspend fun deletePlaylist(playlistId: Long) = withContext(ioDispatcher) {
        playlistDao.deletePlaylistById(playlistId)
    }

    /**
     * Añade una canción a una playlist.
     */
    override suspend fun addSongToPlaylist(playlistId: Long, songId: Long) = withContext(ioDispatcher) {
        val maxPosition = playlistDao.getMaxPosition(playlistId)
        val crossRef = PlaylistSongCrossRef(
            playlistId = playlistId,
            songId = songId,
            position = maxPosition + 1
        )
        playlistDao.addSongToPlaylist(crossRef)
        playlistDao.updatePlaylistMetadata(playlistId)
    }

    /**
     * Añade múltiples canciones a una playlist.
     */
    override suspend fun addSongsToPlaylist(playlistId: Long, songIds: List<Long>) = withContext(ioDispatcher) {
        var position = playlistDao.getMaxPosition(playlistId) + 1
        val crossRefs = songIds.map { songId ->
            PlaylistSongCrossRef(
                playlistId = playlistId,
                songId = songId,
                position = position++
            )
        }
        playlistDao.addSongsToPlaylist(crossRefs)
        playlistDao.updatePlaylistMetadata(playlistId)
    }

    /**
     * Elimina una canción de una playlist.
     */
    override suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) = withContext(ioDispatcher) {
        playlistDao.removeSongFromPlaylist(playlistId, songId)
        playlistDao.updatePlaylistMetadata(playlistId)
    }

    /**
     * Actualiza la posición de una canción en una playlist.
     */
    override suspend fun updateSongPosition(playlistId: Long, songId: Long, newPosition: Int) = withContext(ioDispatcher) {
        playlistDao.updateSongPosition(playlistId, songId, newPosition)
    }

    /**
     * Verifica si una canción está en una playlist.
     */
    override suspend fun isSongInPlaylist(playlistId: Long, songId: Long): Boolean {
        return playlistDao.isSongInPlaylist(playlistId, songId)
    }

    /**
     * Busca playlists por nombre.
     */
    override fun searchPlaylists(query: String): Flow<List<Playlist>> {
        return playlistDao.searchPlaylists(query).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene el conteo total de playlists.
     */
    override suspend fun getPlaylistCount(): Int {
        return playlistDao.getPlaylistCount()
    }
}

/**
 * Extensión para convertir PlaylistEntity a modelo de dominio Playlist.
 */
private fun PlaylistEntity.toDomainModel(): Playlist {
    return Playlist(
        id = id,
        name = name,
        description = description,
        coverArtUri = coverArtUri,
        songCount = songCount,
        totalDuration = totalDuration,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}
