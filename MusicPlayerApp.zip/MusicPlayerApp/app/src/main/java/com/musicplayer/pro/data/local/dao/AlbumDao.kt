package com.musicplayer.pro.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.musicplayer.pro.data.local.entity.AlbumEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO para operaciones de base de datos relacionadas con álbumes.
 */
@Dao
interface AlbumDao {

    /**
     * Obtiene todos los álbumes ordenados por nombre.
     */
    @Query("SELECT * FROM albums ORDER BY name ASC")
    fun getAllAlbums(): Flow<List<AlbumEntity>>

    /**
     * Obtiene un álbum por su ID.
     */
    @Query("SELECT * FROM albums WHERE id = :albumId")
    suspend fun getAlbumById(albumId: Long): AlbumEntity?

    /**
     * Obtiene un álbum por su ID de MediaStore.
     */
    @Query("SELECT * FROM albums WHERE media_store_id = :mediaStoreId")
    suspend fun getAlbumByMediaStoreId(mediaStoreId: Long): AlbumEntity?

    /**
     * Obtiene álbumes por ID de artista.
     */
    @Query("SELECT * FROM albums WHERE artist_id = :artistId ORDER BY year DESC, name ASC")
    fun getAlbumsByArtist(artistId: Long): Flow<List<AlbumEntity>>

    /**
     * Busca álbumes por nombre.
     */
    @Query("SELECT * FROM albums WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchAlbums(query: String): Flow<List<AlbumEntity>>

    /**
     * Obtiene el conteo total de álbumes.
     */
    @Query("SELECT COUNT(*) FROM albums")
    suspend fun getAlbumCount(): Int

    /**
     * Inserta un álbum.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlbum(album: AlbumEntity): Long

    /**
     * Inserta múltiples álbumes.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlbums(albums: List<AlbumEntity>)

    /**
     * Actualiza un álbum.
     */
    @Update
    suspend fun updateAlbum(album: AlbumEntity)

    /**
     * Elimina un álbum.
     */
    @Delete
    suspend fun deleteAlbum(album: AlbumEntity)

    /**
     * Elimina todos los álbumes.
     */
    @Query("DELETE FROM albums")
    suspend fun deleteAllAlbums()

    /**
     * Obtiene todos los IDs de MediaStore existentes.
     */
    @Query("SELECT media_store_id FROM albums")
    suspend fun getAllMediaStoreIds(): List<Long>
}
