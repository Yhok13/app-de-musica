package com.musicplayer.pro.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.usecase.IncrementPlayCountUseCase
import com.musicplayer.pro.domain.usecase.IsFavoriteUseCase
import com.musicplayer.pro.domain.usecase.ToggleFavoriteUseCase
import com.musicplayer.pro.presentation.state.PlayerUiState
import com.musicplayer.pro.presentation.state.UiEvent
import com.musicplayer.pro.service.MusicController
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel para el reproductor de música.
 * Gestiona el estado de reproducción y la interacción con el servicio de música.
 */
@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val musicController: MusicController,
    private val toggleFavoriteUseCase: ToggleFavoriteUseCase,
    private val isFavoriteUseCase: IsFavoriteUseCase,
    private val incrementPlayCountUseCase: IncrementPlayCountUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val _events = Channel<UiEvent>()
    val events = _events.receiveAsFlow()

    init {
        initializeMusicController()
        observePlaybackState()
    }

    /**
     * Inicializa el controlador de música.
     */
    private fun initializeMusicController() {
        musicController.initialize()
    }

    /**
     * Observa el estado de reproducción.
     */
    private fun observePlaybackState() {
        viewModelScope.launch {
            combine(
                musicController.playbackState,
                musicController.currentSong,
                musicController.queue
            ) { playbackState, currentSong, queue ->
                Triple(playbackState, currentSong, queue)
            }.collectLatest { (playbackState, currentSong, queue) ->
                val isFavorite = currentSong?.let { 
                    isFavoriteUseCase(it.id) 
                } ?: false

                _uiState.update { state ->
                    state.copy(
                        playbackState = playbackState,
                        currentSong = currentSong,
                        queue = queue,
                        currentQueueIndex = playbackState.currentQueueIndex,
                        isFavorite = isFavorite
                    )
                }
            }
        }
    }

    /**
     * Reproduce una canción.
     */
    fun playSong(song: Song) {
        musicController.playSong(song)
        viewModelScope.launch {
            incrementPlayCountUseCase(song.id)
        }
    }

    /**
     * Reproduce una lista de canciones.
     */
    fun playSongs(songs: List<Song>, startIndex: Int = 0) {
        musicController.playSongs(songs, startIndex)
        if (startIndex in songs.indices) {
            viewModelScope.launch {
                incrementPlayCountUseCase(songs[startIndex].id)
            }
        }
    }

    /**
     * Alterna play/pause.
     */
    fun playPause() {
        musicController.playPause()
    }

    /**
     * Reproduce.
     */
    fun play() {
        musicController.play()
    }

    /**
     * Pausa.
     */
    fun pause() {
        musicController.pause()
    }

    /**
     * Salta a la siguiente canción.
     */
    fun skipToNext() {
        musicController.skipToNext()
        _uiState.value.currentSong?.let { song ->
            viewModelScope.launch {
                incrementPlayCountUseCase(song.id)
            }
        }
    }

    /**
     * Salta a la canción anterior.
     */
    fun skipToPrevious() {
        musicController.skipToPrevious()
    }

    /**
     * Busca una posición específica.
     */
    fun seekTo(positionMs: Long) {
        musicController.seekTo(positionMs)
    }

    /**
     * Busca una posición como porcentaje.
     */
    fun seekToProgress(progress: Float) {
        musicController.seekToProgress(progress)
    }

    /**
     * Alterna el modo aleatorio.
     */
    fun toggleShuffle() {
        musicController.toggleShuffle()
    }

    /**
     * Alterna el modo de repetición.
     */
    fun toggleRepeatMode() {
        musicController.toggleRepeatMode()
    }

    /**
     * Añade una canción a la cola.
     */
    fun addToQueue(song: Song) {
        musicController.addToQueue(song)
        viewModelScope.launch {
            _events.send(UiEvent.ShowSnackbar("Añadido a la cola"))
        }
    }

    /**
     * Reproduce una canción después de la actual.
     */
    fun playNext(song: Song) {
        musicController.playNext(song)
        viewModelScope.launch {
            _events.send(UiEvent.ShowSnackbar("Se reproducirá a continuación"))
        }
    }

    /**
     * Elimina una canción de la cola.
     */
    fun removeFromQueue(index: Int) {
        musicController.removeFromQueue(index)
    }

    /**
     * Mueve una canción en la cola.
     */
    fun moveQueueItem(fromIndex: Int, toIndex: Int) {
        musicController.moveQueueItem(fromIndex, toIndex)
    }

    /**
     * Limpia la cola.
     */
    fun clearQueue() {
        musicController.clearQueue()
        viewModelScope.launch {
            _events.send(UiEvent.ShowSnackbar("Cola limpiada"))
        }
    }

    /**
     * Salta a un elemento de la cola.
     */
    fun skipToQueueItem(index: Int) {
        musicController.skipToQueueItem(index)
    }

    /**
     * Alterna el estado de favorito de la canción actual.
     */
    fun toggleFavorite() {
        _uiState.value.currentSong?.let { song ->
            viewModelScope.launch {
                val isFavorite = toggleFavoriteUseCase(song.id)
                _uiState.update { it.copy(isFavorite = isFavorite) }
                
                val message = if (isFavorite) "Añadido a favoritos" else "Eliminado de favoritos"
                _events.send(UiEvent.ShowSnackbar(message))
            }
        }
    }

    /**
     * Alterna el estado de favorito de una canción específica.
     */
    fun toggleFavorite(songId: Long) {
        viewModelScope.launch {
            val isFavorite = toggleFavoriteUseCase(songId)
            
            // Actualizar el estado si es la canción actual
            if (_uiState.value.currentSong?.id == songId) {
                _uiState.update { it.copy(isFavorite = isFavorite) }
            }
            
            val message = if (isFavorite) "Añadido a favoritos" else "Eliminado de favoritos"
            _events.send(UiEvent.ShowSnackbar(message))
        }
    }

    /**
     * Expande o colapsa el reproductor.
     */
    fun setExpanded(expanded: Boolean) {
        _uiState.update { it.copy(isExpanded = expanded) }
    }

    /**
     * Muestra u oculta la cola.
     */
    fun setShowQueue(show: Boolean) {
        _uiState.update { it.copy(showQueue = show) }
    }

    /**
     * Establece la velocidad de reproducción.
     */
    fun setPlaybackSpeed(speed: Float) {
        musicController.setPlaybackSpeed(speed)
    }

    override fun onCleared() {
        super.onCleared()
        musicController.release()
    }
}
