package com.musicplayer.pro.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entidad Room que representa una carpeta con archivos de audio.
 */
@Entity(
    tableName = "folders",
    indices = [
        Index(value = ["path"], unique = true),
        Index(value = ["parent_path"])
    ]
)
data class FolderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "path")
    val path: String,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "parent_path")
    val parentPath: String?,

    @ColumnInfo(name = "song_count")
    val songCount: Int,

    @ColumnInfo(name = "total_size")
    val totalSize: Long,

    @ColumnInfo(name = "last_modified")
    val lastModified: Long
)
