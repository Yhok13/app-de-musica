package com.musicplayer.pro.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.presentation.components.SmallAlbumArt
import com.musicplayer.pro.presentation.theme.CustomShapes
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.PlaylistsViewModel

/**
 * Pantalla de playlists.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistsScreen(
    onPlaylistClick: (Playlist) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlaylistsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()
    
    var showCreateDialog by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }

    Scaffold(
        modifier = modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "Playlists")
                        if (uiState.playlists.isNotEmpty()) {
                            Text(
                                text = "${uiState.playlists.size} playlists",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                scrollBehavior = scrollBehavior
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true }
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = "Crear playlist"
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                uiState.isLoading -> {
                    LoadingState()
                }
                uiState.playlists.isEmpty() -> {
                    EmptyState(
                        icon = Icons.Filled.PlaylistPlay,
                        title = "No hay playlists",
                        message = "Crea tu primera playlist",
                        action = {
                            TextButton(onClick = { showCreateDialog = true }) {
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Crear playlist")
                            }
                        }
                    )
                }
                else -> {
                    PlaylistsList(
                        playlists = uiState.playlists,
                        onPlaylistClick = onPlaylistClick,
                        onEditClick = { playlist ->
                            viewModel.selectPlaylist(playlist)
                            viewModel.showEditDialog()
                        },
                        onDeleteClick = { playlist ->
                            viewModel.selectPlaylist(playlist)
                            viewModel.showDeleteDialog()
                        }
                    )
                }
            }
        }
    }

    // Diálogo de crear playlist
    if (showCreateDialog) {
        CreatePlaylistDialog(
            playlistName = playlistName,
            onNameChange = { playlistName = it },
            onDismiss = {
                showCreateDialog = false
                playlistName = ""
            },
            onConfirm = {
                viewModel.createPlaylist(playlistName)
                showCreateDialog = false
                playlistName = ""
            }
        )
    }

    // Diálogo de editar playlist
    if (uiState.showEditDialog) {
        var editName by remember { mutableStateOf(uiState.selectedPlaylist?.name ?: "") }
        
        EditPlaylistDialog(
            playlistName = editName,
            onNameChange = { editName = it },
            onDismiss = { viewModel.hideEditDialog() },
            onConfirm = {
                uiState.selectedPlaylist?.let { playlist ->
                    viewModel.updatePlaylistName(playlist.id, editName)
                }
            }
        )
    }

    // Diálogo de eliminar playlist
    if (uiState.showDeleteDialog) {
        DeletePlaylistDialog(
            playlistName = uiState.selectedPlaylist?.name ?: "",
            onDismiss = { viewModel.hideDeleteDialog() },
            onConfirm = {
                uiState.selectedPlaylist?.let { playlist ->
                    viewModel.deletePlaylist(playlist.id)
                }
            }
        )
    }
}

/**
 * Lista de playlists.
 */
@Composable
private fun PlaylistsList(
    playlists: List<Playlist>,
    onPlaylistClick: (Playlist) -> Unit,
    onEditClick: (Playlist) -> Unit,
    onDeleteClick: (Playlist) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(
            top = Sizes.PaddingSmall,
            bottom = 120.dp
        )
    ) {
        items(
            items = playlists,
            key = { it.id }
        ) { playlist ->
            PlaylistItem(
                playlist = playlist,
                onClick = { onPlaylistClick(playlist) },
                onEditClick = { onEditClick(playlist) },
                onDeleteClick = { onDeleteClick(playlist) }
            )
        }
    }
}

/**
 * Item de playlist.
 */
@Composable
private fun PlaylistItem(
    playlist: Playlist,
    onClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = Sizes.PaddingMedium, vertical = Sizes.PaddingTiny)
            .clip(CustomShapes.SongCard)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(Sizes.PaddingMedium),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Carátula de la playlist
            SmallAlbumArt(
                albumArtUri = playlist.coverArtUri,
                contentDescription = "Carátula de ${playlist.name}",
                placeholderSeed = playlist.name
            )

            Spacer(modifier = Modifier.width(Sizes.PaddingMedium))

            // Información de la playlist
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = playlist.name,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = "${playlist.songCount} canciones",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Menú de opciones
            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(
                        imageVector = Icons.Filled.MoreVert,
                        contentDescription = "Más opciones"
                    )
                }
                
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Editar") },
                        onClick = {
                            showMenu = false
                            onEditClick()
                        },
                        leadingIcon = {
                            Icon(Icons.Filled.Edit, contentDescription = null)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Eliminar") },
                        onClick = {
                            showMenu = false
                            onDeleteClick()
                        },
                        leadingIcon = {
                            Icon(Icons.Filled.Delete, contentDescription = null)
                        }
                    )
                }
            }
        }
    }
}

/**
 * Diálogo para crear playlist.
 */
@Composable
private fun CreatePlaylistDialog(
    playlistName: String,
    onNameChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva playlist") },
        text = {
            OutlinedTextField(
                value = playlistName,
                onValueChange = onNameChange,
                label = { Text("Nombre") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                enabled = playlistName.isNotBlank()
            ) {
                Text("Crear")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

/**
 * Diálogo para editar playlist.
 */
@Composable
private fun EditPlaylistDialog(
    playlistName: String,
    onNameChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar playlist") },
        text = {
            OutlinedTextField(
                value = playlistName,
                onValueChange = onNameChange,
                label = { Text("Nombre") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                enabled = playlistName.isNotBlank()
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

/**
 * Diálogo para eliminar playlist.
 */
@Composable
private fun DeletePlaylistDialog(
    playlistName: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Eliminar playlist") },
        text = { Text("¿Estás seguro de que quieres eliminar \"$playlistName\"?") },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("Eliminar", color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
