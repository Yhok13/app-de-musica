package com.musicplayer.pro.presentation.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.domain.model.RepeatMode
import com.musicplayer.pro.presentation.components.ControlButton
import com.musicplayer.pro.presentation.components.LargeAlbumArt
import com.musicplayer.pro.presentation.components.MusicProgressBar
import com.musicplayer.pro.presentation.components.NextButton
import com.musicplayer.pro.presentation.components.PlayPauseButton
import com.musicplayer.pro.presentation.components.PreviousButton
import com.musicplayer.pro.presentation.components.ToggleButton
import com.musicplayer.pro.presentation.theme.PlaceholderGradients
import com.musicplayer.pro.presentation.theme.PlayerColors
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.PlayerViewModel
import kotlinx.coroutines.launch

/**
 * Pantalla de reproducción actual (Now Playing).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    onBackClick: () -> Unit,
    onQueueClick: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlayerViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val currentSong = uiState.currentSong
    val playbackState = uiState.playbackState

    var showOptionsSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()
    val scope = rememberCoroutineScope()

    // Gradiente de fondo basado en la canción
    val gradientColors = remember(currentSong?.title) {
        PlaceholderGradients.getGradient(currentSong?.title?.hashCode() ?: 0)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        gradientColors[0].copy(alpha = 0.3f),
                        MaterialTheme.colorScheme.background
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = Sizes.PaddingLarge),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Barra superior
            NowPlayingTopBar(
                onBackClick = onBackClick,
                onQueueClick = onQueueClick,
                onMoreClick = { showOptionsSheet = true }
            )

            Spacer(modifier = Modifier.height(Sizes.PaddingExtraLarge))

            // Carátula del álbum
            LargeAlbumArt(
                albumArtUri = currentSong?.albumArtUri,
                songTitle = currentSong?.title ?: ""
            )

            Spacer(modifier = Modifier.height(Sizes.PaddingExtraLarge))

            // Información de la canción
            SongInfo(
                title = currentSong?.title ?: "Sin reproducción",
                artist = currentSong?.artist ?: "",
                album = currentSong?.album ?: "",
                isFavorite = uiState.isFavorite,
                onFavoriteClick = { viewModel.toggleFavorite() }
            )

            Spacer(modifier = Modifier.height(Sizes.PaddingLarge))

            // Barra de progreso
            MusicProgressBar(
                progress = playbackState.progress,
                currentTime = playbackState.formattedCurrentPosition,
                totalTime = playbackState.formattedDuration,
                onSeek = { viewModel.seekToProgress(it) },
                enabled = currentSong != null
            )

            Spacer(modifier = Modifier.height(Sizes.PaddingLarge))

            // Controles de reproducción
            PlaybackControls(
                isPlaying = playbackState.isPlaying,
                shuffleEnabled = playbackState.shuffleEnabled,
                repeatMode = playbackState.repeatMode,
                onPlayPauseClick = { viewModel.playPause() },
                onPreviousClick = { viewModel.skipToPrevious() },
                onNextClick = { viewModel.skipToNext() },
                onShuffleClick = { viewModel.toggleShuffle() },
                onRepeatClick = { viewModel.toggleRepeatMode() },
                enabled = currentSong != null
            )

            Spacer(modifier = Modifier.weight(1f))
        }

        // Bottom sheet de opciones
        if (showOptionsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showOptionsSheet = false },
                sheetState = sheetState
            ) {
                SongOptionsSheet(
                    song = currentSong,
                    onDismiss = {
                        scope.launch {
                            sheetState.hide()
                            showOptionsSheet = false
                        }
                    }
                )
            }
        }
    }
}

/**
 * Barra superior de la pantalla Now Playing.
 */
@Composable
private fun NowPlayingTopBar(
    onBackClick: () -> Unit,
    onQueueClick: () -> Unit,
    onMoreClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = Sizes.PaddingSmall),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBackClick) {
            Icon(
                imageVector = Icons.Filled.KeyboardArrowDown,
                contentDescription = "Cerrar",
                modifier = Modifier.size(32.dp)
            )
        }

        Text(
            text = "REPRODUCIENDO",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row {
            IconButton(onClick = onQueueClick) {
                Icon(
                    imageVector = Icons.Filled.QueueMusic,
                    contentDescription = "Cola de reproducción"
                )
            }
            IconButton(onClick = onMoreClick) {
                Icon(
                    imageVector = Icons.Filled.MoreVert,
                    contentDescription = "Más opciones"
                )
            }
        }
    }
}

/**
 * Información de la canción actual.
 */
@Composable
private fun SongInfo(
    title: String,
    artist: String,
    album: String,
    isFavorite: Boolean,
    onFavoriteClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = artist,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            
            if (album.isNotEmpty()) {
                Text(
                    text = album,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        IconButton(onClick = onFavoriteClick) {
            Icon(
                imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = if (isFavorite) "Quitar de favoritos" else "Añadir a favoritos",
                tint = if (isFavorite) PlayerColors.FavoriteActive else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

/**
 * Controles de reproducción.
 */
@Composable
private fun PlaybackControls(
    isPlaying: Boolean,
    shuffleEnabled: Boolean,
    repeatMode: RepeatMode,
    onPlayPauseClick: () -> Unit,
    onPreviousClick: () -> Unit,
    onNextClick: () -> Unit,
    onShuffleClick: () -> Unit,
    onRepeatClick: () -> Unit,
    enabled: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Shuffle
        ToggleButton(
            icon = Icons.Filled.Shuffle,
            contentDescription = "Aleatorio",
            isActive = shuffleEnabled,
            onClick = onShuffleClick,
            activeColor = PlayerColors.ShuffleActive
        )

        // Previous
        PreviousButton(
            onClick = onPreviousClick,
            enabled = enabled
        )

        // Play/Pause
        PlayPauseButton(
            isPlaying = isPlaying,
            onClick = onPlayPauseClick,
            enabled = enabled
        )

        // Next
        NextButton(
            onClick = onNextClick,
            enabled = enabled
        )

        // Repeat
        ToggleButton(
            icon = when (repeatMode) {
                RepeatMode.ONE -> Icons.Filled.RepeatOne
                else -> Icons.Filled.Repeat
            },
            contentDescription = "Repetir",
            isActive = repeatMode != RepeatMode.OFF,
            onClick = onRepeatClick,
            activeColor = PlayerColors.RepeatActive
        )
    }
}

/**
 * Sheet de opciones de la canción.
 */
@Composable
private fun SongOptionsSheet(
    song: com.musicplayer.pro.domain.model.Song?,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(Sizes.PaddingMedium)
    ) {
        if (song != null) {
            // Información de la canción
            Row(
                modifier = Modifier.padding(bottom = Sizes.PaddingMedium),
                verticalAlignment = Alignment.CenterVertically
            ) {
                com.musicplayer.pro.presentation.components.SmallAlbumArt(
                    albumArtUri = song.albumArtUri,
                    contentDescription = "Carátula",
                    placeholderSeed = song.title
                )
                
                Spacer(modifier = Modifier.width(Sizes.PaddingMedium))
                
                Column {
                    Text(
                        text = song.title,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Opciones (placeholder - se implementarán los items reales)
            Text(
                text = "Opciones de canción",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = Sizes.PaddingMedium)
            )
        }

        Spacer(modifier = Modifier.height(Sizes.PaddingLarge))
    }
}
