package com.musicplayer.pro.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicplayer.pro.domain.usecase.GetSongCountUseCase
import com.musicplayer.pro.domain.usecase.ScanMediaUseCase
import com.musicplayer.pro.presentation.state.MainUiState
import com.musicplayer.pro.presentation.state.UiEvent
import com.musicplayer.pro.util.PermissionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel principal de la aplicación.
 * Gestiona el estado global, permisos y escaneo de biblioteca.
 */
@HiltViewModel
class MainViewModel @Inject constructor(
    private val permissionManager: PermissionManager,
    private val scanMediaUseCase: ScanMediaUseCase,
    private val getSongCountUseCase: GetSongCountUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _events = Channel<UiEvent>()
    val events = _events.receiveAsFlow()

    init {
        checkPermissionAndLoadData()
    }

    /**
     * Verifica el permiso y carga los datos si está concedido.
     */
    fun checkPermissionAndLoadData() {
        val hasPermission = permissionManager.hasAudioPermission()
        _uiState.update { it.copy(hasPermission = hasPermission) }

        if (hasPermission) {
            loadSongCount()
        }
    }

    /**
     * Llamado cuando el permiso es concedido.
     */
    fun onPermissionGranted() {
        _uiState.update { it.copy(hasPermission = true) }
        scanLibrary()
    }

    /**
     * Llamado cuando el permiso es denegado.
     */
    fun onPermissionDenied() {
        _uiState.update { it.copy(hasPermission = false) }
        viewModelScope.launch {
            _events.send(UiEvent.ShowSnackbar("Se requiere permiso para acceder a la música"))
        }
    }

    /**
     * Escanea la biblioteca de música.
     */
    fun scanLibrary() {
        if (_uiState.value.isScanning) return

        viewModelScope.launch {
            _uiState.update { it.copy(isScanning = true, error = null) }

            scanMediaUseCase().fold(
                onSuccess = { songCount ->
                    _uiState.update { 
                        it.copy(
                            isScanning = false,
                            totalSongs = songCount
                        )
                    }
                    if (songCount > 0) {
                        _events.send(UiEvent.ShowSnackbar("Se encontraron $songCount canciones"))
                    } else {
                        _events.send(UiEvent.ShowSnackbar("No se encontraron canciones"))
                    }
                },
                onFailure = { error ->
                    _uiState.update { 
                        it.copy(
                            isScanning = false,
                            error = error.message
                        )
                    }
                    _events.send(UiEvent.ShowSnackbar("Error al escanear: ${error.message}"))
                }
            )
        }
    }

    /**
     * Carga el conteo de canciones.
     */
    private fun loadSongCount() {
        viewModelScope.launch {
            val count = getSongCountUseCase()
            _uiState.update { it.copy(totalSongs = count) }
            
            // Si no hay canciones, escanear automáticamente
            if (count == 0) {
                scanLibrary()
            }
        }
    }

    /**
     * Actualiza la pestaña actual.
     */
    fun setCurrentTab(tabIndex: Int) {
        _uiState.update { it.copy(currentTab = tabIndex) }
    }

    /**
     * Refresca la biblioteca.
     */
    fun refreshLibrary() {
        if (_uiState.value.hasPermission) {
            scanLibrary()
        }
    }

    /**
     * Limpia el error actual.
     */
    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}
