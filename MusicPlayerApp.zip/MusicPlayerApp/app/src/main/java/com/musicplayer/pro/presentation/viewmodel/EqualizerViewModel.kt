package com.musicplayer.pro.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicplayer.pro.presentation.state.EqualizerUiState
import com.musicplayer.pro.presentation.state.UiEvent
import com.musicplayer.pro.service.EqualizerManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel para el ecualizador.
 */
@HiltViewModel
class EqualizerViewModel @Inject constructor(
    private val equalizerManager: EqualizerManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(EqualizerUiState())
    val uiState: StateFlow<EqualizerUiState> = _uiState.asStateFlow()

    private val _events = Channel<UiEvent>()
    val events = _events.receiveAsFlow()

    init {
        observeEqualizerState()
    }

    /**
     * Observa el estado del ecualizador.
     */
    private fun observeEqualizerState() {
        viewModelScope.launch {
            combine(
                equalizerManager.isEnabled,
                equalizerManager.bandLevels,
                equalizerManager.bandFrequencies,
                equalizerManager.bassBoostStrength,
                equalizerManager.currentPreset,
                equalizerManager.presets
            ) { isEnabled, bandLevels, bandFrequencies, bassBoost, currentPreset, presets ->
                EqualizerData(isEnabled, bandLevels, bandFrequencies, bassBoost, currentPreset, presets)
            }.collectLatest { data ->
                val (minLevel, maxLevel) = equalizerManager.getBandLevelRange()
                _uiState.update { state ->
                    state.copy(
                        isEnabled = data.isEnabled,
                        bandLevels = data.bandLevels,
                        bandFrequencies = data.bandFrequencies,
                        bassBoostStrength = data.bassBoostStrength,
                        currentPreset = data.currentPreset,
                        presets = data.presets,
                        minLevel = minLevel,
                        maxLevel = maxLevel
                    )
                }
            }
        }
    }

    /**
     * Inicializa el ecualizador con el ID de sesión de audio.
     */
    fun initialize(audioSessionId: Int) {
        equalizerManager.initialize(audioSessionId)
    }

    /**
     * Habilita o deshabilita el ecualizador.
     */
    fun setEnabled(enabled: Boolean) {
        equalizerManager.setEnabled(enabled)
        viewModelScope.launch {
            val message = if (enabled) "Ecualizador activado" else "Ecualizador desactivado"
            _events.send(UiEvent.ShowSnackbar(message))
        }
    }

    /**
     * Establece el nivel de una banda.
     */
    fun setBandLevel(band: Int, level: Int) {
        equalizerManager.setBandLevel(band, level)
    }

    /**
     * Aplica un preset.
     */
    fun setPreset(presetIndex: Int) {
        equalizerManager.setPreset(presetIndex)
        viewModelScope.launch {
            val presetName = _uiState.value.presets.getOrNull(presetIndex) ?: "Preset"
            _events.send(UiEvent.ShowSnackbar("Preset aplicado: $presetName"))
        }
    }

    /**
     * Aplica un preset personalizado.
     */
    fun applyCustomPreset(name: String, levels: List<Int>) {
        equalizerManager.applyCustomPreset(levels)
        viewModelScope.launch {
            _events.send(UiEvent.ShowSnackbar("Preset aplicado: $name"))
        }
    }

    /**
     * Establece la intensidad del bass boost.
     */
    fun setBassBoostStrength(strength: Int) {
        equalizerManager.setBassBoostStrength(strength)
    }

    /**
     * Reinicia el ecualizador a valores por defecto.
     */
    fun reset() {
        equalizerManager.reset()
        viewModelScope.launch {
            _events.send(UiEvent.ShowSnackbar("Ecualizador reiniciado"))
        }
    }

    /**
     * Obtiene los presets personalizados disponibles.
     */
    fun getCustomPresets(): List<Pair<String, List<Int>>> {
        return listOf(
            "Plano" to EqualizerManager.CustomPresets.FLAT,
            "Bass Boost" to EqualizerManager.CustomPresets.BASS_BOOST,
            "Treble Boost" to EqualizerManager.CustomPresets.TREBLE_BOOST,
            "Vocal" to EqualizerManager.CustomPresets.VOCAL,
            "Rock" to EqualizerManager.CustomPresets.ROCK,
            "Pop" to EqualizerManager.CustomPresets.POP,
            "Jazz" to EqualizerManager.CustomPresets.JAZZ,
            "Clásica" to EqualizerManager.CustomPresets.CLASSICAL,
            "Electrónica" to EqualizerManager.CustomPresets.ELECTRONIC,
            "Hip-Hop" to EqualizerManager.CustomPresets.HIP_HOP
        )
    }

    /**
     * Verifica si el bass boost está soportado.
     */
    fun isBassBoostSupported(): Boolean {
        return equalizerManager.isBassBoostSupported
    }

    /**
     * Libera los recursos del ecualizador.
     */
    fun release() {
        equalizerManager.release()
    }

    override fun onCleared() {
        super.onCleared()
        release()
    }

    /**
     * Clase de datos para combinar los flows del ecualizador.
     */
    private data class EqualizerData(
        val isEnabled: Boolean,
        val bandLevels: List<Int>,
        val bandFrequencies: List<Int>,
        val bassBoostStrength: Int,
        val currentPreset: String?,
        val presets: List<String>
    )
}
