package com.musicplayer.pro.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entidad Room que representa un álbum en la base de datos local.
 */
@Entity(
    tableName = "albums",
    indices = [
        Index(value = ["media_store_id"], unique = true),
        Index(value = ["artist_id"])
    ]
)
data class AlbumEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "media_store_id")
    val mediaStoreId: Long,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "artist")
    val artist: String,

    @ColumnInfo(name = "artist_id")
    val artistId: Long,

    @ColumnInfo(name = "song_count")
    val songCount: Int,

    @ColumnInfo(name = "year")
    val year: Int?,

    @ColumnInfo(name = "album_art_uri")
    val albumArtUri: String?,

    @ColumnInfo(name = "total_duration")
    val totalDuration: Long = 0
)
