package com.musicplayer.pro.presentation.screens

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.presentation.components.TinyAlbumArt
import com.musicplayer.pro.presentation.theme.CustomShapes
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.PlayerViewModel
import org.burnoutcrew.reorderable.ReorderableItem
import org.burnoutcrew.reorderable.detectReorderAfterLongPress
import org.burnoutcrew.reorderable.rememberReorderableLazyListState
import org.burnoutcrew.reorderable.reorderable

/**
 * Pantalla de cola de reproducción.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlayerViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val queue = uiState.queue
    val currentSong = uiState.currentSong

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = "Cola de reproducción")
                        if (queue.isNotEmpty()) {
                            Text(
                                text = "${queue.size} canciones",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Atrás"
                        )
                    }
                },
                actions = {
                    if (queue.isNotEmpty()) {
                        TextButton(onClick = { viewModel.clearQueue() }) {
                            Icon(
                                imageVector = Icons.Filled.Clear,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Limpiar")
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                queue.isEmpty() -> {
                    EmptyState(
                        icon = Icons.Filled.QueueMusic,
                        title = "Cola vacía",
                        message = "Añade canciones a la cola de reproducción"
                    )
                }
                else -> {
                    QueueList(
                        queue = queue,
                        currentSongId = currentSong?.id,
                        onSongClick = { index ->
                            viewModel.skipToQueueItem(index)
                        },
                        onRemoveClick = { index ->
                            viewModel.removeFromQueue(index)
                        },
                        onReorder = { from, to ->
                            viewModel.moveQueueItem(from, to)
                        }
                    )
                }
            }
        }
    }
}

/**
 * Lista de cola con soporte para reordenar.
 */
@Composable
private fun QueueList(
    queue: List<Song>,
    currentSongId: Long?,
    onSongClick: (Int) -> Unit,
    onRemoveClick: (Int) -> Unit,
    onReorder: (Int, Int) -> Unit
) {
    var items by remember(queue) { mutableStateOf(queue) }
    
    val state = rememberReorderableLazyListState(
        onMove = { from, to ->
            items = items.toMutableList().apply {
                add(to.index, removeAt(from.index))
            }
        },
        onDragEnd = { from, to ->
            onReorder(from, to)
        }
    )

    LazyColumn(
        state = state.listState,
        contentPadding = PaddingValues(
            top = Sizes.PaddingSmall,
            bottom = 120.dp
        ),
        modifier = Modifier.reorderable(state)
    ) {
        itemsIndexed(
            items = items,
            key = { _, song -> song.id }
        ) { index, song ->
            ReorderableItem(
                reorderableState = state,
                key = song.id
            ) { isDragging ->
                val elevation by animateDpAsState(
                    targetValue = if (isDragging) 8.dp else 0.dp,
                    label = "elevation"
                )
                
                QueueItem(
                    song = song,
                    index = index + 1,
                    isPlaying = song.id == currentSongId,
                    isDragging = isDragging,
                    elevation = elevation,
                    onClick = { onSongClick(index) },
                    onRemoveClick = { onRemoveClick(index) },
                    modifier = Modifier.detectReorderAfterLongPress(state)
                )
            }
        }
    }
}

/**
 * Item de la cola de reproducción.
 */
@Composable
private fun QueueItem(
    song: Song,
    index: Int,
    isPlaying: Boolean,
    isDragging: Boolean,
    elevation: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
    onRemoveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = Sizes.PaddingMedium, vertical = Sizes.PaddingTiny)
            .shadow(elevation, CustomShapes.SongCard),
        colors = CardDefaults.cardColors(
            containerColor = when {
                isDragging -> MaterialTheme.colorScheme.surfaceVariant
                isPlaying -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                else -> MaterialTheme.colorScheme.surface
            }
        ),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(Sizes.PaddingSmall),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Número de orden
            Text(
                text = "$index",
                style = MaterialTheme.typography.labelMedium,
                color = if (isPlaying) MaterialTheme.colorScheme.primary 
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.width(24.dp)
            )

            Spacer(modifier = Modifier.width(Sizes.PaddingSmall))

            // Carátula
            TinyAlbumArt(
                albumArtUri = song.albumArtUri,
                contentDescription = "Carátula de ${song.title}",
                placeholderSeed = song.title
            )

            Spacer(modifier = Modifier.width(Sizes.PaddingSmall))

            // Información de la canción
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = song.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isPlaying) MaterialTheme.colorScheme.primary 
                            else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = song.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Botón de eliminar
            IconButton(onClick = onRemoveClick) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = "Eliminar de la cola",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Handle para arrastrar
            Icon(
                imageVector = Icons.Filled.DragHandle,
                contentDescription = "Arrastrar para reordenar",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
