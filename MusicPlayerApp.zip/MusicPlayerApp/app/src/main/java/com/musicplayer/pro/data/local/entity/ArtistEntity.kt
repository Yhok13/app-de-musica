package com.musicplayer.pro.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entidad Room que representa un artista en la base de datos local.
 */
@Entity(
    tableName = "artists",
    indices = [
        Index(value = ["media_store_id"], unique = true)
    ]
)
data class ArtistEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "media_store_id")
    val mediaStoreId: Long,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "song_count")
    val songCount: Int,

    @ColumnInfo(name = "album_count")
    val albumCount: Int,

    @ColumnInfo(name = "album_art_uri")
    val albumArtUri: String? = null
)
