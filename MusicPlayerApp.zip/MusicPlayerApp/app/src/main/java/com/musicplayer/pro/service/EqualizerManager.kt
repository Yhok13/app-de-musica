package com.musicplayer.pro.service

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gestor del ecualizador de audio.
 * Proporciona control sobre el ecualizador de 5 bandas y bass boost.
 */
@Singleton
class EqualizerManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    
    private val _isEnabled = MutableStateFlow(false)
    val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    private val _bandLevels = MutableStateFlow<List<Int>>(emptyList())
    val bandLevels: StateFlow<List<Int>> = _bandLevels.asStateFlow()

    private val _bassBoostStrength = MutableStateFlow(0)
    val bassBoostStrength: StateFlow<Int> = _bassBoostStrength.asStateFlow()

    private val _currentPreset = MutableStateFlow<String?>(null)
    val currentPreset: StateFlow<String?> = _currentPreset.asStateFlow()

    private val _presets = MutableStateFlow<List<String>>(emptyList())
    val presets: StateFlow<List<String>> = _presets.asStateFlow()

    private val _bandFrequencies = MutableStateFlow<List<Int>>(emptyList())
    val bandFrequencies: StateFlow<List<Int>> = _bandFrequencies.asStateFlow()

    /**
     * Inicializa el ecualizador con el ID de sesión de audio.
     */
    fun initialize(audioSessionId: Int) {
        release()

        try {
            // Inicializar ecualizador
            equalizer = Equalizer(0, audioSessionId).apply {
                enabled = _isEnabled.value
            }

            // Obtener información de bandas
            equalizer?.let { eq ->
                val numBands = eq.numberOfBands.toInt()
                val frequencies = (0 until numBands).map { band ->
                    eq.getCenterFreq(band.toShort()) / 1000 // Convertir a Hz
                }
                _bandFrequencies.value = frequencies

                // Obtener niveles actuales
                val levels = (0 until numBands).map { band ->
                    eq.getBandLevel(band.toShort()).toInt()
                }
                _bandLevels.value = levels

                // Obtener presets
                val presetNames = (0 until eq.numberOfPresets).map { preset ->
                    eq.getPresetName(preset.toShort())
                }
                _presets.value = presetNames
            }

            // Inicializar bass boost
            bassBoost = BassBoost(0, audioSessionId).apply {
                enabled = _isEnabled.value
                if (strengthSupported) {
                    setStrength(_bassBoostStrength.value.toShort())
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Libera los recursos del ecualizador.
     */
    fun release() {
        try {
            equalizer?.release()
            bassBoost?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        equalizer = null
        bassBoost = null
    }

    /**
     * Habilita o deshabilita el ecualizador.
     */
    fun setEnabled(enabled: Boolean) {
        _isEnabled.value = enabled
        equalizer?.enabled = enabled
        bassBoost?.enabled = enabled
    }

    /**
     * Establece el nivel de una banda específica.
     * @param band Índice de la banda (0-4 para 5 bandas)
     * @param level Nivel en milibeles (-1500 a 1500 típicamente)
     */
    fun setBandLevel(band: Int, level: Int) {
        equalizer?.let { eq ->
            if (band in 0 until eq.numberOfBands) {
                val minLevel = eq.bandLevelRange[0]
                val maxLevel = eq.bandLevelRange[1]
                val clampedLevel = level.coerceIn(minLevel.toInt(), maxLevel.toInt())
                
                eq.setBandLevel(band.toShort(), clampedLevel.toShort())
                
                val currentLevels = _bandLevels.value.toMutableList()
                if (band < currentLevels.size) {
                    currentLevels[band] = clampedLevel
                    _bandLevels.value = currentLevels
                }
                
                _currentPreset.value = null // Preset personalizado
            }
        }
    }

    /**
     * Obtiene el rango de niveles de banda.
     * @return Par con (mínimo, máximo) en milibeles
     */
    fun getBandLevelRange(): Pair<Int, Int> {
        equalizer?.let { eq ->
            return Pair(eq.bandLevelRange[0].toInt(), eq.bandLevelRange[1].toInt())
        }
        return Pair(-1500, 1500)
    }

    /**
     * Aplica un preset predefinido.
     */
    fun setPreset(presetIndex: Int) {
        equalizer?.let { eq ->
            if (presetIndex in 0 until eq.numberOfPresets) {
                eq.usePreset(presetIndex.toShort())
                
                // Actualizar niveles de banda
                val numBands = eq.numberOfBands.toInt()
                val levels = (0 until numBands).map { band ->
                    eq.getBandLevel(band.toShort()).toInt()
                }
                _bandLevels.value = levels
                _currentPreset.value = eq.getPresetName(presetIndex.toShort())
            }
        }
    }

    /**
     * Establece la intensidad del bass boost.
     * @param strength Intensidad de 0 a 1000
     */
    fun setBassBoostStrength(strength: Int) {
        val clampedStrength = strength.coerceIn(0, 1000)
        _bassBoostStrength.value = clampedStrength
        
        bassBoost?.let { bb ->
            if (bb.strengthSupported) {
                bb.setStrength(clampedStrength.toShort())
            }
        }
    }

    /**
     * Reinicia el ecualizador a valores por defecto.
     */
    fun reset() {
        equalizer?.let { eq ->
            val numBands = eq.numberOfBands.toInt()
            for (band in 0 until numBands) {
                eq.setBandLevel(band.toShort(), 0)
            }
            val levels = List(numBands) { 0 }
            _bandLevels.value = levels
        }
        
        setBassBoostStrength(0)
        _currentPreset.value = null
    }

    /**
     * Obtiene el número de bandas del ecualizador.
     */
    val numberOfBands: Int
        get() = equalizer?.numberOfBands?.toInt() ?: 5

    /**
     * Verifica si el bass boost está soportado.
     */
    val isBassBoostSupported: Boolean
        get() = bassBoost?.strengthSupported ?: false

    /**
     * Presets predefinidos personalizados.
     */
    object CustomPresets {
        val FLAT = listOf(0, 0, 0, 0, 0)
        val BASS_BOOST = listOf(600, 400, 0, 0, 0)
        val TREBLE_BOOST = listOf(0, 0, 0, 400, 600)
        val VOCAL = listOf(-200, 0, 400, 400, 0)
        val ROCK = listOf(400, 200, -100, 200, 400)
        val POP = listOf(-100, 200, 400, 200, -100)
        val JAZZ = listOf(300, 0, 100, 100, 300)
        val CLASSICAL = listOf(400, 200, -200, 200, 400)
        val ELECTRONIC = listOf(500, 300, 0, 100, 400)
        val HIP_HOP = listOf(500, 400, 0, 100, 300)
    }

    /**
     * Aplica un preset personalizado.
     */
    fun applyCustomPreset(levels: List<Int>) {
        equalizer?.let { eq ->
            val numBands = eq.numberOfBands.toInt()
            for (band in 0 until minOf(numBands, levels.size)) {
                setBandLevel(band, levels[band])
            }
        }
    }
}
