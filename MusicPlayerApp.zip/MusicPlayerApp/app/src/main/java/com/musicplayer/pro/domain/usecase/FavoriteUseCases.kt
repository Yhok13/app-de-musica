package com.musicplayer.pro.domain.usecase

import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.repository.FavoriteRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

/**
 * Caso de uso para obtener todas las canciones favoritas.
 */
class GetAllFavoritesUseCase @Inject constructor(
    private val favoriteRepository: FavoriteRepository
) {
    operator fun invoke(): Flow<List<Song>> = favoriteRepository.getAllFavorites()
}

/**
 * Caso de uso para verificar si una canción es favorita.
 */
class IsFavoriteUseCase @Inject constructor(
    private val favoriteRepository: FavoriteRepository
) {
    suspend operator fun invoke(songId: Long): Boolean = favoriteRepository.isFavorite(songId)
    
    fun asFlow(songId: Long): Flow<Boolean> = favoriteRepository.isFavoriteFlow(songId)
}

/**
 * Caso de uso para añadir una canción a favoritos.
 */
class AddToFavoritesUseCase @Inject constructor(
    private val favoriteRepository: FavoriteRepository
) {
    suspend operator fun invoke(songId: Long) = favoriteRepository.addToFavorites(songId)
}

/**
 * Caso de uso para eliminar una canción de favoritos.
 */
class RemoveFromFavoritesUseCase @Inject constructor(
    private val favoriteRepository: FavoriteRepository
) {
    suspend operator fun invoke(songId: Long) = favoriteRepository.removeFromFavorites(songId)
}

/**
 * Caso de uso para alternar el estado de favorito de una canción.
 */
class ToggleFavoriteUseCase @Inject constructor(
    private val favoriteRepository: FavoriteRepository
) {
    /**
     * Alterna el estado de favorito.
     * @return true si ahora es favorita, false si se quitó de favoritos.
     */
    suspend operator fun invoke(songId: Long): Boolean = favoriteRepository.toggleFavorite(songId)
}

/**
 * Caso de uso para obtener el conteo de favoritos.
 */
class GetFavoriteCountUseCase @Inject constructor(
    private val favoriteRepository: FavoriteRepository
) {
    suspend operator fun invoke(): Int = favoriteRepository.getFavoriteCount()
    
    fun asFlow(): Flow<Int> = favoriteRepository.getFavoriteCountFlow()
}

/**
 * Caso de uso para obtener los IDs de canciones favoritas.
 */
class GetFavoriteSongIdsUseCase @Inject constructor(
    private val favoriteRepository: FavoriteRepository
) {
    suspend operator fun invoke(): List<Long> = favoriteRepository.getAllFavoriteSongIds()
    
    fun asFlow(): Flow<List<Long>> = favoriteRepository.getAllFavoriteSongIdsFlow()
}
