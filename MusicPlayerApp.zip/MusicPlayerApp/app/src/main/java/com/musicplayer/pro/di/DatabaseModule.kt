package com.musicplayer.pro.di

import android.content.Context
import androidx.room.Room
import com.musicplayer.pro.data.local.dao.AlbumDao
import com.musicplayer.pro.data.local.dao.ArtistDao
import com.musicplayer.pro.data.local.dao.FavoriteDao
import com.musicplayer.pro.data.local.dao.FolderDao
import com.musicplayer.pro.data.local.dao.GenreDao
import com.musicplayer.pro.data.local.dao.PlaylistDao
import com.musicplayer.pro.data.local.dao.SongDao
import com.musicplayer.pro.data.local.database.MusicDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Módulo de Hilt para proveer la base de datos Room y sus DAOs.
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    /**
     * Provee la instancia de la base de datos Room.
     */
    @Provides
    @Singleton
    fun provideMusicDatabase(
        @ApplicationContext context: Context
    ): MusicDatabase {
        return Room.databaseBuilder(
            context,
            MusicDatabase::class.java,
            MusicDatabase.DATABASE_NAME
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    /**
     * Provee el DAO de canciones.
     */
    @Provides
    @Singleton
    fun provideSongDao(database: MusicDatabase): SongDao = database.songDao()

    /**
     * Provee el DAO de álbumes.
     */
    @Provides
    @Singleton
    fun provideAlbumDao(database: MusicDatabase): AlbumDao = database.albumDao()

    /**
     * Provee el DAO de artistas.
     */
    @Provides
    @Singleton
    fun provideArtistDao(database: MusicDatabase): ArtistDao = database.artistDao()

    /**
     * Provee el DAO de géneros.
     */
    @Provides
    @Singleton
    fun provideGenreDao(database: MusicDatabase): GenreDao = database.genreDao()

    /**
     * Provee el DAO de carpetas.
     */
    @Provides
    @Singleton
    fun provideFolderDao(database: MusicDatabase): FolderDao = database.folderDao()

    /**
     * Provee el DAO de playlists.
     */
    @Provides
    @Singleton
    fun providePlaylistDao(database: MusicDatabase): PlaylistDao = database.playlistDao()

    /**
     * Provee el DAO de favoritos.
     */
    @Provides
    @Singleton
    fun provideFavoriteDao(database: MusicDatabase): FavoriteDao = database.favoriteDao()
}
