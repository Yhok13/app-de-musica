package com.musicplayer.pro.util

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import com.musicplayer.pro.domain.model.Song
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gestor de archivos para operaciones de eliminación, compartir y gestión de archivos de audio.
 */
@Singleton
class FileManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val contentResolver: ContentResolver = context.contentResolver

    /**
     * Resultado de una operación de eliminación.
     */
    sealed class DeleteResult {
        object Success : DeleteResult()
        data class RequiresPermission(val intentSender: IntentSender) : DeleteResult()
        data class Error(val message: String) : DeleteResult()
    }

    /**
     * Elimina un archivo de audio del dispositivo.
     * En Android 10+ puede requerir confirmación del usuario.
     */
    suspend fun deleteAudioFile(song: Song): DeleteResult = withContext(Dispatchers.IO) {
        try {
            val uri = ContentUris.withAppendedId(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                song.mediaStoreId
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Android 11+ - Usar createDeleteRequest
                val pendingIntent = MediaStore.createDeleteRequest(
                    contentResolver,
                    listOf(uri)
                )
                return@withContext DeleteResult.RequiresPermission(pendingIntent.intentSender)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10 - Manejar RecoverableSecurityException
                try {
                    contentResolver.delete(uri, null, null)
                    return@withContext DeleteResult.Success
                } catch (e: RecoverableSecurityException) {
                    return@withContext DeleteResult.RequiresPermission(e.userAction.actionIntent.intentSender)
                }
            } else {
                // Android 9 y anteriores - Eliminar directamente
                val file = File(song.filePath)
                if (file.exists()) {
                    if (file.delete()) {
                        // También eliminar de MediaStore
                        contentResolver.delete(uri, null, null)
                        return@withContext DeleteResult.Success
                    } else {
                        return@withContext DeleteResult.Error("No se pudo eliminar el archivo")
                    }
                } else {
                    // El archivo no existe, eliminar solo de MediaStore
                    contentResolver.delete(uri, null, null)
                    return@withContext DeleteResult.Success
                }
            }
        } catch (e: Exception) {
            return@withContext DeleteResult.Error(e.message ?: "Error desconocido")
        }
    }

    /**
     * Elimina múltiples archivos de audio.
     */
    suspend fun deleteMultipleAudioFiles(songs: List<Song>): DeleteResult = withContext(Dispatchers.IO) {
        try {
            val uris = songs.map { song ->
                ContentUris.withAppendedId(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    song.mediaStoreId
                )
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Android 11+ - Usar createDeleteRequest para múltiples archivos
                val pendingIntent = MediaStore.createDeleteRequest(contentResolver, uris)
                return@withContext DeleteResult.RequiresPermission(pendingIntent.intentSender)
            } else {
                // Eliminar uno por uno en versiones anteriores
                var allSuccess = true
                for (song in songs) {
                    val result = deleteAudioFile(song)
                    if (result is DeleteResult.RequiresPermission) {
                        return@withContext result
                    } else if (result is DeleteResult.Error) {
                        allSuccess = false
                    }
                }
                return@withContext if (allSuccess) DeleteResult.Success else DeleteResult.Error("Algunos archivos no se pudieron eliminar")
            }
        } catch (e: Exception) {
            return@withContext DeleteResult.Error(e.message ?: "Error desconocido")
        }
    }

    /**
     * Verifica si un archivo existe.
     */
    fun fileExists(filePath: String): Boolean {
        return File(filePath).exists()
    }

    /**
     * Obtiene el tamaño de un archivo.
     */
    fun getFileSize(filePath: String): Long {
        val file = File(filePath)
        return if (file.exists()) file.length() else 0
    }

    /**
     * Obtiene la URI de contenido de una canción.
     */
    fun getSongContentUri(mediaStoreId: Long): Uri {
        return ContentUris.withAppendedId(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            mediaStoreId
        )
    }

    /**
     * Obtiene la URI del artwork de un álbum.
     */
    fun getAlbumArtUri(albumId: Long): Uri {
        return ContentUris.withAppendedId(
            Uri.parse("content://media/external/audio/albumart"),
            albumId
        )
    }

    /**
     * Verifica si el artwork de un álbum existe.
     */
    suspend fun albumArtExists(albumId: Long): Boolean = withContext(Dispatchers.IO) {
        try {
            val uri = getAlbumArtUri(albumId)
            contentResolver.openInputStream(uri)?.use { true } ?: false
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Obtiene información del archivo.
     */
    data class FileInfo(
        val name: String,
        val path: String,
        val size: Long,
        val extension: String,
        val exists: Boolean,
        val lastModified: Long
    )

    fun getFileInfo(filePath: String): FileInfo {
        val file = File(filePath)
        return FileInfo(
            name = file.name,
            path = file.absolutePath,
            size = if (file.exists()) file.length() else 0,
            extension = file.extension.uppercase(),
            exists = file.exists(),
            lastModified = if (file.exists()) file.lastModified() else 0
        )
    }

    /**
     * Obtiene el directorio padre de un archivo.
     */
    fun getParentDirectory(filePath: String): String? {
        return File(filePath).parent
    }

    /**
     * Lista archivos de audio en un directorio.
     */
    suspend fun listAudioFilesInDirectory(directoryPath: String): List<File> = withContext(Dispatchers.IO) {
        val directory = File(directoryPath)
        if (!directory.exists() || !directory.isDirectory) {
            return@withContext emptyList()
        }

        val supportedExtensions = listOf("mp3", "flac", "ogg", "wav", "aac", "m4a")
        
        directory.listFiles()?.filter { file ->
            file.isFile && file.extension.lowercase() in supportedExtensions
        } ?: emptyList()
    }

    /**
     * Lista subdirectorios en un directorio.
     */
    suspend fun listSubdirectories(directoryPath: String): List<File> = withContext(Dispatchers.IO) {
        val directory = File(directoryPath)
        if (!directory.exists() || !directory.isDirectory) {
            return@withContext emptyList()
        }

        directory.listFiles()?.filter { it.isDirectory } ?: emptyList()
    }
}
