package com.musicplayer.pro.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.annotation.OptIn
import androidx.core.app.NotificationCompat
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.musicplayer.pro.MusicPlayerApplication
import com.musicplayer.pro.R
import com.musicplayer.pro.domain.model.Song
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gestor de notificaciones para el reproductor de música.
 * Crea y actualiza la notificación de reproducción con controles de media.
 */
@Singleton
class MusicNotificationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val scope = CoroutineScope(Dispatchers.Main)

    init {
        createNotificationChannel()
    }

    /**
     * Crea el canal de notificación para Android 8.0+.
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                MusicPlayerApplication.PLAYBACK_CHANNEL_ID,
                context.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.notification_channel_description)
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Construye la notificación de reproducción.
     */
    @OptIn(UnstableApi::class)
    fun buildNotification(
        mediaSession: MediaSession,
        song: Song?,
        isPlaying: Boolean,
        albumArt: Bitmap? = null
    ): Notification {
        val player = mediaSession.player

        // Intent para abrir la app
        val contentIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.let { intent ->
            PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        // Construir la notificación
        val builder = NotificationCompat.Builder(context, MusicPlayerApplication.PLAYBACK_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle(song?.title ?: context.getString(R.string.app_name))
            .setContentText(song?.artist ?: "")
            .setSubText(song?.album)
            .setContentIntent(contentIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setStyle(
                MediaStyleNotificationHelper.MediaStyle(mediaSession)
                    .setShowActionsInCompactView(0, 1, 2)
            )

        // Establecer imagen del álbum
        if (albumArt != null) {
            builder.setLargeIcon(albumArt)
        }

        return builder.build()
    }

    /**
     * Actualiza la notificación.
     */
    fun updateNotification(notification: Notification) {
        notificationManager.notify(MusicPlayerApplication.PLAYBACK_NOTIFICATION_ID, notification)
    }

    /**
     * Cancela la notificación.
     */
    fun cancelNotification() {
        notificationManager.cancel(MusicPlayerApplication.PLAYBACK_NOTIFICATION_ID)
    }

    /**
     * Carga el artwork del álbum de forma asíncrona.
     */
    fun loadAlbumArt(uri: String?, onLoaded: (Bitmap?) -> Unit) {
        if (uri.isNullOrEmpty()) {
            onLoaded(null)
            return
        }

        scope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                try {
                    // Intentar cargar desde URI de contenido
                    context.contentResolver.openInputStream(android.net.Uri.parse(uri))?.use { stream ->
                        BitmapFactory.decodeStream(stream)
                    }
                } catch (e: Exception) {
                    null
                }
            }
            onLoaded(bitmap)
        }
    }
}
