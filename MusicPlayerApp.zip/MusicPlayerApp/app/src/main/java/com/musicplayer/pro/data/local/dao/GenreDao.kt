package com.musicplayer.pro.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.musicplayer.pro.data.local.entity.GenreEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO para operaciones de base de datos relacionadas con géneros musicales.
 */
@Dao
interface GenreDao {

    /**
     * Obtiene todos los géneros ordenados por nombre.
     */
    @Query("SELECT * FROM genres ORDER BY name ASC")
    fun getAllGenres(): Flow<List<GenreEntity>>

    /**
     * Obtiene un género por su ID.
     */
    @Query("SELECT * FROM genres WHERE id = :genreId")
    suspend fun getGenreById(genreId: Long): GenreEntity?

    /**
     * Obtiene un género por su ID de MediaStore.
     */
    @Query("SELECT * FROM genres WHERE media_store_id = :mediaStoreId")
    suspend fun getGenreByMediaStoreId(mediaStoreId: Long): GenreEntity?

    /**
     * Busca géneros por nombre.
     */
    @Query("SELECT * FROM genres WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchGenres(query: String): Flow<List<GenreEntity>>

    /**
     * Obtiene el conteo total de géneros.
     */
    @Query("SELECT COUNT(*) FROM genres")
    suspend fun getGenreCount(): Int

    /**
     * Inserta un género.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGenre(genre: GenreEntity): Long

    /**
     * Inserta múltiples géneros.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGenres(genres: List<GenreEntity>)

    /**
     * Actualiza un género.
     */
    @Update
    suspend fun updateGenre(genre: GenreEntity)

    /**
     * Elimina un género.
     */
    @Delete
    suspend fun deleteGenre(genre: GenreEntity)

    /**
     * Elimina todos los géneros.
     */
    @Query("DELETE FROM genres")
    suspend fun deleteAllGenres()
}
