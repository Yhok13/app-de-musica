package com.musicplayer.pro.presentation.navigation

/**
 * Rutas de navegación de la aplicación.
 */
sealed class Screen(val route: String) {
    // Pantallas principales (Bottom Navigation)
    object Home : Screen("home")
    object Songs : Screen("songs")
    object Albums : Screen("albums")
    object Artists : Screen("artists")
    object Folders : Screen("folders")
    object Playlists : Screen("playlists")
    
    // Pantallas secundarias
    object NowPlaying : Screen("now_playing")
    object Queue : Screen("queue")
    object Search : Screen("search")
    object Settings : Screen("settings")
    object Equalizer : Screen("equalizer")
    object Favorites : Screen("favorites")
    
    // Pantallas con argumentos
    object AlbumDetail : Screen("album/{albumId}") {
        fun createRoute(albumId: Long) = "album/$albumId"
    }
    
    object ArtistDetail : Screen("artist/{artistId}") {
        fun createRoute(artistId: Long) = "artist/$artistId"
    }
    
    object PlaylistDetail : Screen("playlist/{playlistId}") {
        fun createRoute(playlistId: Long) = "playlist/$playlistId"
    }
    
    object FolderDetail : Screen("folder/{folderPath}") {
        fun createRoute(folderPath: String) = "folder/${folderPath.encodeForRoute()}"
    }
    
    // Diálogos
    object CreatePlaylist : Screen("create_playlist")
    object EditPlaylist : Screen("edit_playlist/{playlistId}") {
        fun createRoute(playlistId: Long) = "edit_playlist/$playlistId"
    }
    object AddToPlaylist : Screen("add_to_playlist/{songId}") {
        fun createRoute(songId: Long) = "add_to_playlist/$songId"
    }
    object SongOptions : Screen("song_options/{songId}") {
        fun createRoute(songId: Long) = "song_options/$songId"
    }
    object SortOptions : Screen("sort_options")
}

/**
 * Pestañas de la barra de navegación inferior.
 */
enum class BottomNavTab(
    val route: String,
    val title: String,
    val iconName: String
) {
    SONGS("songs", "Canciones", "music_note"),
    ALBUMS("albums", "Álbumes", "album"),
    ARTISTS("artists", "Artistas", "person"),
    FOLDERS("folders", "Carpetas", "folder"),
    PLAYLISTS("playlists", "Playlists", "playlist_play")
}

/**
 * Argumentos de navegación.
 */
object NavArgs {
    const val ALBUM_ID = "albumId"
    const val ARTIST_ID = "artistId"
    const val PLAYLIST_ID = "playlistId"
    const val FOLDER_PATH = "folderPath"
    const val SONG_ID = "songId"
}

/**
 * Extensión para codificar rutas con caracteres especiales.
 */
fun String.encodeForRoute(): String {
    return java.net.URLEncoder.encode(this, "UTF-8")
}

/**
 * Extensión para decodificar rutas.
 */
fun String.decodeFromRoute(): String {
    return java.net.URLDecoder.decode(this, "UTF-8")
}
