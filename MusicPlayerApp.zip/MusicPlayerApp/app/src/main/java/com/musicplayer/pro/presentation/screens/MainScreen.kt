package com.musicplayer.pro.presentation.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.musicplayer.pro.presentation.components.MiniPlayer
import com.musicplayer.pro.presentation.components.MusicBottomNavigation
import com.musicplayer.pro.presentation.navigation.BottomNavTab
import com.musicplayer.pro.presentation.navigation.Screen
import com.musicplayer.pro.presentation.viewmodel.MainViewModel
import com.musicplayer.pro.presentation.viewmodel.PlayerViewModel

/**
 * Pantalla principal de la aplicación.
 * Contiene la navegación inferior, el mini player y las pantallas principales.
 */
@Composable
fun MainScreen(
    modifier: Modifier = Modifier,
    mainViewModel: MainViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel()
) {
    val navController = rememberNavController()
    val mainUiState by mainViewModel.uiState.collectAsState()
    val playerUiState by playerViewModel.uiState.collectAsState()
    
    var currentTab by remember { mutableStateOf(BottomNavTab.SONGS) }
    var showNowPlaying by remember { mutableStateOf(false) }
    
    // Observar la ruta actual para determinar si mostrar la barra de navegación
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    
    val showBottomBar = currentRoute in listOf(
        Screen.Songs.route,
        Screen.Albums.route,
        Screen.Artists.route,
        Screen.Folders.route,
        Screen.Playlists.route
    )

    if (showNowPlaying) {
        // Pantalla de reproducción a pantalla completa
        NowPlayingScreen(
            onBackClick = { showNowPlaying = false },
            onQueueClick = { /* Navegar a cola */ }
        )
    } else {
        Scaffold(
            modifier = modifier,
            bottomBar = {
                Column {
                    // Mini Player
                    MiniPlayer(
                        song = playerUiState.currentSong,
                        isPlaying = playerUiState.playbackState.isPlaying,
                        progress = playerUiState.playbackState.progress,
                        onPlayPauseClick = { playerViewModel.playPause() },
                        onNextClick = { playerViewModel.skipToNext() },
                        onClick = { showNowPlaying = true },
                        visible = playerUiState.currentSong != null
                    )
                    
                    // Barra de navegación inferior
                    AnimatedVisibility(
                        visible = showBottomBar,
                        enter = slideInVertically(initialOffsetY = { it }),
                        exit = slideOutVertically(targetOffsetY = { it })
                    ) {
                        MusicBottomNavigation(
                            currentTab = currentTab,
                            onTabSelected = { tab ->
                                currentTab = tab
                                navigateToTab(navController, tab)
                            }
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                MainNavHost(
                    navController = navController,
                    onSongClick = { /* Opcional: navegar a detalles */ },
                    onAlbumClick = { album ->
                        navController.navigate(Screen.AlbumDetail.createRoute(album.id))
                    },
                    onArtistClick = { artist ->
                        navController.navigate(Screen.ArtistDetail.createRoute(artist.id))
                    },
                    onPlaylistClick = { playlist ->
                        navController.navigate(Screen.PlaylistDetail.createRoute(playlist.id))
                    },
                    onSearchClick = {
                        navController.navigate(Screen.Search.route)
                    }
                )
            }
        }
    }
}

/**
 * NavHost principal de la aplicación.
 */
@Composable
private fun MainNavHost(
    navController: NavHostController,
    onSongClick: (com.musicplayer.pro.domain.model.Song) -> Unit,
    onAlbumClick: (com.musicplayer.pro.domain.model.Album) -> Unit,
    onArtistClick: (com.musicplayer.pro.domain.model.Artist) -> Unit,
    onPlaylistClick: (com.musicplayer.pro.domain.model.Playlist) -> Unit,
    onSearchClick: () -> Unit
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Songs.route
    ) {
        // Pantallas principales
        composable(Screen.Songs.route) {
            SongsScreen(
                onSongClick = onSongClick,
                onSearchClick = onSearchClick,
                onSortClick = { /* Mostrar opciones de ordenamiento */ }
            )
        }
        
        composable(Screen.Albums.route) {
            AlbumsScreen(
                onAlbumClick = onAlbumClick,
                onSearchClick = onSearchClick
            )
        }
        
        composable(Screen.Artists.route) {
            ArtistsScreen(
                onArtistClick = onArtistClick,
                onSearchClick = onSearchClick
            )
        }
        
        composable(Screen.Folders.route) {
            FoldersScreen(
                onSongClick = onSongClick
            )
        }
        
        composable(Screen.Playlists.route) {
            PlaylistsScreen(
                onPlaylistClick = onPlaylistClick
            )
        }
        
        // Pantalla de búsqueda
        composable(Screen.Search.route) {
            SearchScreen(
                onBackClick = { navController.popBackStack() },
                onSongClick = onSongClick,
                onAlbumClick = onAlbumClick,
                onArtistClick = onArtistClick,
                onPlaylistClick = onPlaylistClick
            )
        }
        
        // Pantalla de favoritos
        composable(Screen.Favorites.route) {
            FavoritesScreen(
                onBackClick = { navController.popBackStack() },
                onSongClick = onSongClick
            )
        }
        
        // Pantalla de ecualizador
        composable(Screen.Equalizer.route) {
            EqualizerScreen(
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}

/**
 * Navega a la pestaña seleccionada.
 */
private fun navigateToTab(navController: NavHostController, tab: BottomNavTab) {
    val route = when (tab) {
        BottomNavTab.SONGS -> Screen.Songs.route
        BottomNavTab.ALBUMS -> Screen.Albums.route
        BottomNavTab.ARTISTS -> Screen.Artists.route
        BottomNavTab.FOLDERS -> Screen.Folders.route
        BottomNavTab.PLAYLISTS -> Screen.Playlists.route
    }
    
    navController.navigate(route) {
        // Evitar múltiples copias de la misma pantalla en el back stack
        popUpTo(navController.graph.startDestinationId) {
            saveState = true
        }
        launchSingleTop = true
        restoreState = true
    }
}
