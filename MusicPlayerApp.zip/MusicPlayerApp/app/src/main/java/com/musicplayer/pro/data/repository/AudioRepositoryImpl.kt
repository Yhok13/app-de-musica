package com.musicplayer.pro.data.repository

import com.musicplayer.pro.data.datasource.MediaStoreDataSource
import com.musicplayer.pro.data.local.dao.AlbumDao
import com.musicplayer.pro.data.local.dao.ArtistDao
import com.musicplayer.pro.data.local.dao.FolderDao
import com.musicplayer.pro.data.local.dao.SongDao
import com.musicplayer.pro.data.local.entity.SongEntity
import com.musicplayer.pro.di.IoDispatcher
import com.musicplayer.pro.domain.model.Album
import com.musicplayer.pro.domain.model.Artist
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.repository.AudioRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implementación del repositorio de audio.
 * Gestiona el acceso a canciones, álbumes y artistas desde MediaStore y Room.
 */
@Singleton
class AudioRepositoryImpl @Inject constructor(
    private val mediaStoreDataSource: MediaStoreDataSource,
    private val songDao: SongDao,
    private val albumDao: AlbumDao,
    private val artistDao: ArtistDao,
    private val folderDao: FolderDao,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : AudioRepository {

    /**
     * Escanea y sincroniza la biblioteca de música con MediaStore.
     */
    override suspend fun scanAndSyncLibrary(): Result<Int> = withContext(ioDispatcher) {
        try {
            // Escanear canciones desde MediaStore
            val songs = mediaStoreDataSource.scanAllSongs()
            
            if (songs.isEmpty()) {
                return@withContext Result.success(0)
            }

            // Insertar canciones en la base de datos
            songDao.insertSongs(songs)

            // Escanear y guardar álbumes
            val albums = mediaStoreDataSource.scanAllAlbums()
            albumDao.insertAlbums(albums)

            // Escanear y guardar artistas
            val artists = mediaStoreDataSource.scanAllArtists()
            artistDao.insertArtists(artists)

            // Extraer y guardar carpetas
            val folders = mediaStoreDataSource.extractFolders(songs)
            folderDao.insertFolders(folders)

            // Limpiar canciones huérfanas (que ya no existen en MediaStore)
            val validIds = songs.map { it.mediaStoreId }
            songDao.deleteOrphanedSongs(validIds)

            Result.success(songs.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Obtiene todas las canciones.
     */
    override fun getAllSongs(): Flow<List<Song>> {
        return songDao.getAllSongs().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene todas las canciones ordenadas por fecha de adición.
     */
    override fun getAllSongsByDateAdded(): Flow<List<Song>> {
        return songDao.getAllSongsByDateAdded().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene una canción por su ID.
     */
    override suspend fun getSongById(songId: Long): Song? {
        return songDao.getSongById(songId)?.toDomainModel()
    }

    /**
     * Obtiene canciones por ID de álbum.
     */
    override fun getSongsByAlbum(albumId: Long): Flow<List<Song>> {
        return songDao.getSongsByAlbum(albumId).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene canciones por ID de artista.
     */
    override fun getSongsByArtist(artistId: Long): Flow<List<Song>> {
        return songDao.getSongsByArtist(artistId).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene canciones por ruta de carpeta.
     */
    override fun getSongsByFolder(folderPath: String): Flow<List<Song>> {
        return songDao.getSongsByFolder(folderPath).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Busca canciones por consulta.
     */
    override fun searchSongs(query: String): Flow<List<Song>> {
        return songDao.searchSongs(query).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene las canciones más reproducidas.
     */
    override fun getMostPlayedSongs(limit: Int): Flow<List<Song>> {
        return songDao.getMostPlayedSongs(limit).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene las canciones reproducidas recientemente.
     */
    override fun getRecentlyPlayedSongs(limit: Int): Flow<List<Song>> {
        return songDao.getRecentlyPlayedSongs(limit).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Incrementa el contador de reproducciones de una canción.
     */
    override suspend fun incrementPlayCount(songId: Long) {
        songDao.incrementPlayCount(songId)
    }

    /**
     * Obtiene el conteo total de canciones.
     */
    override suspend fun getSongCount(): Int {
        return songDao.getSongCount()
    }

    /**
     * Obtiene todos los álbumes.
     */
    override fun getAllAlbums(): Flow<List<Album>> {
        return albumDao.getAllAlbums().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene un álbum por su ID.
     */
    override suspend fun getAlbumById(albumId: Long): Album? {
        return albumDao.getAlbumById(albumId)?.toDomainModel()
    }

    /**
     * Obtiene álbumes por ID de artista.
     */
    override fun getAlbumsByArtist(artistId: Long): Flow<List<Album>> {
        return albumDao.getAlbumsByArtist(artistId).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Busca álbumes por consulta.
     */
    override fun searchAlbums(query: String): Flow<List<Album>> {
        return albumDao.searchAlbums(query).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene todos los artistas.
     */
    override fun getAllArtists(): Flow<List<Artist>> {
        return artistDao.getAllArtists().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Obtiene un artista por su ID.
     */
    override suspend fun getArtistById(artistId: Long): Artist? {
        return artistDao.getArtistById(artistId)?.toDomainModel()
    }

    /**
     * Busca artistas por consulta.
     */
    override fun searchArtists(query: String): Flow<List<Artist>> {
        return artistDao.searchArtists(query).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    /**
     * Elimina una canción de la base de datos.
     */
    override suspend fun deleteSong(songId: Long) {
        songDao.getSongById(songId)?.let { song ->
            songDao.deleteSong(song)
        }
    }
}

/**
 * Extensión para convertir SongEntity a modelo de dominio Song.
 */
private fun SongEntity.toDomainModel(): Song {
    return Song(
        id = id,
        mediaStoreId = mediaStoreId,
        title = title,
        artist = artist,
        artistId = artistId,
        album = album,
        albumId = albumId,
        genre = genre,
        duration = duration,
        filePath = filePath,
        folderPath = folderPath,
        folderName = folderName,
        fileName = fileName,
        fileSize = fileSize,
        mimeType = mimeType,
        bitrate = bitrate,
        sampleRate = sampleRate,
        trackNumber = trackNumber,
        year = year,
        albumArtUri = albumArtUri,
        dateAdded = dateAdded,
        dateModified = dateModified,
        isFavorite = isFavorite,
        playCount = playCount,
        lastPlayed = lastPlayed
    )
}

/**
 * Extensión para convertir AlbumEntity a modelo de dominio Album.
 */
private fun com.musicplayer.pro.data.local.entity.AlbumEntity.toDomainModel(): Album {
    return Album(
        id = id,
        mediaStoreId = mediaStoreId,
        name = name,
        artist = artist,
        artistId = artistId,
        songCount = songCount,
        year = year,
        albumArtUri = albumArtUri,
        totalDuration = totalDuration
    )
}

/**
 * Extensión para convertir ArtistEntity a modelo de dominio Artist.
 */
private fun com.musicplayer.pro.data.local.entity.ArtistEntity.toDomainModel(): Artist {
    return Artist(
        id = id,
        mediaStoreId = mediaStoreId,
        name = name,
        songCount = songCount,
        albumCount = albumCount,
        albumArtUri = albumArtUri
    )
}
