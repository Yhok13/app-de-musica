package com.musicplayer.pro.presentation.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.musicplayer.pro.domain.model.Folder
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.presentation.components.SongItem
import com.musicplayer.pro.presentation.theme.CustomShapes
import com.musicplayer.pro.presentation.theme.Sizes
import com.musicplayer.pro.presentation.viewmodel.FavoritesViewModel
import com.musicplayer.pro.presentation.viewmodel.FoldersViewModel
import com.musicplayer.pro.presentation.viewmodel.PlayerViewModel

/**
 * Pantalla de navegación de carpetas.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoldersScreen(
    onSongClick: (Song) -> Unit,
    modifier: Modifier = Modifier,
    foldersViewModel: FoldersViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel(),
    favoritesViewModel: FavoritesViewModel = hiltViewModel()
) {
    val uiState by foldersViewModel.uiState.collectAsState()
    val playerState by playerViewModel.uiState.collectAsState()
    val favoriteSongIds by favoritesViewModel.favoriteSongIds.collectAsState()
    
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()
    
    // Manejar botón de retroceso
    BackHandler(enabled = !foldersViewModel.isAtRoot()) {
        foldersViewModel.navigateBack()
    }

    Scaffold(
        modifier = modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(text = foldersViewModel.getCurrentFolderName())
                        if (uiState.currentPath != null) {
                            Text(
                                text = uiState.currentPath ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (!foldersViewModel.isAtRoot()) {
                        IconButton(onClick = { foldersViewModel.navigateBack() }) {
                            Icon(
                                imageVector = Icons.Filled.ArrowBack,
                                contentDescription = "Atrás"
                            )
                        }
                    }
                },
                scrollBehavior = scrollBehavior
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                uiState.isLoading -> {
                    LoadingState()
                }
                uiState.folders.isEmpty() && uiState.songsInCurrentFolder.isEmpty() -> {
                    EmptyState(
                        icon = Icons.Filled.Folder,
                        title = "No hay carpetas",
                        message = "No se encontraron carpetas con música"
                    )
                }
                else -> {
                    FolderContent(
                        folders = uiState.folders,
                        songs = uiState.songsInCurrentFolder,
                        currentSongId = playerState.currentSong?.id,
                        favoriteSongIds = favoriteSongIds,
                        onFolderClick = { folder ->
                            foldersViewModel.navigateToFolder(folder)
                        },
                        onSongClick = { song ->
                            val songs = uiState.songsInCurrentFolder
                            playerViewModel.playSongs(songs, songs.indexOf(song))
                            onSongClick(song)
                        },
                        onPlayAllClick = {
                            if (uiState.songsInCurrentFolder.isNotEmpty()) {
                                playerViewModel.playSongs(uiState.songsInCurrentFolder, 0)
                            }
                        },
                        onFavoriteClick = { songId ->
                            favoritesViewModel.toggleFavorite(songId)
                        }
                    )
                }
            }
        }
    }
}

/**
 * Contenido de la carpeta (subcarpetas y canciones).
 */
@Composable
private fun FolderContent(
    folders: List<Folder>,
    songs: List<Song>,
    currentSongId: Long?,
    favoriteSongIds: Set<Long>,
    onFolderClick: (Folder) -> Unit,
    onSongClick: (Song) -> Unit,
    onPlayAllClick: () -> Unit,
    onFavoriteClick: (Long) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(
            top = Sizes.PaddingSmall,
            bottom = 120.dp
        )
    ) {
        // Botón de reproducir todo si hay canciones
        if (songs.isNotEmpty()) {
            item {
                PlayAllHeader(
                    songCount = songs.size,
                    onPlayAllClick = onPlayAllClick
                )
            }
        }

        // Carpetas
        if (folders.isNotEmpty()) {
            item {
                if (songs.isNotEmpty()) {
                    SectionHeader(title = "Carpetas")
                }
            }
            
            items(
                items = folders,
                key = { it.id }
            ) { folder ->
                FolderItem(
                    folder = folder,
                    onClick = { onFolderClick(folder) }
                )
            }
        }

        // Canciones
        if (songs.isNotEmpty()) {
            if (folders.isNotEmpty()) {
                item {
                    SectionHeader(title = "Canciones")
                }
            }
            
            items(
                items = songs,
                key = { it.id }
            ) { song ->
                SongItem(
                    song = song,
                    onClick = { onSongClick(song) },
                    isPlaying = song.id == currentSongId,
                    isFavorite = song.id in favoriteSongIds,
                    onFavoriteClick = { onFavoriteClick(song.id) },
                    onMoreClick = { /* Mostrar opciones */ }
                )
            }
        }
    }
}

/**
 * Header para reproducir todas las canciones.
 */
@Composable
private fun PlayAllHeader(
    songCount: Int,
    onPlayAllClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = Sizes.PaddingMedium, vertical = Sizes.PaddingSmall),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$songCount canciones",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        TextButton(onClick = onPlayAllClick) {
            Icon(
                imageVector = Icons.Filled.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("Reproducir todo")
        }
    }
}

/**
 * Header de sección.
 */
@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(
            horizontal = Sizes.PaddingMedium,
            vertical = Sizes.PaddingSmall
        )
    )
}

/**
 * Item de carpeta.
 */
@Composable
private fun FolderItem(
    folder: Folder,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = Sizes.PaddingMedium, vertical = Sizes.PaddingTiny)
            .clip(CustomShapes.SongCard)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(Sizes.PaddingMedium),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icono de carpeta
            Icon(
                imageVector = Icons.Filled.Folder,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.width(Sizes.PaddingMedium))

            // Información de la carpeta
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = folder.name,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = "${folder.songCount} canciones",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Icono de navegación
            Icon(
                imageVector = Icons.Filled.FolderOpen,
                contentDescription = "Abrir carpeta",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
