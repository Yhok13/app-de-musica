package com.musicplayer.pro.domain.usecase

import com.musicplayer.pro.domain.model.Playlist
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.repository.PlaylistRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

/**
 * Caso de uso para obtener todas las playlists.
 */
class GetAllPlaylistsUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    operator fun invoke(): Flow<List<Playlist>> = playlistRepository.getAllPlaylists()
}

/**
 * Caso de uso para obtener una playlist por ID.
 */
class GetPlaylistByIdUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    suspend operator fun invoke(playlistId: Long): Playlist? = playlistRepository.getPlaylistById(playlistId)
    
    fun asFlow(playlistId: Long): Flow<Playlist?> = playlistRepository.getPlaylistByIdFlow(playlistId)
}

/**
 * Caso de uso para obtener las canciones de una playlist.
 */
class GetPlaylistSongsUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    operator fun invoke(playlistId: Long): Flow<List<Song>> = playlistRepository.getPlaylistSongs(playlistId)
}

/**
 * Caso de uso para crear una playlist.
 */
class CreatePlaylistUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    suspend operator fun invoke(name: String, description: String? = null): Long {
        return playlistRepository.createPlaylist(name, description)
    }
}

/**
 * Caso de uso para actualizar el nombre de una playlist.
 */
class UpdatePlaylistNameUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    suspend operator fun invoke(playlistId: Long, name: String) {
        playlistRepository.updatePlaylistName(playlistId, name)
    }
}

/**
 * Caso de uso para eliminar una playlist.
 */
class DeletePlaylistUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    suspend operator fun invoke(playlistId: Long) {
        playlistRepository.deletePlaylist(playlistId)
    }
}

/**
 * Caso de uso para añadir una canción a una playlist.
 */
class AddSongToPlaylistUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    suspend operator fun invoke(playlistId: Long, songId: Long) {
        playlistRepository.addSongToPlaylist(playlistId, songId)
    }
}

/**
 * Caso de uso para añadir múltiples canciones a una playlist.
 */
class AddSongsToPlaylistUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    suspend operator fun invoke(playlistId: Long, songIds: List<Long>) {
        playlistRepository.addSongsToPlaylist(playlistId, songIds)
    }
}

/**
 * Caso de uso para eliminar una canción de una playlist.
 */
class RemoveSongFromPlaylistUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    suspend operator fun invoke(playlistId: Long, songId: Long) {
        playlistRepository.removeSongFromPlaylist(playlistId, songId)
    }
}

/**
 * Caso de uso para reordenar canciones en una playlist.
 */
class ReorderPlaylistSongsUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    suspend operator fun invoke(playlistId: Long, songId: Long, newPosition: Int) {
        playlistRepository.updateSongPosition(playlistId, songId, newPosition)
    }
}

/**
 * Caso de uso para verificar si una canción está en una playlist.
 */
class IsSongInPlaylistUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    suspend operator fun invoke(playlistId: Long, songId: Long): Boolean {
        return playlistRepository.isSongInPlaylist(playlistId, songId)
    }
}

/**
 * Caso de uso para buscar playlists.
 */
class SearchPlaylistsUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository
) {
    operator fun invoke(query: String): Flow<List<Playlist>> = playlistRepository.searchPlaylists(query)
}
