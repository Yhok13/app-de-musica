package com.musicplayer.pro.domain.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Modelo de dominio que representa una carpeta con archivos de audio.
 */
data class Folder(
    val id: Long,
    val path: String,
    val name: String,
    val parentPath: String?,
    val songCount: Int,
    val totalSize: Long,
    val lastModified: Long
) {
    /**
     * Tamaño total formateado.
     */
    val formattedSize: String
        get() {
            val kb = totalSize / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0

            return when {
                gb >= 1 -> String.format("%.2f GB", gb)
                mb >= 1 -> String.format("%.2f MB", mb)
                else -> String.format("%.2f KB", kb)
            }
        }

    /**
     * Fecha de última modificación formateada.
     */
    val formattedLastModified: String
        get() {
            val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            return dateFormat.format(Date(lastModified * 1000))
        }

    /**
     * Descripción del contenido.
     */
    val contentDescription: String
        get() = if (songCount == 1) "1 canción" else "$songCount canciones"

    /**
     * Información completa (canciones y tamaño).
     */
    val fullInfo: String
        get() = "$contentDescription • $formattedSize"

    /**
     * Verifica si es una carpeta raíz.
     */
    val isRoot: Boolean
        get() = parentPath.isNullOrEmpty()

    /**
     * Obtiene el nombre corto de la ruta (últimos 2 niveles).
     */
    val shortPath: String
        get() {
            val parts = path.split("/").filter { it.isNotEmpty() }
            return if (parts.size > 2) {
                ".../${parts.takeLast(2).joinToString("/")}"
            } else {
                path
            }
        }

    companion object {
        /**
         * Crea una carpeta vacía/placeholder.
         */
        fun empty() = Folder(
            id = 0,
            path = "",
            name = "",
            parentPath = null,
            songCount = 0,
            totalSize = 0,
            lastModified = 0
        )
    }
}
