package com.musicplayer.pro.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicplayer.pro.domain.model.Album
import com.musicplayer.pro.domain.model.Artist
import com.musicplayer.pro.domain.model.Song
import com.musicplayer.pro.domain.usecase.GetAllAlbumsUseCase
import com.musicplayer.pro.domain.usecase.GetAllArtistsUseCase
import com.musicplayer.pro.domain.usecase.GetAllSongsUseCase
import com.musicplayer.pro.domain.usecase.GetSongsByAlbumUseCase
import com.musicplayer.pro.domain.usecase.GetSongsByArtistUseCase
import com.musicplayer.pro.domain.usecase.SearchSongsUseCase
import com.musicplayer.pro.presentation.state.LibraryUiState
import com.musicplayer.pro.presentation.state.SortOrder
import com.musicplayer.pro.presentation.state.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel para la biblioteca de música.
 * Gestiona canciones, álbumes y artistas.
 */
@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val getAllSongsUseCase: GetAllSongsUseCase,
    private val getAllAlbumsUseCase: GetAllAlbumsUseCase,
    private val getAllArtistsUseCase: GetAllArtistsUseCase,
    private val getSongsByAlbumUseCase: GetSongsByAlbumUseCase,
    private val getSongsByArtistUseCase: GetSongsByArtistUseCase,
    private val searchSongsUseCase: SearchSongsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(LibraryUiState())
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()

    private val _events = Channel<UiEvent>()
    val events = _events.receiveAsFlow()

    private var searchJob: Job? = null

    init {
        loadLibrary()
    }

    /**
     * Carga toda la biblioteca.
     */
    fun loadLibrary() {
        loadSongs()
        loadAlbums()
        loadArtists()
    }

    /**
     * Carga todas las canciones.
     */
    private fun loadSongs() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            getAllSongsUseCase()
                .catch { error ->
                    _uiState.update { 
                        it.copy(isLoading = false, error = error.message) 
                    }
                }
                .collectLatest { songs ->
                    val sortedSongs = sortSongs(songs, _uiState.value.sortOrder)
                    _uiState.update { 
                        it.copy(songs = sortedSongs, isLoading = false, error = null) 
                    }
                }
        }
    }

    /**
     * Carga todos los álbumes.
     */
    private fun loadAlbums() {
        viewModelScope.launch {
            getAllAlbumsUseCase()
                .catch { error ->
                    _uiState.update { it.copy(error = error.message) }
                }
                .collectLatest { albums ->
                    _uiState.update { it.copy(albums = albums) }
                }
        }
    }

    /**
     * Carga todos los artistas.
     */
    private fun loadArtists() {
        viewModelScope.launch {
            getAllArtistsUseCase()
                .catch { error ->
                    _uiState.update { it.copy(error = error.message) }
                }
                .collectLatest { artists ->
                    _uiState.update { it.copy(artists = artists) }
                }
        }
    }

    /**
     * Obtiene las canciones de un álbum.
     */
    fun getSongsByAlbum(albumId: Long, onResult: (List<Song>) -> Unit) {
        viewModelScope.launch {
            getSongsByAlbumUseCase(albumId)
                .catch { /* Ignorar errores */ }
                .collectLatest { songs ->
                    onResult(songs)
                }
        }
    }

    /**
     * Obtiene las canciones de un artista.
     */
    fun getSongsByArtist(artistId: Long, onResult: (List<Song>) -> Unit) {
        viewModelScope.launch {
            getSongsByArtistUseCase(artistId)
                .catch { /* Ignorar errores */ }
                .collectLatest { songs ->
                    onResult(songs)
                }
        }
    }

    /**
     * Busca canciones con debounce.
     */
    fun search(query: String) {
        _uiState.update { it.copy(filterQuery = query) }

        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(300) // Debounce de 300ms

            if (query.isBlank()) {
                loadSongs()
                return@launch
            }

            searchSongsUseCase(query)
                .catch { error ->
                    _uiState.update { it.copy(error = error.message) }
                }
                .collectLatest { songs ->
                    val sortedSongs = sortSongs(songs, _uiState.value.sortOrder)
                    _uiState.update { it.copy(songs = sortedSongs) }
                }
        }
    }

    /**
     * Establece el orden de clasificación.
     */
    fun setSortOrder(order: SortOrder) {
        _uiState.update { state ->
            val sortedSongs = sortSongs(state.songs, order)
            state.copy(sortOrder = order, songs = sortedSongs)
        }
    }

    /**
     * Ordena las canciones según el criterio especificado.
     */
    private fun sortSongs(songs: List<Song>, order: SortOrder): List<Song> {
        return when (order) {
            SortOrder.TITLE_ASC -> songs.sortedBy { it.title.lowercase() }
            SortOrder.TITLE_DESC -> songs.sortedByDescending { it.title.lowercase() }
            SortOrder.ARTIST_ASC -> songs.sortedBy { it.artist.lowercase() }
            SortOrder.ARTIST_DESC -> songs.sortedByDescending { it.artist.lowercase() }
            SortOrder.ALBUM_ASC -> songs.sortedBy { it.album.lowercase() }
            SortOrder.ALBUM_DESC -> songs.sortedByDescending { it.album.lowercase() }
            SortOrder.DATE_ADDED_ASC -> songs.sortedBy { it.dateAdded }
            SortOrder.DATE_ADDED_DESC -> songs.sortedByDescending { it.dateAdded }
            SortOrder.DURATION_ASC -> songs.sortedBy { it.duration }
            SortOrder.DURATION_DESC -> songs.sortedByDescending { it.duration }
        }
    }

    /**
     * Refresca la biblioteca.
     */
    fun refresh() {
        loadLibrary()
    }

    /**
     * Limpia el filtro de búsqueda.
     */
    fun clearFilter() {
        _uiState.update { it.copy(filterQuery = "") }
        loadSongs()
    }

    /**
     * Limpia el error.
     */
    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}
